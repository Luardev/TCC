//document.addEventListener('DOMContentLoaded',function(){});
//$(()=>{})

$(document).ready(()=>{
    $('#senha').on('keydown',(event) => {
        if (event.key === "Enter") {  // Verifica se a tecla pressionada foi 'Enter'
            entrar()  // Remove o modal da página
        }
    })
})

async function entrar() {
    let Login = document.getElementById('Login').value;
    let senha = document.getElementById('senha').value;
    let response = await fetch(`Banco/LOGIN.php`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ Login, senha })
    });
    let data = await response.json();
    if (data.status === true) {
        window.location.assign('http://localhost:8080/TCC-main/php/escola/GerenciadorCampeonatos.php')
        //window.location = 'php/escola/cadescola.php';
    } else {
        $("#aviso").show();
        $("#aviso").html(` 
        <div class="alert alert-danger d-flex align-items-center" role="alert">
        <svg class="bi flex-shrink-0 me-2" width="16" height="20" role="img" aria-label="Danger:">
            <use xlink:href="#exclamation-triangle-fill" />
        </svg>
        <div class=''>Erro: `+data.message+`</div>
        </div>`);
        $("#aviso").fadeOut(2500);
    }
}

// FUNÇÕES DE USO GERAL NO PROJETO
const Aviso = (action,message) => { 
    switch (action){
        case 'success':
            $("#teste").html(`
                <div class="alert alert-success z-3 position-fixed end-0 d-flex align-items-center justify-content-center gap-2 w-md-25 mx-auto me-1 mt-2" role="alert">
                    <i class="material-icons">check_circle</i>
                <div>${message}</div>`);
            $("#teste").show();
            $("#teste").fadeOut(3000);
        break;
        case 'warning':
            $("#teste").html(`
                <div class="alert alert-warning z-3 position-fixed end-0 d-flex align-items-center justify-content-center gap-2 w-md-25 mx-auto me-1 mt-2" role="alert">
                    <i class="material-icons">warning</i>
                <div>${message}</div>`);
            $("#teste").show();
            $("#teste").fadeOut(3000);
        break;
        case 'error':
            $("#teste").html(`
                <div class="alert alert-danger z-3 position-fixed end-0 d-flex align-items-center justify-content-center gap-2 w-md-25 mx-auto me-1 mt-2" role="alert">
                <i class="material-icons">error</i>
                <div>${message}</div>`);
            $("#teste").show();
            $("#teste").fadeOut(3000);
        break;
        case 'info':
            $("#teste").html(`
                <div class="alert alert-primary z-3 position-fixed end-0 d-flex align-items-center justify-content-center gap-2 
                w-md-25 mx-auto me-1 mt-2" role="alert">
                <i class="material-icons">info</i>
                <div>${message}</div>`);
            $("#teste").show();
            $("#teste").fadeOut(3000);
        break;

    }
}

const loadingSpinner = (elementID, action) => {
    $(`#${elementID}`).html(`
    <div class="d-flex justify-content-center">
        <div class="spinner-border" role="status" style="width: 4rem; height: 4rem;">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    `);
    action && action === 'hide' ?  $(`#${elementID}`).empty() : '';
}