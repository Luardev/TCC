<?php
// Cabeçalhos para permitir CORS
header('Access-Control-Allow-Methods: POST, GET, PUT, DELETE, OPTIONS'); // Adicionando mais métodos se necessário
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Origin: *'); // Permite qualquer origem
header('Access-Control-Max-Age: 86400'); // Opcional: Tempo em segundos que o navegador pode armazenar a resposta de CORS

date_default_timezone_set('America/Sao_Paulo'); // Passa como horário local o de São Paulo

if (session_status() == PHP_SESSION_NONE){
    session_start();
}

// Verificação de login
if (!isset($_SESSION['login'])) {
    header('Location: ../login.php');
    exit();
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
