<?php
  require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesBuscaCliente.php';

  if (isset($_GET['id'])) {
    $id_camp = $_GET['id'];
  }

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Campeonato - E-Sports Arena</title>
  <link rel="stylesheet" href="../../CSS/style.css">
  <!--<link rel="stylesheet" href="../../CSS/tela_campeonato.css">-->
  <link rel="stylesheet" href="../../CSS/cliente_moderno.css">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&family=Rajdhani:wght@400;500;700&family=Sarpanch:wght@700;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-bracket/0.11.1/jquery.bracket.min.css">
  
</head>

<body>
  <div class="overlay" id="menuOverlay" onclick="toggleMenu()"></div>
  
  <!-- ======= HEADER ======= -->
  <header id="header" class="header-transparent">
    <div style="display: flex; align-items: center; gap: 2rem; flex-wrap: wrap;">
      <a href="../../index.php" style="text-decoration: none;">
      <div onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'" class="logo">
          <img src="../../Imagens/Logo.png" alt="Logo Interclasse" style="height: 48px; border-radius: 100%; filter: drop-shadow(0 0 5px rgba(255,255,255,0.5));">
          <span class="titulo_real">INTERCLASSE</span>
        </div>
      </a>
      <button class="menu-toggle" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
      <nav id="navLinks" style="display: flex; flex-wrap: wrap; gap: 1.5rem; font-weight: bold; font-size: 1rem;">
        <a href="../login.php" class="nav-link">ACESSO ESCOLAR</a>
      </nav>
    </div>
  </header>

  <main>
    <section class="section cabecalho">
    <?php
        $result = buscarCampeonatos($id_camp);
        $row = $result->fetch_assoc();
        echo "<h1>" . htmlspecialchars($row['nome']) . "</h1>";
        echo "<h2>" . htmlspecialchars($row['escola']) . "</h2>";
        echo "<h3>" . htmlspecialchars($row['ano']) . "</h3>";
    ?>  
    <!--<h1>Campeonato Municipal de Futsal</h1>
      <h2>Escola Estadual Monte Azul</h2>
      <h3>2025</h3>-->
    </section>

    <section class="section jogos">
      <?php
        $result_partidas = buscarPartidas($id_camp);
        $teams = [];
        $results = [];
        $id_fase_atual = null;
        $rounds = [];
        $menor_fase = PHP_INT_MAX;
        if ($result_partidas != "Não apresenta partidas") {          
          if ($result_partidas->num_rows > 0) {            
            while ($row_fase = $result_partidas->fetch_assoc()) {
                if ($row_fase['FK_FASE'] < $menor_fase) {
                  $menor_fase = $row_fase['FK_FASE'];
                }
            }
            $result_partidas->data_seek(0);
            while ($row = $result_partidas->fetch_assoc()) {
                // Pegar os jogos das primeiras fases para fazer a visualização do chaveamento
                if ($row['FK_FASE'] == $menor_fase) {
                  $teams[] = [ [$row['TIME1']], [$row['TIME2']] ];
                }
                // Pegar os resultados de todos os jogos para apresentar:
                $fase = (int)$row['FK_FASE'];
                if (!isset($rounds[$fase])) {
                  $rounds[$fase] = [];
                }
                $rounds[$fase][] = [
                    "time1" => $row['TIME1'],
                    "time2" => $row['TIME2'],
                    "gols1" => (int)$row['GOLS_TIME1'],
                    "gols2" => (int)$row['GOLS_TIME2']
                ];
                
                // Exibição dos jogos de todas as fases 
                if ($id_fase_atual !== $row['DETALHE']) {
                    if ($id_fase_atual !== null) {
                      echo "</div>"; // Fecha a div da fase anterior
                    } 
                    $id_fase_atual = $row['DETALHE'];
                    echo "<div class='divisao_fase'>"; // Abre uma nova div para a nova fase
                    echo "<h2>" . htmlspecialchars($row['DETALHE']) . "</h2>";
                }
                echo "<div class=\"jogo-card\" id='fase{$row['FK_FASE']}_jogo{$row['ID_PARTIDA']}'>";
                  echo "<a href=\"tela_partida.php?id_partida=" . $row['ID_PARTIDA'] . "&id_camp=" . $id_camp . "&id_fase=" . $row['FK_FASE'] . "\">";
                  
                  echo "<div class=\"divdia\">";
                  if ($row['STATUS'] == "I") {
                    echo "<span class=\"data_partida_ao_vivo\" style='display:block;'> AO VIVO</span>";
                  } else if ($row['STATUS'] == "T") {
                    echo "<span class=\"data_partida\" style='display:block;'> Encerrado em " . htmlspecialchars($row['DATA_PARTIDA']) . "</span>";
                  } else {
                    echo "<span class=\"data_partida\" style='display:block;'> Não iniciada </span>";  
                  }
                  echo "</div>";
                  echo "<div class=\"divplacar\">";
                      
                      echo "<p class='times'>" . htmlspecialchars($row['TIME1']) . "</p>";
                      echo "<div class='plac'>";
                      echo "<p>" . htmlspecialchars($row['GOLS_TIME1']) . "</p>";
                      echo "<p>X</p>";
                      echo "<p>" . htmlspecialchars($row['GOLS_TIME2']) . "</p>";
                      echo "</div>";
                      echo "<p class='times'>" . htmlspecialchars($row['TIME2']) . "</p>";
                      
                    echo "</div>";
                  echo "</a>";
                echo "</div>";
                
                  
            }
            ksort($rounds);

            // Apenas os valores em sequência (sub-arrays por fase)
            $results = [];
            foreach ($rounds as $fase => $partidas) {
                $fase_result = [];
                foreach ($partidas as $p) {
                    $fase_result[] = [ $p['gols1'], $p['gols2'] ];
                }
                $results[] = $fase_result;
            }

          } 
        } else {
          echo "<p style='text-align: center; font-size: 1.5rem;'>Ainda não há partidas registradas para este campeonato.</p>";
        }
        
      ?>
        
      </div>
    </section>

    <section class="painel-tabela">
      <div class="tabs">
        <button class="tab active" onclick="mudarAba('classificacao')">Classificação</button>
        <button class="tab" onclick="mudarAba('artilheiros')">Artilheiros</button>
      </div>

      <div id="classificacao" class="tabela-conteudo ativo">
      </div>
      
      
      <div id="artilheiros" class="tabela-conteudo">
        <table>
          <?php
          $artilheiros = buscarJogadores($id_camp); // sua função atual
          
          if($artilheiros === "Não apresenta jogadores") {
              echo "<p> </p>";
          } else {
            $artilheirosList = [];
            while ($row = $artilheiros->fetch_assoc()) {
                $artilheirosList[] = $row;
            }
            usort($artilheirosList, function($a, $b) {
              if ($a['QTD_GOL'] == $b['QTD_GOL']) {
                  return 0;
              }
              return ($a['QTD_GOL'] < $b['QTD_GOL']) ? 1 : -1; // ordena desc
            });
            
            $top10 = array_slice($artilheirosList, 0, 10); // pega só os 10 primeiros
          }
          
        ?>
          <thead>
            <tr>
              <th>#</th>
              <th>Nome</th>
              <th>Time</th>
              <th>Gols</th>
            </tr>
          </thead>
          <tbody>
            <?php
              if (empty($top10)) {
                  echo "<tr><td colspan='4'>Nenhum artilheiro registrado.</td></tr>";
              } else {
                $pos = 1;
                foreach ($top10 as $jogador) {
                    // Definir emoji para os 3 primeiros
                    $icone = "";
                    if ($pos == 1) $icone = "🥇";
                    elseif ($pos == 2) $icone = "🥈";
                    elseif ($pos == 3) $icone = "🥉";

                    echo "<tr>
                            <td>{$icone} {$pos}º</td>
                            <td>{$jogador['NOME']}</td>
                            <td>{$jogador['TIME']}</td>
                            <td>{$jogador['QTD_GOL']}</td>
                          </tr>";
                    $pos++;
                }
                }
              
            ?>
          </tbody>
        </table>
      </div>
    </section>
  </main>

  <!-- ======= FOOTER ======= -->
  <footer id="contato" style="background: #0b0b14; color: #ccc; text-align: center; padding: 2rem; margin-top: 2rem;">
      <p>© 2025 Interclasse. Todos os direitos reservados.</p>
      <p>Participe do maior campeonato estudantil do Brasil!</p>
      <p>Contatos</p>
      <div style="margin-top: 1rem;">
        <a href="mailto:tccMain@gmail.com" style="color:#4a90e2; margin:0 10px;"><i class="fa-regular fa-envelope"></i></a>
      </div>
    </footer>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-bracket/0.11.1/jquery.bracket.min.js"></script>
  <script src="../../js/api-poller.js"></script>
  <script>
    function toggleMenu() {
      const nav = document.getElementById("navLinks");
      const overlay = document.getElementById("menuOverlay");
      nav.classList.toggle("show");
      overlay.classList.toggle("active");
    }
    window.addEventListener('scroll', () => {
      const header = document.getElementById('header');
      if (window.scrollY > 20) {
        header.classList.remove('header-transparent');
        header.classList.add('header-scrolled');
      } else {
        header.classList.remove('header-scrolled');
        header.classList.add('header-transparent');
      }
    });
    
    function mudarAba(abaId) {
      document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
      document.querySelectorAll('.tabela-conteudo').forEach(t => t.classList.remove('ativo'));
      document.getElementById(abaId).classList.add('ativo');
      event.currentTarget.classList.add('active');
    }

    // INSERE O CHAVEAMENTO
    
    var times = <?php echo json_encode($teams, JSON_UNESCAPED_UNICODE); ?>;
    var results = <?php echo json_encode($results, JSON_UNESCAPED_UNICODE); ?>; 
    var data = {
      teams: times,
      results: results
    };
      /*[
        [["1° Nutri A"], ["2° ADM A"]],
        [["2° Nutri B"], ["1° A"]],
        [["1° ADM C"]  , ["3° B"]],
        [["3° Info A"] , ["1° B"]],
        [["2° Info C"] , ["1° Info B"]],
        [["3° Nutri A"] , ["3° Info B"]],
        [["2° B"]  , ["3° C"]],
        [["3° ADM A"], ["1° Nutri B"]]
      ],
      results : [
        [ [1,2], [2,1], [3,0], [2,1], [1,0], [2,3], [0,2], [3,1] ], // oitavas
        [ [2,1], [0,3], [1,2], [3,0] ] ,                          // quartas
        [ [3,0], [2,1] ],
        [ [3,4], [1,0] ]
        
      ]*/

    // Renderiza card do time
    function renderTeam(container, data, score, state) {
      if (!data) return;
      const [name, flag] = data;
      $(container).html(`
        <style>
          div.jQBracket .team{    
                align-items: center;
                gap: 8px;
                background: var(--gradient-card) !important;
                border: 1px solid var(--border-color) !important;
                border-radius: var(--radius-sm) !important;
                padding: 6px 10px;
                transition: all 0.2s ease-in-out;
          }
          div.jQBracket .tools {
                position: absolute;
                top: 0;
                color: #fff;
                display: none;
          }
          div.jQBracket .team.lose {
            background-color: #333;
          }
          div.jQBracket .team.lose div.score {
            color: #B00;
          }
          div.jQBracket .team.win div.score {
            color: #075511;
          }
          div.jQBracket .team div.score {
              float: right;
              padding: 3px;
              background-color: rgba(255, 255, 255, 0.7);
              text-align: center;
              box-sizing: border-box;
              border-radius: 30%;
          }
        </style>
        <span class="team-name">${name}</span>
        
      `);
    }

    // Monta o bracket
    $('#classificacao').bracket({
      init: data,
      teamWidth: 160,
      scoreWidth: 30,
      matchMargin: 40,
      roundMargin: 70,
      save: function(){}, 
      decorator: { render: renderTeam, edit: function(){} }
    });

    // Sistema de polling para atualização automática dos dados
    let campeonatoPoller = null;
    
    // Inicializa o polling quando a página carrega
    document.addEventListener('DOMContentLoaded', function() {
      const campeonatoId = <?php echo json_encode($id_camp); ?>;
      
      if (campeonatoId) {
        campeonatoPoller = createCampeonatoPoller(campeonatoId, {
          interval: 5000, // Atualiza a cada 5 segundos
          onDataUpdate: function(data) {
            console.log("Dados do campeonato atualizados ADSDADASDASDA:", data);
            updateCampeonatoData(data);
          },
          onError: function(error, consecutiveErrors) {
            console.warn(`Erro na atualização automática (${consecutiveErrors}):`, error.message);
            
            // Mostra notificação discreta após alguns erros
            if (consecutiveErrors >= 3) {
              showUpdateError();
            }
          },
          onStart: function() {
            console.log('Atualização automática iniciada');
            showUpdateStatus('Atualização automática ativa');
          },
          onStop: function() {
            console.log('Atualização automática parada');
            showUpdateStatus('Atualização automática pausada');
          }
        });
        
        // Inicia o polling
        campeonatoPoller.start();
        
        // Para o polling quando a página é fechada ou navegada
        window.addEventListener('beforeunload', function() {
          if (campeonatoPoller) {
            campeonatoPoller.stop();
          }
        });
        
        // Pausa/retoma polling quando a aba perde/ganha foco
        document.addEventListener('visibilitychange', function() {
          if (document.hidden) {
            if (campeonatoPoller && campeonatoPoller.isRunning) {
              campeonatoPoller.stop();
            }
          } else {
            if (campeonatoPoller && !campeonatoPoller.isRunning) {
              campeonatoPoller.start();
            }
          }
        });
      }
    });

    // Função para atualizar os dados do campeonato na interface
    function updateCampeonatoData(data) {
      try {
        // Atualiza placares dos jogos
        if (data.partidas) {
          data.partidas.forEach(function(partida) {
            const jogoElement = document.getElementById(`fase${partida.FK_FASE}_jogo${partida.ID_PARTIDA}`);
            if (jogoElement) {
              const statusElement = jogoElement.querySelector('.data_partida, .data_partida_ao_vivo');
              if (!statusElement) return;

              const isLive = partida.STATUS === 'I';
              const isEnded = partida.STATUS === 'T';

              if (isEnded) {
                statusElement.textContent = 'Encerrado em ' + partida.DATA_PARTIDA;
                statusElement.classList.remove('data_partida_ao_vivo');
                statusElement.classList.add('data_partida');
              } else if (isLive) {
                statusElement.textContent = ' AO VIVO';
                statusElement.classList.remove('data_partida');
                statusElement.classList.add('data_partida_ao_vivo');
              } else {
                // Oculta se não houver status conhecido
                statusElement.style.display = 'block';
                statusElement.textContent = 'Não iniciada';
                statusElement.classList.remove('data_partida_ao_vivo');
                statusElement.classList.add('data_partida');
              }
              const placarElement = jogoElement.querySelector('.plac');
              if (placarElement) {
                const placarAtual = placarElement.innerHTML;
                const novoPlacar = `<p>${partida.GOLS_TIME1}</p><p>X</p><p>${partida.GOLS_TIME2}</p>`;
                
                if (placarAtual !== novoPlacar) {
                  placarElement.innerHTML = novoPlacar;
                  // Adiciona efeito visual de atualização
                  placarElement.style.backgroundColor = '#4a90e2';
                  setTimeout(() => {
                    placarElement.style.backgroundColor = '';
                  }, 1000);
                }
              }
            }
          });
        }

        // Atualiza tabela de artilheiros
        if (data.artilheiros) {
          updateArtilheirosTable(data.artilheiros);
        }

        // Atualiza chaveamento se necessário
        if (data.chaveamento) {
          updateBracket(data.chaveamento);
        }

        console.log('Dados do campeonato atualizados com sucesso');
        
      } catch (error) {
        console.error('Erro ao atualizar interface:', error);
      }
    }

    // Função para atualizar tabela de artilheiros
    function updateArtilheirosTable(artilheiros) {
      const tbody = document.querySelector('#artilheiros tbody');
      if (!tbody) return;

      tbody.innerHTML = '';
      
      artilheiros.slice(0, 10).forEach(function(jogador, index) {
        const pos = index + 1;
        let icone = '';
        if (pos === 1) icone = '🥇';
        else if (pos === 2) icone = '🥈';
        else if (pos === 3) icone = '🥉';

        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${icone} ${pos}º</td>
          <td>${jogador.NOME}</td>
          <td>${jogador.TIME}</td>
          <td>${jogador.QTD_GOL}</td>
        `;
        tbody.appendChild(row);
      });
    }

    // Função para atualizar o chaveamento
    function updateBracket(chaveamento) {
      try {
        // Destrói o bracket atual
        $('#classificacao').empty();
        
        // Recria com novos dados
        $('#classificacao').bracket({
          init: chaveamento,
          teamWidth: 160,
          scoreWidth: 30,
          matchMargin: 40,
          roundMargin: 70,
          save: function(){}, 
          decorator: { render: renderTeam, edit: function(){} }
        });
      } catch (error) {
        console.error('Erro ao atualizar chaveamento:', error);
      }
    }

    // Função para mostrar status de atualização
    function showUpdateStatus(message) {
      // Remove notificação anterior se existir
      const existingNotification = document.querySelector('.update-notification');
      if (existingNotification) {
        existingNotification.remove();
      }

      const notification = document.createElement('div');
      notification.className = 'update-notification';
      notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: rgba(0, 255, 231, 0.9);
        color: #000;
        padding: 10px 15px;
        border-radius: 5px;
        font-size: 14px;
        z-index: 1000;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      `;
      notification.textContent = message;
      
      document.body.appendChild(notification);
      
      // Remove após 3 segundos
      setTimeout(() => {
        if (notification.parentNode) {
          notification.remove();
        }
      }, 3000);
    }

    // Função para mostrar erro de atualização
    function showUpdateError() {
      const notification = document.createElement('div');
      notification.className = 'update-error';
      notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: rgba(255, 0, 0, 0.9);
        color: white;
        padding: 10px 15px;
        border-radius: 5px;
        font-size: 14px;
        z-index: 1000;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      `;
      notification.textContent = 'Erro na atualização automática';
      
      document.body.appendChild(notification);
      
      // Remove após 5 segundos
      setTimeout(() => {
        if (notification.parentNode) {
          notification.remove();
        }
      }, 5000);
    }

    // Função para controlar o polling manualmente (útil para debug)
    window.togglePolling = function() {
      if (campeonatoPoller) {
        if (campeonatoPoller.isRunning) {
          campeonatoPoller.stop();
        } else {
          campeonatoPoller.start();
        }
      }
    };

    // Função para forçar atualização imediata
    window.forceUpdate = function() {
      if (campeonatoPoller) {
        campeonatoPoller.forceRequest();
      }
    };
  </script>
</body>

</html>