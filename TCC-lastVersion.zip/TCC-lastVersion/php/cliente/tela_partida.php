<?php
  require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesBuscaCliente.php';

  if (isset($_GET['id_partida']) & isset($_GET['id_camp']) & is_numeric($_GET['id_fase'])) {
    $id_camp = $_GET['id_camp'];
    $id_partida = $_GET['id_partida'];
    $id_fase = $_GET['id_fase'];
  }

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Partida - Ao Vivo</title>
  <link rel="stylesheet" href="../../CSS/style.css" />
  <!--<link rel="stylesheet" href="../../CSS/tela_partida_aovivo.css" />-->
  <link rel="stylesheet" href="../../CSS/cliente_moderno.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Rajdhani:wght@500;700&display=swap" rel="stylesheet" />
</head>

<body>  
  <div class="overlay" id="menuOverlay" onclick="toggleMenu()"></div>
  
  <!-- ======= HEADER ======= -->
  <header id="header" class="header-transparent">
    <div style="display: flex; align-items: center; gap: 2rem; flex-wrap: wrap;">
      <a href="../../index.php" style="text-decoration: none;">
      <div onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'" class="logo">
          <img src="../../Imagens/Logo.png" alt="Logo Interclasse" style="height: 48px; border-radius: 100%; filter: drop-shadow(0 0 5px rgba(255,255,255,0.5));">
          <span class="titulo_real">INTERCLASSE</span>
        </div>
      </a>
      <button class="menu-toggle" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
      <nav id="navLinks" style="display: flex; flex-wrap: wrap; gap: 1.5rem; font-weight: bold; font-size: 1rem;">
        <a href="../login.php" class="nav-link">ACESSO ESCOLAR</a>
      </nav>
    </div>
  </header>

  <main>
    <!-- APRESENTAÇÃO -->
    <?php
      $result_camp = buscarCampeonatos($id_camp);
      $row = $result_camp->fetch_assoc();

      $result_partida = buscarUmaPartida($id_partida, $id_camp, $id_fase);
      $row_partida = $result_partida->fetch_assoc();

     echo "<section class=\"section\" style=\"text-align: center; margin-top: 120px;\">
      <h2>" . htmlspecialchars($row['nome']) . "</h2>
      <p style=\"color: #4a90e2;\">" . htmlspecialchars($row['escola']) . " | " . htmlspecialchars($row_partida['DATA_PARTIDA']) . "</p>
    </section>";
    ?>
  
    <!-- PLACAR MODERNO -->
    <section class="scoreboard-modern">
      <div class="team">
         
        <?php
          echo "<a href=\"tela_time_cliente.php?id_time=" . htmlspecialchars($row_partida['FKID_TIME1']) . "&id_camp=" . htmlspecialchars($id_camp) . "\">";
            echo "<h3>" . htmlspecialchars($row_partida['TIME_1']) . "</h3>";
          echo "</a>";
        ?>
      </div>
      <div class="score">
        <?php 
          echo "<span class=\"score-number\">". htmlspecialchars($row_partida['GOLS_TIME1']) ."</span>";
        ?>
        <span class="score-separator">x</span>
        <?php 
          echo "<span class=\"score-number\">". htmlspecialchars($row_partida['GOLS_TIME2']) ."</span>";
        ?>
        <?php
          
          if ($row_partida['STATUS'] == "T") {
            echo "<p class=\"match-status\">Encerrado</p>";
          } else if ($row_partida['STATUS'] == "I") {
            echo "<span class=\"live-badge\" style='display:block;'>● AO VIVO</span>";
          } else {
            echo "<p class=\"match-status\">Não iniciada</p>";
          }
          $status = $row_partida['STATUS'];
        ?>
      </div>
      <div class="team">
        <?php
          echo "<a href=\"tela_time_cliente.php?id_time=" . htmlspecialchars($row_partida['FKID_TIME2']) . "&id_camp=" . htmlspecialchars($id_camp) . "\">";
            echo "<h3>" . htmlspecialchars($row_partida['TIME_2']) . "</h3>";
          echo "</a>";
        ?>
      </div>

    </section>
      <!-- LINHA DO TEMPO -->
    

          <?php
            echo "<section class=\"section\">
              <h2>Linha do Tempo</h2>
              <div class=\"timeline\">";
            if ($status == "I" || $status == "T") { 
                       
              $result_eventos = buscarEventosPartida($id_partida, $id_fase, $id_camp);
              if (is_string($result_eventos)) {
                echo "<p style='text-align: center'>Ainda não há eventos</p>";
              } else {
                
                while ($row = $result_eventos->fetch_assoc()) {
                  $time = $row['FKID_TIME'];
                  $jogador = $row['JOGADOR'] ?: "";
                  $evento = $row['TIPO_EVENTO'];
                  $minuto = $row['minutos_partida'];

                  // Define classe e ícone conforme o tipo do evento
                  switch ($evento) {
                      case "Gol":
                          $classe = "gol";
                          $icone = "⚽";
                          break;
                      case "Cartões amarelos":
                          $classe = "amarelo";
                          $icone = "🟨";
                          break;
                      case "Cartões vermelhos":
                          $classe = "vermelho";
                          $icone = "🟥";
                          break;
                      case "Faltas":
                          $classe = "falta";
                          $icone = "🚩";
                          break;
                      case "Chutes a gol":
                          $classe = "chute";
                          $icone = "🎯";
                          break;
                      case "Inicio Partida":
                          $classe = "inicio";
                          $icone = "🕑";
                          break;
                      case "Final Partida":
                          $classe = "fim";
                          $icone = "🔔";
                          break;
                      default:
                          $classe = "";
                          $icone = "📌";
                          break;
                  }
                
                  if ($evento === "Inicio Partida" || $evento === "Final Partida") {
                      $lado = "center";
                  } else {
                      $lado = ($time == $row_partida['FKID_TIME1']) ? "left" : "right";
                  }

                  // Monta o texto (início e fim não precisam de jogador)
                  $texto = ($jogador)
                      ? "$icone $evento de $jogador"
                      : "$icone $evento";

                  echo "
                  <div class='evento $lado $classe'>
                      $texto
                      <span>{$minuto}'</span>
                  </div>
                  ";
                }
                
                }
                
              } 
              echo "  </div>
                      </section>";
              
          ?>
        
  
    <!-- ESTATÍSTICAS COM BARRAS -->
     <?php
      $result_estatisticas_time1 = buscarEstatisticasAgrupadas($id_partida, $id_fase, $id_camp, $row_partida['FKID_TIME1']);
      $estatisticas_time1 = [];
      if (is_string($result_estatisticas_time1)) {
        echo "<p> $result_estatisticas_time1 </p>";
      } else {
        if ($result_estatisticas_time1) {
          while ($row = $result_estatisticas_time1->fetch_assoc()) {
            // A chave do array será o tipo de evento, e o valor será a contagem
            $estatisticas_time1[$row['TIPO_EVENTO']] = $row['COUNT(*)'];
          }        
        }
      }
      $result_estatisticas_time2 = buscarEstatisticasAgrupadas($id_partida, $id_fase, $id_camp, $row_partida['FKID_TIME2']);
      $estatisticas_time2 = [];
      if (is_string($result_estatisticas_time2)){
        echo "<p> $result_estatisticas_time2 </p>";
      } else {
        if ($result_estatisticas_time2) {
          while ($row = $result_estatisticas_time2->fetch_assoc()) {
            $estatisticas_time2[$row['TIPO_EVENTO']] = $row['COUNT(*)'];
          }
        }
      }
    ?>
    <section class="section">
      <h2>Estatísticas</h2>
      <div class="stats-container">
          <div class="stat-row"
              data-stat="Chutes a Gol"
              data-left="<?php echo htmlspecialchars(isset($estatisticas_time1['Chute ao Gol']) ? $estatisticas_time1['Chute ao Gol'] : 0); ?>"
              data-right="<?php echo htmlspecialchars(isset($estatisticas_time2['Chute ao Gol']) ? $estatisticas_time2['Chute ao Gol'] : 0); ?>">
          </div>
          <div class="stat-row"
              data-stat="Faltas"
              data-left="<?php echo htmlspecialchars(isset($estatisticas_time1['Falta']) ? $estatisticas_time1['Falta'] : 0); ?>"
              data-right="<?php echo htmlspecialchars(isset($estatisticas_time2['Falta']) ? $estatisticas_time2['Falta'] : 0); ?>">
          </div>
          <div class="stat-row"
              data-stat="Cartões Amarelos"
              data-left="<?php echo htmlspecialchars(isset($estatisticas_time1['Cartão Amarelo']) ? $estatisticas_time1['Cartão Amarelo'] : 0); ?>"
              data-right="<?php echo htmlspecialchars(isset($estatisticas_time2['Cartão Amarelo']) ? $estatisticas_time2['Cartão Amarelo'] : 0); ?>">
          </div>
          <div class="stat-row"
              data-stat="Cartões Vermelhos"
              data-left="<?php echo htmlspecialchars(isset($estatisticas_time1['Cartão Vermelho']) ? $estatisticas_time1['Cartão Vermelho'] : 0); ?>"
              data-right="<?php echo htmlspecialchars(isset($estatisticas_time2['Cartão Vermelho']) ? $estatisticas_time2['Cartão Vermelho'] : 0); ?>">
          </div>
      </div>
  </section>
    
  
    <!-- ESCALAÇÃO -->
    <section class="section">
      <h2>Escalações</h2>
      <div class="lineup-container">
        <!-- TIME 1 -->
        <?php
          $result_jogadores_time1 = buscarJogadoresTime($id_camp, $row_partida['FKID_TIME1']);
          $list_jogadores = [];
          if (is_string($result_jogadores_time1)) {
            echo "<p>" . htmlspecialchars($result_jogadores_time1) . "</p>";
          } else {
            echo "<div class=\"lineup\">
                    <h3>" . htmlspecialchars($row_partida['TIME_1']) . "</h3>
                    <div class=\"players\">";
            while ($jogador = $result_jogadores_time1->fetch_assoc()) {
              $list_jogadores[$jogador['ID_JOGADOR']] = [
                'NOME' => $jogador['NOME'],
                'POSICAO' => $jogador['POSICAO'],
                'TIME' => $jogador['TIME'],
                'QTD_GOL' => $jogador['QTD_GOL'],
                'QTD_ASS' => $jogador['QTD_ASS'],
                'AGE' => $jogador['IDADE'],
                'ALTURA' => $jogador['ALTURA'],
                'FALTAS' => $jogador['FALTAS'],
                'CARTOES_AMARELOS' => $jogador['CARTOES_AMARELOS'],
                'CARTOES_VERMELHOS' => $jogador['CARTOES_VERMELHOS'],
                'NUMERO' => $jogador['NUMERO']
              ];
              echo "<button class=\"player-btn\" data-player=\"" . htmlspecialchars($jogador['ID_JOGADOR']) . "\">" . htmlspecialchars($jogador['NOME']) . "</button>";
            }
            echo "    </div>
                  </div>";
          }

          // TIME 2
          $result_jogadores_time2 = buscarJogadoresTime($id_camp, $row_partida['FKID_TIME2']);
          if (is_string($result_jogadores_time2)) {
            echo "<p>" . htmlspecialchars($result_jogadores_time2) . "</p>";
          } else {
            echo "<div class=\"lineup\">
                    <h3>" . htmlspecialchars($row_partida['TIME_2']) . "</h3>
                    <div class=\"players\">";
            while ($jogador = $result_jogadores_time2->fetch_assoc()) {
              $list_jogadores[$jogador['ID_JOGADOR']] = [
                'NOME' => $jogador['NOME'],
                'POSICAO' => $jogador['POSICAO'],
                'TIME' => $jogador['TIME'],
                'QTD_GOL' => $jogador['QTD_GOL'],
                'QTD_ASS' => $jogador['QTD_ASS'],
                'AGE' => $jogador['IDADE'],
                'ALTURA' => $jogador['ALTURA'],
                'FALTAS' => $jogador['FALTAS'],
                'CARTOES_AMARELOS' => $jogador['CARTOES_AMARELOS'],
                'CARTOES_VERMELHOS' => $jogador['CARTOES_VERMELHOS'],
                'NUMERO' => $jogador['NUMERO']
              ];
              echo "<button class=\"player-btn\" data-player=\"" . htmlspecialchars($jogador['ID_JOGADOR']) . "\">" . htmlspecialchars($jogador['NOME']) . "</button>";
            }
            echo "    </div>
                  </div>";
          }

          $players_json = json_encode($list_jogadores);
          echo "<script>const players = " . $players_json . ";</script>";
          
        ?>
      </div>
    </section>
    <div id="playerModal">
      <div>
        <button class="player-btn"onclick="closeModal()"><span>&#10005;</span></button>
        <h2 id="modalName"></h2>
        <p><strong>Número:</strong> <span id="modalNumero"></span></p>
        <p><strong>Idade:</strong> <span id="modalAge"></span></p>
        <p><strong>Altura:</strong> <span id="modalHeight"></span></p>
        <p><strong>Posição:</strong> <span id="modalPosicao"></span></p>
        <p><strong>Time:</strong> <span id="modalTeam"></span></p>
        <p><strong>Gols:</strong> <span id="modalGoals"></span></p>
        <p><strong>Assistências:</strong> <span id="modalAssistencias"></span></p>
        <p><strong>Cartões Amarelos:</strong> <span id="modalCartoesAmarelos"></span></p>
        <p><strong>Cartões Vermelhos:</strong> <span id="modalCartoesVermelhos"></span></p>
        <p><strong>Faltas:</strong> <span id="modalFaltas"></span></p>
      </div>
    </div>
  </main>

  <!-- ======= FOOTER ======= -->
  <footer id="contato" style="background: #0b0b14; color: #ccc; text-align: center; padding: 2rem; margin-top: 2rem;">
      <p>© 2025 Interclasse. Todos os direitos reservados.</p>
      <p>Participe do maior campeonato estudantil do Brasil!</p>
      <p>Contatos</p>
      <div style="margin-top: 1rem;">
        <a href="mailto:tccMain@gmail.com" style="color:#4a90e2; margin:0 10px;"><i class="fa-regular fa-envelope"></i></a>
      </div>
    </footer>

  <script src="../../js/api-poller.js"></script>
  <script>
    function toggleMenu() {
      const nav = document.getElementById("navLinks");
      nav.classList.toggle("show");
    }
    window.addEventListener('scroll', () => {
      const header = document.getElementById('header');
      if (window.scrollY > 20) {
        header.classList.remove('header-transparent');
        header.classList.add('header-scrolled');
      } else {
        header.classList.remove('header-scrolled');
        header.classList.add('header-transparent');
      }
    });
    document.querySelectorAll(".player-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const p = players[btn.dataset.player];
        if (!p) return;
        document.getElementById("modalName").textContent = p.NOME;
        document.getElementById("modalAge").textContent = p.AGE;
        document.getElementById("modalHeight").textContent = p.ALTURA;
        document.getElementById("modalTeam").textContent = p.TIME;
        document.getElementById("modalGoals").textContent = p.QTD_GOL;
        document.getElementById("modalAssistencias").textContent = p.QTD_ASS;
        document.getElementById("modalCartoesAmarelos").textContent = p.CARTOES_AMARELOS;
        document.getElementById("modalCartoesVermelhos").textContent = p.CARTOES_VERMELHOS;
        document.getElementById("modalFaltas").textContent = p.FALTAS;
        document.getElementById("modalPosicao").textContent = p.POSICAO;
        document.getElementById("modalNumero").textContent = p.NUMERO;
        document.getElementById("playerModal").style.display = "flex";
      });
    });

    function closeModal() {
      document.getElementById("playerModal").style.display = "none";
    }

    function renderStats() {
    document.querySelectorAll('.stat-row').forEach(row => {
      const label = row.dataset.stat;
      const left = parseInt(row.dataset.left);
      const right = parseInt(row.dataset.right);
      const total = left + right || 1;

      const leftPercent = (left / total) * 100;
      const rightPercent = (right / total) * 100;

      row.innerHTML = `
        <span class="label">${label}</span>
        <div class="stat-bar">
          <div class="bar-fill" style="width: ${leftPercent}%"></div>
          <div class="bar-fill right" style="width: ${rightPercent}%"></div>
        </div>
        <div class="stat-values-below">
          <span class="left-value">${left}</span>
          <span class="right-value">${right}</span>
        </div>
      `;
    });
  }

  renderStats();

  // Sistema de polling para atualização automática dos dados da partida
  let partidaPoller = null;
  
  // Inicializa o polling quando a página carrega
  document.addEventListener('DOMContentLoaded', function() {
    const partidaId = <?php echo json_encode($id_partida); ?>;
    const campeonatoId = <?php echo json_encode($id_camp); ?>;
    const faseId = <?php echo json_encode($id_fase); ?>;
    
    if (partidaId && campeonatoId && faseId) {
      partidaPoller = createPartidaPoller(partidaId, campeonatoId, faseId, {
        interval: 2000, // Atualiza a cada 2 segundos (mais frequente para partidas ao vivo)
        onDataUpdate: function(data) {
          updatePartidaData(data);
        },
        onError: function(error, consecutiveErrors) {
          console.warn(`Erro na atualização da partida (${consecutiveErrors}):`, error.message);
          
          // Mostra notificação discreta após alguns erros
          if (consecutiveErrors >= 3) {
            showUpdateError();
          }
        },
        onStart: function() {
          console.log('Atualização da partida iniciada');
          showUpdateStatus('Atualização ao vivo ativa');
        },
        onStop: function() {
          console.log('Atualização da partida parada');
          showUpdateStatus('Atualização ao vivo pausada');
        }
      });
      
      // Inicia o polling
      partidaPoller.start();
      
      // Para o polling quando a página é fechada ou navegada
      window.addEventListener('beforeunload', function() {
        if (partidaPoller) {
          partidaPoller.stop();
        }
      });
      
      // Pausa/retoma polling quando a aba perde/ganha foco
      document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
          if (partidaPoller && partidaPoller.isRunning) {
            partidaPoller.stop();
          }
        } else {
          if (partidaPoller && !partidaPoller.isRunning) {
            partidaPoller.start();
          }
        }
      });
    }
  });

  // Função para atualizar os dados da partida na interface
  function updatePartidaData(data) {
    try {
      // Atualiza placar principal
      if (data.placar) {
        updateScoreboard(data.placar);
      }

      // Atualiza linha do tempo de eventos
      if (data.eventos) {
        updateTimeline(data.eventos);
      }

      // Atualiza estatísticas
      if (data.estatisticas) {
        updateStatistics(data.estatisticas);
      }

      // Atualiza status da partida
      if (data.status) {
        updateMatchStatus(data.status);
      }

      // Atualiza dados dos jogadores
      if (data.jogadores) {
        updatePlayersData(data.jogadores);
      }

      console.log('Dados da partida atualizados com sucesso');
      
    } catch (error) {
      console.error('Erro ao atualizar interface da partida:', error);
    }
  }

  // Função para atualizar o placar principal
  function updateScoreboard(placar) {
    // Garante que o placar é válido
    if (!placar || typeof placar.time1 === 'undefined' || typeof placar.time2 === 'undefined') {
      console.warn("Placar inválido ou incompleto:", placar);
      return;
    }

    const scoreNumbers = document.querySelectorAll('.score-number');
    if (scoreNumbers.length < 2) {
      console.warn("Elementos de placar não encontrados no DOM.");
      return;
    }

    const [score1, score2] = scoreNumbers;

    // Atualiza Time 1
    const novoPlacar1 = placar.time1.toString();
    if (score1.textContent !== novoPlacar1) {
      score1.textContent = novoPlacar1;
      score1.style.backgroundColor = '#4a90e2';
      setTimeout(() => score1.style.backgroundColor = '', 1000);
    }

    // Atualiza Time 2
    const novoPlacar2 = placar.time2.toString();
    if (score2.textContent !== novoPlacar2) {
      score2.textContent = novoPlacar2;
      score2.style.backgroundColor = '#4a90e2';
      setTimeout(() => score2.style.backgroundColor = '', 1000);
    }
  }


  // Função para atualizar a linha do tempo
  function updateTimeline(eventos) {
    const timeline = document.querySelector('.timeline');
    if (!timeline) {
      console.warn("Elemento .timeline não encontrado no DOM.");
      return;
    }

    // Garante que 'eventos' é um array
    if (!Array.isArray(eventos)) {
      console.warn("Eventos inválidos:", eventos);
      return;
    }

    // Evita atualizar se não há eventos
    if (eventos.length === 0) {
      timeline.innerHTML = "<p style='text-align: center'>Ainda não há eventos</p>";
      return;
    }

    // Gera novo conteúdo sem recriar o DOM desnecessariamente
    const novoHTML = eventos.map(evento => {
      const lado = evento.lado || "neutro";
      const classe = evento.classe || "";
      const icone = evento.icone || "⚽";
      const tipo = evento.tipo || "Evento";
      const jogador = evento.jogador ? ` de ${evento.jogador}` : "";
      const minuto = evento.minuto !== undefined ? `<span>${evento.minuto}'</span>` : "";

      return `
        <div class="evento ${lado} ${classe}">
          ${icone} ${tipo}${jogador}
          ${minuto}
        </div>
      `;
    }).join("");

    // Atualiza o HTML da timeline
    timeline.innerHTML = novoHTML;
  }


  // Função para atualizar estatísticas
  function updateStatistics(estatisticas) {
    if (!estatisticas || typeof estatisticas !== 'object') return;

    document.querySelectorAll('.stat-row').forEach(row => {
      const statType = row.dataset.stat;
      const statData = estatisticas[statType];
      
      if (!statData) return;

      const left = Number(statData.time1) || 0;
      const right = Number(statData.time2) || 0;
      const total = left + right || 1;

      const leftPercent = (left / total) * 100;
      const rightPercent = (right / total) * 100;

      // Atualiza só se houver mudança (evita repintar sempre)
      const oldLeft = row.dataset.left;
      const oldRight = row.dataset.right;

      if (oldLeft != left || oldRight != right) {
        row.dataset.left = left;
        row.dataset.right = right;

        row.innerHTML = `
          <span class="label">${statType}</span>
          <div class="stat-bar">
            <div class="bar-fill" style="width: ${leftPercent}%"></div>
            <div class="bar-fill right" style="width: ${rightPercent}%"></div>
          </div>
          <div class="stat-values-below">
            <span class="left-value">${left}</span>
            <span class="right-value">${right}</span>
          </div>
        `;
      }
    });
  }


  // Função para atualizar status da partida
  function updateMatchStatus(status) {
    const statusElement = document.querySelector('.match-status, .live-badge');
    if (!statusElement) return;

    const isLive = status === 'I';
    const isEnded = status === 'T';

    if (isEnded) {
      statusElement.textContent = 'Encerrado';
      statusElement.classList.remove('live-badge');
      statusElement.classList.add('match-status');
    } else if (isLive) {
      statusElement.textContent = '● AO VIVO';
      statusElement.classList.remove('match-status');
      statusElement.classList.add('live-badge');
    } else {
      // Oculta se não houver status conhecido
      statusElement.style.display = 'block';
      statusElement.textContent = 'Não iniciada';
      statusElement.classList.remove('live-badge');
      statusElement.classList.add('match-status');
    }
  }


  // Função para atualizar dados dos jogadores
  function updatePlayersData(jogadores) {
    if (!window.players) window.players = {};

    if (jogadores.time1) {
      window.players.time1 = { ...jogadores.time1 };
    }

    if (jogadores.time2) {
      window.players.time2 = { ...jogadores.time2 };
    }
  }


  // Função para mostrar status de atualização
  function showUpdateStatus(message) {
    // Remove notificação anterior se existir
    const existingNotification = document.querySelector('.update-notification');
    if (existingNotification) {
      existingNotification.remove();
    }

    const notification = document.createElement('div');
    notification.className = 'update-notification';
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: rgba(0, 255, 231, 0.9);
      color: #000;
      padding: 10px 15px;
      border-radius: 5px;
      font-size: 14px;
      z-index: 1000;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove após 3 segundos
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 3000);
  }

  // Função para mostrar erro de atualização
  function showUpdateError() {
    const notification = document.createElement('div');
    notification.className = 'update-error';
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: rgba(255, 0, 0, 0.9);
      color: white;
      padding: 10px 15px;
      border-radius: 5px;
      font-size: 14px;
      z-index: 1000;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    `;
    notification.textContent = 'Erro na atualização ao vivo';
    
    document.body.appendChild(notification);
    
    // Remove após 5 segundos
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 5000);
  }

  // Função para controlar o polling manualmente (útil para debug)
  window.togglePolling = function() {
    if (partidaPoller) {
      if (partidaPoller.isRunning) {
        partidaPoller.stop();
      } else {
        partidaPoller.start();
      }
    }
  };

  // Função para forçar atualização imediata
  window.forceUpdate = function() {
    if (partidaPoller) {
      partidaPoller.forceRequest();
    }
  };

  </script>
</body>
</html>
