<?php
  require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesBuscaCliente.php';

  if (isset($_GET['id_camp']) & isset($_GET['id_time'])) {
    $id_camp = $_GET['id_camp'];
    $id_time = $_GET['id_time'];
  }

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Interclasse - Informações do Time</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Rajdhani:wght@500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="../../CSS/style.css">
  <link rel="stylesheet" href="../../CSS/telatime.css">
  <!-- CSS MODERNO - DESCOMENTE A LINHA ABAIXO PARA ATIVAR O NOVO DESIGN -->
  <link rel="stylesheet" href="../../CSS/cliente_moderno.css">
   <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
   <script src="../../js/api-poller.js"></script>
    

</head>
<body>
<div class="overlay" id="menuOverlay" onclick="toggleMenu()"></div>
  
  <!-- ======= HEADER ======= -->
  <header id="header" class="header-transparent">
    <div style="display: flex; align-items: center; gap: 2rem; flex-wrap: wrap;">
      <a href="../../index.php" style="text-decoration: none;">
      <div onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'" class="logo">
          <img src="../../Imagens/Logo.png" alt="Logo Interclasse" style="height: 48px; border-radius: 100%; filter: drop-shadow(0 0 5px rgba(255,255,255,0.5));">
          <span class="titulo_real">INTERCLASSE</span>
        </div>
      </a>
      <button class="menu-toggle" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
      <nav id="navLinks" style="display: flex; flex-wrap: wrap; gap: 1.5rem; font-weight: bold; font-size: 1rem;">
        <a href="../login.php" class="nav-link">ACESSO ESCOLAR</a>
      </nav>
    </div>
  </header>
<main>  
  <?php
    $result_time = buscarTimeEstatisticas($id_time, $id_camp);
    if (is_string($result_time)) {
      echo "<p>Time não encontrado.</p>";
    } else {
        echo "<section class=\"section cabecalho\">";
      $row = $result_time->fetch_assoc();
        echo "<h1>" . htmlspecialchars($row['TIME']) . " - " . htmlspecialchars($row['SERIE']) . "</h1>";
        echo "<h2>" . htmlspecialchars($row['ESCOLA']) . "</h2>";
        echo "<h3>" . htmlspecialchars($row['ANO']) . "</h3>";
      echo "</section>";
    }
  ?>
  

  <section class="section">
    <h2 style="color: #4a90e2;">Estatísticas</h2>
    <section style="display: flex; flex-direction: column; justify-content: center; align-items: center; ">
      <div class="vers_mob">
        <div style="width: 15em;">
          <?php
            echo "<p style=\"display:none;\" id=\"graphic_matches\"><strong>Partidas Jogadas:</strong> " . htmlspecialchars($row['Npartidas']) . "</p>";
            echo "<p><strong>Partidas:</strong> " . htmlspecialchars($row['Npartidas']) . "</p>";
            echo "<p id=\"graphic_wins\"><strong>Vitórias:</strong> " . htmlspecialchars($row['VITORIAS']) . "</p>";
            echo "<p id=\"graphic_losses\"><strong>Derrotas:</strong> " . htmlspecialchars($row['DERROTA']) . "</p>";

        echo "</div>
        <div style=\"width: 15em;\">";
          echo "<p><strong>Jogadores:</strong> " . htmlspecialchars($row['Njogadores']) . "</p>";
          echo "<p><strong>Gols Marcados:</strong> " . htmlspecialchars($row['GolsMarcados']) . "</p>";
          echo "<p><strong>Gols Sofridos:</strong> " . htmlspecialchars($row['GolsSofridos']) . "</p>";

        echo"</div>
        <div style=\"width: 15em;\">";
          echo "<p><strong>Faltas</strong> " . htmlspecialchars($row['FALTA']) . "</p>";
          echo "<p><strong>Cartões Amarelos</strong> " . htmlspecialchars($row['CartoesAmarelos']) . "</p>";
          echo "<p><strong>Cartões Vermelhos:</strong> " . htmlspecialchars($row['CartoesVermelhos']) . "</p>

        </div>
      </div>";
          ?>
      
      <div class="graf" id="container"></div><!--gráficos-->
    </section>    
  </section>

  <section class="section">
    <h2 style="color: #4a90e2;">Escalação</h2>
    <div class="carousel-wrapper" style="display: flex; flex-direction: column;">
      <?php
        $result_players = buscarJogadoresTime($id_camp, $id_time);
        $players = [];
        if (!is_string($result_players)) {
          while ($row = $result_players->fetch_assoc()) {
            $players[] = [
              'NOME' => $row['NOME'],
              'IDADE' => $row['IDADE'],
              'QTD_GOL' => $row['QTD_GOL'],
              'QTD_ASS' => $row['QTD_ASS'],
              'FALTAS' => $row['FALTAS'],
              'CARTOES_AMARELOS' => $row['CARTOES_AMARELOS'],
              'CARTOES_VERMELHOS' => $row['CARTOES_VERMELHOS'],
            ];
          }
        }
        echo '<div class="carousel-container"><div class="cards-carousel" id="cardsCarousel"></div></div>';
      ?>
      <div style="display: flex; flex-direction: row; gap: 7em; justify-content: center; margin-top: 2em;">
        <button class="carousel-btn left" onclick="scrollCarousel(-1)"><i class="fas fa-chevron-left"></i></button>
        <button class="carousel-btn right" onclick="scrollCarousel(1)"><i class="fas fa-chevron-right"></i></button>
      </div>
    </div>   
  </section>

  <script>
    // Renderização dinâmica dos cartões de jogadores (conteúdo preservado)
    (function renderPlayers(){
      const data = <?php echo json_encode(isset($players) ? $players : []); ?>;
      const list = document.getElementById('cardsCarousel');
      if (!list) return;
      list.innerHTML = '';
      if (!Array.isArray(data) || data.length === 0) {
        const empty = document.createElement('div');
        empty.style.cssText = 'color:#ccc;text-align:center;width:100%;padding:1rem;';
        empty.textContent = 'Nenhum jogador encontrado.';
        list.appendChild(empty);
        return;
      }
      const frag = document.createDocumentFragment();
      data.forEach((row) => {
        const card = document.createElement('div');
        card.className = 'card live-card is-live';
        const content = document.createElement('div');
        content.className = 'card-content';
        const h2 = document.createElement('h2');
        h2.id = 'modalName';
        h2.textContent = row.NOME;
        const p1 = document.createElement('p');
        p1.innerHTML = '<strong>Idade:</strong> ' + (row.IDADE ? row.IDADE : 0);
        const p2 = document.createElement('p');
        p2.innerHTML = '<strong>Gols:</strong> ' + (row.QTD_GOL ? row.QTD_GOL : 0);
        const p3 = document.createElement('p');
        p3.innerHTML = '<strong>Assistências:</strong> ' + (row.QTD_ASS ? row.QTD_ASS : 0);
        const p4 = document.createElement('p');
        p4.innerHTML = '<strong>Faltas:</strong> ' + (row.FALTAS ? row.FALTAS : 0);
        const p5 = document.createElement('p');
        p5.innerHTML = '<strong>Cartões Amarelos:</strong> ' + (row.CARTOES_AMARELOS ? row.CARTOES_AMARELOS : 0);
        const p6 = document.createElement('p');
        p6.innerHTML = '<strong>Cartões Vermelhos:</strong> ' + (row.CARTOES_VERMELHOS ? row.CARTOES_VERMELHOS : 0);
        content.append(h2, p1, p2, p3, p4, p5, p6);
        card.appendChild(content);
        frag.appendChild(card);
      });
      list.appendChild(frag);
    })();
  </script>

  <section class="section">
    <?php
      $result_artilheiros = buscarJogadoresTime($id_camp, $id_time);
      
      if (is_string($result_artilheiros)) {
        echo "<p>Nenhum artilheiro registrado.</p>";
      } else {
        $artilheiros = [];
        while ($row = $result_artilheiros->fetch_assoc()) {
          $artilheiros[] = $row;
        }
        usort($artilheiros, function($a, $b) {
          if ($b['QTD_GOL'] == $a['QTD_GOL']) {
            return 0;
          }
          return ($b['QTD_GOL'] < $a['QTD_GOL']) ? -1 : 1;
        });
      }
    ?>
    <h2 style="color: #4a90e2;">Artilheiros</h2>
    <section class="painel-tabela">
      <div id="artilheiros" class="tabela-conteudo" style="display: block;">
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Nome</th>
              <th>Gols</th>
            </tr>
          </thead>
          <tbody>
            <?php
              if (is_string($artilheiros)) {
                  echo "<tr><td colspan='3'>Nenhum artilheiro registrado.</td></tr>";
              } else {
                $pos = 1;
                foreach ($artilheiros as $jogador) {

                  $icone = "";
                  if ($pos == 1) $icone = "🥇";
                  elseif ($pos == 2) $icone = "🥈";
                  elseif ($pos == 3) $icone = "🥉";

                  echo "<tr>
                          <td>{$icone} {$pos}º</td>
                          <td>{$jogador["NOME"]}</td>
                          <td>{$jogador["QTD_GOL"]}</td>
                        </tr>";
                  $pos++;
                }
              }
            ?>
          </tbody>
        </table>
      </div>
    </section>
  </section>  

  <!--<div id="playerModal">
    <div>
      <button class="player-btn"onclick="closeModal()"><span>&#10005;</span></button>
      <h2 id="modalName"></h2>
  
      <p><strong>Idade:</strong> <span id="modalAge"></span></p>
      <p><strong>Faltas:</strong> <span id="modalFouls"></span></p>
      <p><strong>Time:</strong> <span id="modalTeam"></span></p>
      <p><strong>Gols:</strong> <span id="modalGoals"></span></p>
      <p><strong>Cartões Amarelos:</strong> <span id="modalYellow"></span></p>
      <p><strong>Cartões Vermelhos:</strong> <span id="modalRed"></span></p>
      
    </div>
  </div>-->
</main>

<!-- ======= FOOTER ======= -->
<footer id="contato" style="background: #0b0b14; color: #ccc; text-align: center; padding: 2rem; margin-top: 2rem;">
      <p>© 2025 Interclasse. Todos os direitos reservados.</p>
      <p>Participe do maior campeonato estudantil do Brasil!</p>
      <p>Contatos</p>
      <div style="margin-top: 1rem;">
        <a href="mailto:tccMain@gmail.com" style="color:#4a90e2; margin:0 10px;"><i class="fa-regular fa-envelope"></i></a>
      </div>
    </footer>

<script>

  function toggleMenu() {
    const nav = document.getElementById("navLinks");
    nav.classList.toggle("show");
  }
  window.addEventListener('scroll', () => {
    const header = document.getElementById('header');
    if (window.scrollY > 20) {
      header.classList.remove('header-transparent');
      header.classList.add('header-scrolled');
    } else {
      header.classList.remove('header-scrolled');
      header.classList.add('header-transparent');
    }
  });

  var losses= document.getElementById("graphic_losses").textContent;
  var wins=document.getElementById("graphic_wins").textContent;
  var matches=document.getElementById("graphic_matches").textContent;
  //var draws=document.getElementById("graphic_draws").textContent;

  var total = parseInt(matches.replace(/[^0-9]/g,'')) || 0;
  var vit = parseInt(wins.replace(/[^0-9]/g,'')) || 0;
  var der = parseInt(losses.replace(/[^0-9]/g,'')) || 0;
  
  var vitPerc = total > 0 ? (vit / total) * 100 : 0;
  var derPerc = total > 0 ? (der / total) * 100 : 0;

  console.log(total, vit, der);

  google.charts.load('current', {packages: ['corechart', 'bar']});
  google.charts.setOnLoadCallback(drawBasic);

  function drawBasic() {

    // var data = new google.visualization.DataTable();
    // data.addColumn('string', 'Partida');
    // data.addColumn('number', 'Quantidade');

    // data.addRows([
    //   ['Partidas',parseInt(matches.replace(/[^0-9]/g,'')),'white'],
    //   ['Vitórias',parseInt(wins.replace(/[^0-9]/g,''))],
    //   ['Empates',parseInt(draws.replace(/[^0-9]/g,''))],
    //   ['Derrotas',parseInt(losses.replace(/[^0-9]/g,''))],
    // ]);
    var data = google.visualization.arrayToDataTable([
      ['Tipo', 'Quantidade', { role: 'style' } ],
      //['Partidas',parseInt(matches.replace(/[^0-9]/g,'')) , 'fill-color:blue;'],
      ['Vitórias',vitPerc , 'fill-color:#007d55'],
      //['Empates', parseInt(draws.replace(/[^0-9]/g,'')), 'fill-color:#9ca300'],
      ['Derrotas',derPerc , 'fill-color:#a30000'],
    ]);

    var options = {
      'legend':'none',
      titleTextStyle:{
        color:'#4a90e2',
        fontSize:30,
        fontName:'Rajdhani'
      },
      title: 'Aproveitamento (%) de ' + total + ' partidas',
      bar: {groupWidth: "80%"},
      hAxis: {
        textStyle:{color: '#FFF'},
        titleTextStyle:{
          color:'white',
        
        },
        title: 'Resultados'
      },
      
      vAxis: {
        title: 'Aproveitamento (%)',
        textStyle:{color: '#FFF'},
        titleTextStyle:{
          color:'white',
        },
        viewWindow: {
          min: 0,     // Defina o valor mínimo
          max: 100   // Aumente o valor máximo para escalar o eixo
        },
        format: '#\'%\''
      },
      
      backgroundColor:{
        fill: 'transparent',
        strokeWidth:0,
        stroke:'#000a6f'
      }
    };

    var chart = new google.visualization.ColumnChart(
      document.getElementById('container'));

    chart.draw(data, options);
  }

  // Sistema de polling para atualização automática dos dados do time
  let timePoller = null;
  
  // Inicializa o polling quando a página carrega
  document.addEventListener('DOMContentLoaded', function() {
    const timeId = <?php echo json_encode($id_time); ?>;
    const campeonatoId = <?php echo json_encode($id_camp); ?>;
    
    if (timeId && campeonatoId) {
      timePoller = createTimePoller(timeId, campeonatoId, {
        interval: 10000, // Atualiza a cada 10 segundos (menos frequente para dados de time)
        onDataUpdate: function(data) {
          updateTimeData(data);
        },
        onError: function(error, consecutiveErrors) {
          console.warn(`Erro na atualização do time (${consecutiveErrors}):`, error.message);
          
          // Mostra notificação discreta após alguns erros
          if (consecutiveErrors >= 3) {
            showUpdateError();
          }
        },
        onStart: function() {
          console.log('Atualização do time iniciada');
          showUpdateStatus('Atualização automática ativa');
        },
        onStop: function() {
          console.log('Atualização do time parada');
          showUpdateStatus('Atualização automática pausada');
        }
      });
      
      // Inicia o polling
      timePoller.start();
      
      // Para o polling quando a página é fechada ou navegada
      window.addEventListener('beforeunload', function() {
        if (timePoller) {
          timePoller.stop();
        }
      });
      
      // Pausa/retoma polling quando a aba perde/ganha foco
      document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
          if (timePoller && timePoller.isRunning) {
            timePoller.stop();
          }
        } else {
          if (timePoller && !timePoller.isRunning) {
            timePoller.start();
          }
        }
      });
    }
  });

  // Função para atualizar os dados do time na interface
  function updateTimeData(data) {
    try {
      // Atualiza estatísticas do time
      if (data.estatisticas) {
        updateTeamStatistics(data.estatisticas);
      }

      // Atualiza lista de artilheiros
      if (data.artilheiros) {
        updateTeamScorers(data.artilheiros);
        updateTeamPlayers(data.artilheiros);
      }

      // Atualiza gráfico de aproveitamento
      if (data.aproveitamento) {
        updatePerformanceChart(data.aproveitamento);
      }

      console.log('Dados do time atualizados com sucesso');
      
    } catch (error) {
      console.error('Erro ao atualizar interface do time:', error);
    }
  }

  // Função para atualizar estatísticas do time
  function updateTeamStatistics(estatisticas) {
    const statsContainer = document.querySelector('.vers_mob');
    if (!statsContainer) return;

    // Atualiza partidas jogadas
    const partidasElements = statsContainer.querySelectorAll('p');
    partidasElements.forEach(element => {
      if (element.textContent.includes('Partidas:')) {
        element.innerHTML = `<strong>Partidas:</strong> ${estatisticas.partidas}`;
      }
      if (element.textContent.includes('Vitórias:')) {
        element.innerHTML = `<strong>Vitórias:</strong> ${estatisticas.vitorias}`;
      }
      if (element.textContent.includes('Derrotas:')) {
        element.innerHTML = `<strong>Derrotas:</strong> ${estatisticas.derrotas}`;
      }
      if (element.textContent.includes('Gols Marcados:')) {
        element.innerHTML = `<strong>Gols Marcados:</strong> ${estatisticas.golsMarcados}`;
      }
      if (element.textContent.includes('Gols Sofridos:')) {
        element.innerHTML = `<strong>Gols Sofridos:</strong> ${estatisticas.golsSofridos}`;
      }
      if (element.textContent.includes('Faltas')) {
        element.innerHTML = `<strong>Faltas</strong> ${estatisticas.faltas}`;
      }
      if (element.textContent.includes('Cartões Amarelos')) {
        element.innerHTML = `<strong>Cartões Amarelos</strong> ${estatisticas.cartoesAmarelos}`;
      }
      if (element.textContent.includes('Cartões Vermelhos:')) {
        element.innerHTML = `<strong>Cartões Vermelhos:</strong> ${estatisticas.cartoesVermelhos}`;
      }
      if (element.textContent.includes('Jogadores:')) {
        element.innerHTML = `<strong>Jogadores:</strong> ${estatisticas.jogadores}`;
      }
    });
  }

  // Função para atualizar informações de jogadores
  function updateTeamPlayers(jogadores) { 
    const list = document.getElementById('cardsCarousel');
    if (!list) return;
    list.innerHTML = '';
    if (!Array.isArray(jogadores) || jogadores.length === 0) {
      const empty = document.createElement('div');
      empty.style.cssText = 'color:#ccc;text-align:center;width:100%;padding:1rem;';
      empty.textContent = 'Nenhum jogador encontrado.';
      list.appendChild(empty);
      return;
    } else {
      jogadores.forEach(function(jogador, index) {
        const card = document.createElement('div');
        card.className = 'card live-card is-live';
        const content = document.createElement('div');
        content.className = 'card-content';
        const h2 = document.createElement('h2');
        h2.textContent = jogador.NOME;
        const p1 = document.createElement('p');
        p1.innerHTML = '<strong>Idade:</strong> ' + (jogador.IDADE ? jogador.IDADE : 0);
        const p2 = document.createElement('p');
        p2.innerHTML = '<strong>Gols:</strong> ' + (jogador.QTD_GOL ? jogador.QTD_GOL : 0);
        const p3 = document.createElement('p');
        p3.innerHTML = '<strong>Assistências:</strong> ' + (jogador.QTD_ASS ? jogador.QTD_ASS : 0);
        const p4 = document.createElement('p');
        p4.innerHTML = '<strong>Faltas:</strong> ' + (jogador.FALTAS ? jogador.FALTAS : 0);
        const p5 = document.createElement('p');
        p5.innerHTML = '<strong>Cartões Amarelos:</strong> ' + (jogador.CARTOES_AMARELOS ? jogador.CARTOES_AMARELOS : 0);
        const p6 = document.createElement('p');
        p6.innerHTML = '<strong>Cartões Vermelhos:</strong> ' + (jogador.CARTOES_VERMELHOS ? jogador.CARTOES_VERMELHOS : 0);
        content.append(h2, p1, p2, p3, p4, p5, p6);
        card.appendChild(content);
        list.appendChild(card);
      });
    }    
  }

  // Função para atualizar lista de artilheiros
  function updateTeamScorers(artilheiros) {
    const tbody = document.querySelector('#artilheiros tbody');
    if (!tbody) return;

    tbody.innerHTML = '';
    
    artilheiros.forEach(function(jogador, index) {
      const pos = index + 1;
      let icone = '';
      if (pos === 1) icone = '🥇';
      else if (pos === 2) icone = '🥈';
      else if (pos === 3) icone = '🥉';

      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${icone} ${pos}º</td>
        <td>${jogador.NOME}</td>
        <td>${jogador.QTD_GOL}</td>
      `;
      tbody.appendChild(row);
    });
  }

  // Função para atualizar gráfico de aproveitamento
  function updatePerformanceChart(aproveitamento) {
    try {
      const data = google.visualization.arrayToDataTable([
        ['Tipo', 'Quantidade', { role: 'style' } ],
        ['Vitórias', aproveitamento.vitoriasPercent, 'fill-color:#007d55'],
        ['Derrotas', aproveitamento.derrotasPercent, 'fill-color:#a30000'],
      ]);

      const options = {
        'legend':'none',
        titleTextStyle:{
          color:'#4a90e2',
          fontSize:30,
          fontName:'Rajdhani'
        },
        title: `Aproveitamento (%) de ${aproveitamento.totalPartidas} partidas`,
        bar: {groupWidth: "80%"},
        hAxis: {
          textStyle:{color: '#FFF'},
          titleTextStyle:{
            color:'white',
          },
          title: 'Resultados'
        },
        vAxis: {
          title: 'Aproveitamento (%)',
          textStyle:{color: '#FFF'},
          titleTextStyle:{
            color:'white',
          },
          viewWindow: {
            min: 0,
            max: 100
          },
          format: '#\'%\''
        },
        backgroundColor:{
          fill: 'transparent',
          strokeWidth:0,
          stroke:'#000a6f'
        }
      };

      const chart = new google.visualization.ColumnChart(
        document.getElementById('container'));

      chart.draw(data, options);
    } catch (error) {
      console.error('Erro ao atualizar gráfico:', error);
    }
  }

  // Função para mostrar status de atualização
  function showUpdateStatus(message) {
    // Remove notificação anterior se existir
    const existingNotification = document.querySelector('.update-notification');
    if (existingNotification) {
      existingNotification.remove();
    }

    const notification = document.createElement('div');
    notification.className = 'update-notification';
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: rgba(0, 255, 231, 0.9);
      color: #000;
      padding: 10px 15px;
      border-radius: 5px;
      font-size: 14px;
      z-index: 1000;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove após 3 segundos
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 3000);
  }

  // Função para mostrar erro de atualização
  function showUpdateError() {
    const notification = document.createElement('div');
    notification.className = 'update-error';
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: rgba(255, 0, 0, 0.9);
      color: white;
      padding: 10px 15px;
      border-radius: 5px;
      font-size: 14px;
      z-index: 1000;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    `;
    notification.textContent = 'Erro na atualização automática';
    
    document.body.appendChild(notification);
    
    // Remove após 5 segundos
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 5000);
  }

  // Função para controlar o polling manualmente (útil para debug)
  window.togglePolling = function() {
    if (timePoller) {
      if (timePoller.isRunning) {
        timePoller.stop();
      } else {
        timePoller.start();
      }
    }
  };

  // Função para forçar atualização imediata
  window.forceUpdate = function() {
    if (timePoller) {
      timePoller.forceRequest();
    }
  };

  // ==============================
  // Carrossel de jogadores (igual ao padrão da index, sem jQuery)
  // ==============================
  (function initPlayersCarousel(){
    const carousel = document.getElementById('cardsCarousel');
    const container = carousel ? carousel.closest('.carousel-container') : null;
    const buttonsWrapper = container ? container.parentElement : null;
    const leftBtn = buttonsWrapper ? buttonsWrapper.querySelector('.carousel-btn.left') : null;
    const rightBtn = buttonsWrapper ? buttonsWrapper.querySelector('.carousel-btn.right') : null;
    if (!carousel || !leftBtn || !rightBtn) return;

    let autoplayTimer = null;

    function getGapPx() {
      const styles = window.getComputedStyle(carousel);
      const gap = styles.getPropertyValue('gap') || styles.getPropertyValue('column-gap') || '0px';
      const parsed = parseFloat(gap);
      return Number.isFinite(parsed) ? parsed : 0;
    }

    function getCardWidth() {
      const firstCard = carousel.querySelector('.live-card');
      if (!firstCard) return 300;
      return firstCard.getBoundingClientRect().width;
    }

    function getScrollStep() {
      const gap = getGapPx();
      const card = getCardWidth();
      const viewport = carousel.clientWidth;
      const perView = Math.max(1, Math.floor((viewport + gap) / (card + gap)));
      return perView * (card + gap);
    }

    function updateNavButtons() {
      const maxLeft = Math.max(0, carousel.scrollWidth - carousel.clientWidth);
      const atStart = carousel.scrollLeft <= 0;
      const atEnd = carousel.scrollLeft >= (maxLeft - 1);
      leftBtn.disabled = atStart;
      rightBtn.disabled = atEnd;
    }

    function scrollStep(direction) {
      const step = getScrollStep();
      const next = carousel.scrollLeft + direction * step;
      carousel.scrollTo({ left: next, behavior: 'smooth' });
      setTimeout(updateNavButtons, 350);
    }

    // Compatível com onclick existente nos botões
    window.scrollCarousel = function(direction){
      scrollStep(direction);
    };

    leftBtn.addEventListener('click', () => scrollStep(-1));
    rightBtn.addEventListener('click', () => scrollStep(1));

    // Atualiza estado em scroll/resize
    let rafId = null;
    carousel.addEventListener('scroll', () => {
      if (rafId) return;
      rafId = requestAnimationFrame(() => { updateNavButtons(); rafId = null; });
    });
    window.addEventListener('resize', () => {
      clearTimeout(window.__ttcResizeTimer);
      window.__ttcResizeTimer = setTimeout(updateNavButtons, 150);
    });

    // Autoplay opcional (5s) com pausa no hover do container
    function startAutoplay(){
      if (autoplayTimer) return;
      autoplayTimer = setInterval(() => {
        const maxLeft = Math.max(0, carousel.scrollWidth - carousel.clientWidth);
        if (carousel.scrollLeft >= (maxLeft - 1)) {
          carousel.scrollTo({ left: 0, behavior: 'smooth' });
        } else {
          scrollStep(1);
        }
      }, 5000);
    }
    function stopAutoplay(){
      if (!autoplayTimer) return;
      clearInterval(autoplayTimer);
      autoplayTimer = null;
    }
    if (container) {
      container.addEventListener('mouseenter', stopAutoplay);
      container.addEventListener('mouseleave', startAutoplay);
    }

    // Init
    updateNavButtons();
    startAutoplay();
  })();

</script>

</body>
</html>
