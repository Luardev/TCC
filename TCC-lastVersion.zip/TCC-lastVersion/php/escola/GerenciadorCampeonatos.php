<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/auth.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Gerenciamento de Campeonato</title>
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <link rel="stylesheet" href="../../CSS/gerenciador_unificado.css">
    <?php require_once '../../imports.php'?>
    <script src="js/cadescola.js?<?php echo time() ?>"></script>
  </head>
  <body>
    <header>
      <div class="logo">
        <img
          src="https://cdn-icons-png.flaticon.com/512/3661/3661392.png"
          alt="Logo"
        />
        <span class="titulo_real">Painel de Gerenciamento</span>
      </div>

      <nav>
        <a href="php/escola/GerenciadorCampeonatos.php">Início</a>
        <a href="index.php">Sair</a>
      </nav>
    </header>

    <main>
      <div class="dashboard-header">
        <h1>Gerenciamento de Campeonato</h1>
      </div>

      <div class="grid-container">
        <div class="card">
          <i class="fa-solid fa-trophy"></i>
          <h3>Criar Campeonato</h3>
          <p>
            Cadastre um novo campeonato, defina o nome, as equipes participantes
            e as regras.
          </p>
          <button><a style="color:white; text-decoration:none;" href="#" class='btn btn-action btn-create d-none d-md-block' data-bs-toggle='modal' data-bs-target='#exampleModal'>Criar</a></button>
        </div>
        
        <div class="card">
          <i class="fa-solid fa fa-trash"></i>
          <h3>Remover Campeonatos</h3>
          <p>
            Remova campeonatos existentes.
          </p>
          <button><a style="color:white; text-decoration:none" href="#" class='btn btn-action btn-remove d-none d-md-block' data-bs-toggle='modal' data-bs-target='#alterar'>Remover</a></button>
        </div>
        <!--
        <div class="card">
          <i class="fa-solid fa-calendar-days"></i>
          <h3>Partidas</h3>
          <p>
            Agende partidas, registre resultados e acompanhe estatísticas em
            tempo real.
          </p>
          <button><a style="color:white; text-decoration:none" href="./php/escola/gerenciador_de_times.php">
            Gerenciar
            </a>
          </button>
        </div>

        <div class="card">
          <i class="fa-solid fa-chart-line"></i>
          <h3>Tabela de Pontuação</h3>
          <p>Veja a classificação dos times e o desempenho em tempo real.</p>
          <button>Ver Tabela</button>
        </div>

        <div class="card">
          <i class="fa-solid fa-users-gear"></i>
          <h3>Gerenciar Jogadores</h3>
          <p>Adicione, edite ou remova jogadores vinculados aos times.</p>
          <button>Editar Jogadores</button>
        </div>

        <div class="card">
          <i class="fa-solid fa-gear"></i>
          <h3>Configurações</h3>
          <p>
            Personalize regras, pontuações e controle administrativo do
            campeonato.
          </p>
          <button>Configurar</button>
        </div>--->
      </div>

      <div class="table-section">
        <h2>Campeonatos Ativos</h2>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Nome</th>
              <th>Data de Início</th>
              <th>Tipo</th>
              <th>Times</th>
              <th>Status</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody id="Campeonatos">
            
            <tr>
              <td>Campeonato Interclasses</td>
              <td>20/09/2025</td>
              <td>6</td>
              <td>
                <span style="color: #f59e0b; font-weight: 500"
                  >Em andamento</span
                >
              </td>
              <td><button>Editar</button></td>
            </tr>
          </tbody>
        </table>
      </div>
    </main>

    <footer id="contato" style="background: #0b0b14; color: #ccc; text-align: center; padding: 2rem; margin-top: 2rem;">
      <p>© 2025 Interclasse. Todos os direitos reservados.</p>
      <p>Participe do maior campeonato estudantil do Brasil!</p>
      <p>Contatos</p>
      <div style="margin-top: 1rem;">
        <a href="mailto:tccMain@gmail.com" style="color:#4a90e2; margin:0 10px;"><i class="fa-regular fa-envelope"></i></a>
      </div>
    </footer>

    <!-- MODAIS -->
    <div class='modal' id='exampleModal' tabindex='-1' aria-labelledby='exampleModalLabel' aria-hidden='true'>
    <div class='modal-dialog modal-dialog-centered'>
      <div class='modal-content'>
        <div class='modal-header'>
          <h1 class='modal-title fs-5' id='exampleModalLabel'>Criar Campeonato</h1>
          <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
        </div>
        <div class='modal-body'>
            <div class='mb-3'>
              <label class='col-form-label'>
                <i class="fas fa-trophy"></i> Nome do Campeonato:
              </label>
              <input type='text' class='form-control' name='Nome' placeholder="Ex: Campeonato Inter-Classes 2025">
            </div>
            <div class='mb-3'>
              <label class='col-form-label'>
                <i class="fas fa-list-alt"></i> Tipo de Campeonato:
              </label>
              <select id='Tipo' name='Tipo' class='form-control'>
                <option value='Empyt' selected disabled> Selecione o formato </option>
                <!-- <option value='Copa'> Copa </option> -->
                <option value='Mata-Mata'> 🏆 Mata-Mata </option>
              </select>
            </div>
            <div class='mb-3'>
              <label class='col-form-label'>
                <i class="fas fa-users"></i> Quantidade de Times:
              </label>
              <input type='number' class='form-control' name='Quantidade' placeholder="Entre 2 e 20 times" step='2' min='2' max='20'>
            </div>
            <div class='mb-3'>
              <label class='col-form-label'>
                <i class="fas fa-calendar-alt"></i> Data de Início:
              </label>
              <input type='date' class='form-control' name='Data' min="<?php echo date('Y-m-d'); ?>" maxlength="10">
            </div>
            <div class="mb-3">
            <label class="form-label">
              <i class="fas fa-image"></i> Logo do Campeonato:
            </label>
             <!-- preview opcional -->
            <div id="preview" class="mt-2 d-flex justify-content-center mb-4" style="width:fit-content">
              <img
                  src="imagens/empty-1.jpeg" 
                  class="img-thumbnail w-25 mx-auto"
                  alt="Preview do logo"
              >
            </div>
            <!-- input escondido -->
                  
            <!-- botão estilizado -->
            <div class="input-group">
               <label for="fotoCamp" class="btn btn-primary mb-0">
                 <i class="fas fa-upload"></i> Escolher arquivo
               </label>
               <input type="text" id="fileName" class="form-control" placeholder="Nenhum arquivo selecionado" readonly>
               <label class="btn btn-danger mb-0 rounded-end" id='cancelUpload'>
                 <i class="fas fa-times"></i> Cancelar
               </label>
               <input type="file" class="form-control" id="fotoCamp" placeholder="Selecione um arquivo" aria-describedby="inputGroupFileAddon04" aria-label="Upload" accept="image/*" hidden>
            </div>

          </div>
        </div>
        <div class='modal-footer'>
          <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>
            <i class="fas fa-times"></i> Cancelar
          </button>
          <!-- <button type='button' class='btn btn-secondary' onclick='sobefoto()'>teste</button> -->
          <a id='cad_new_camp' class='btn btn-primary' onclick='ProximoPasso()'>
            <i class="fas fa-arrow-right"></i> Próximo Passo
          </a>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal Cadastrar PT-3 -->
   <div id="ModalCad3"> </div>

  <!-- Modal Remover-->
  <div class='modal fade' id='alterar' tabindex='-1' aria-labelledby='exampleModalLabel' aria-hidden='true'>
    <div class='modal-dialog modal-dialog-centered'>
      <div class='modal-content'>
        <div class='modal-header'>
          <h1 class='modal-title fs-5' id='exampleModalLabel'>Remover Campeonato</h1>
          <button type='button' class='btn-close btn-close-gray' data-bs-dismiss='modal' aria-label='Close'></button>
        </div>
        <div class='modal-body'>
        <form id='removeform' method='POST'>
          <div class='mb-3'>
            <label for='remover' id='selectLabel' class='col-form-label'>
              <i class="fas fa-list"></i> Selecione o campeonato para remover:
            </label>
            <select id='removeSelect' name='remover' size='4' class='form-select'>
            </select>
            <div class='mt-3 alert alert-warning' role='alert'>
              <i class="fas fa-exclamation-triangle"></i> 
              <strong>Atenção:</strong> Esta ação não pode ser desfeita!
            </div>
          </div>
        </div>
        <div class='modal-footer'>
            <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>
              <i class="fas fa-times"></i> Cancelar
            </button>
            <button id='cad_remove_camp' type='submit' class='btn btn-danger'>
              <i class="fas fa-trash-alt"></i> Remover
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
  </body>
</html>
