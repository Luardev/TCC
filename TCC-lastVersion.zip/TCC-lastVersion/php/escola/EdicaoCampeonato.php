<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/auth.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Gerenciamento de Campeonato</title>
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-bracket/0.11.1/jquery.bracket.min.css">
    <link rel="stylesheet" href="../../CSS/gerenciadorEscola.css">
    <?php require_once '../../imports.php'?>
    <script src="js/cadescola.js?<?php echo time() ?>"></script>
    
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap');

:root {
  /* Cores Primárias - Tema Azul Profundo */
  --primary-blue: #4a90e2;
  --primary-blue-dark: #2d5f9f;
  --primary-blue-light: #6ba5e7;
  
  --secondary-cyan: #5dade2;
  --secondary-teal: #3498db;
  --secondary-indigo: #6c7a9b;
  
  /* Cores de Destaque Suaves */
  --accent-light: #85c1e9;
  --accent-dark: #34495e;
  --accent-purple: #7f8fa6;
  
  /* Backgrounds - Tons Escuros Azulados */
  --bg-dark: #0f1419;
  --bg-darker: #0a0d12;
  --bg-card: #161b22;
  --bg-card-hover: #1c2128;
  --bg-glass: rgba(22, 27, 34, 0.85);
  
  /* Texto - Menos Contraste */
  --text-white: #e4e9f0;
  --text-gray: #8b96a5;
  --text-muted: #6b7684;
  
  /* Gradientes Sutis */
  --gradient-primary: linear-gradient(135deg, #4a90e2 0%, #5dade2 50%, #3498db 100%);
  --gradient-dark: linear-gradient(180deg, #0f1419 0%, #161b22 100%);
  --gradient-card: linear-gradient(135deg, #161b22 0%, #1c2128 100%);
  
  /* Sombras Suaves */
  --shadow-subtle: 0 2px 8px rgba(0, 0, 0, 0.3);
  --shadow-card: 0 4px 16px rgba(0, 0, 0, 0.4);
  --shadow-hover: 0 8px 24px rgba(74, 144, 226, 0.15);
  --shadow-glow: 0 0 16px rgba(74, 144, 226, 0.2);
  
  /* Bordas */
  --radius-sm: 6px;
  --radius-md: 10px;
  --radius-lg: 16px;
  --radius-xl: 20px;
  
  /* Bordas e Divisores */
  --border-color: #21262d;
  --border-subtle: #2d333b;
}
      .content-header {
        margin-bottom: 2rem;
        padding: 1rem 0;
        border-bottom: 2px solid #e5e7eb;
      }
      
      .btn-back {
        background-color: #6b7280;
        color: white;
        border: none;
        padding: 0.75rem 1.5rem;
        border-radius: 8px;
        cursor: pointer;
        font-size: 1rem;
        transition: background-color 0.3s;
      }
      
      .btn-back:hover {
        background-color: #4b5563;
      }
      
      #content-container {
        margin-top: 2rem;
        padding: 2rem;
        background-color: #f9fafb;
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      }
      .card_times{
        width: 25em;
        padding: 1.2em;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-between;
        transition: 0.25s ease;
      }
      .card_times:hover {
        transform: translateY(-4px);
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
      }
      .titulos_times {
        display: flex;
        justify-content: space-between;
        width: 100%;
        font-weight: 600;
        color: #1e293b;
        font-size: 1em;
        margin-bottom: 0.6em;
      }
      
      .score {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-bottom: 0.8em;
      }

      .score-separator {
        margin: 0 0.4em;
        font-size: 1.4em;
        color: #475569;
      }

      .score-number1,
      .score-number2 {
        font-size: 2.4rem;
        font-weight: 700;
      }

      .score-number1 {
        color: #3b82f6;
      }

      .score-number2 {
        color: #ef4444;
      }

      
      .match-status {
        font-size: 0.9em;
        color: #64748b;
        margin-top: 4px;
      }

      .card {
        cursor: pointer;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        
      }
      
      .card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
      }
      
      .sorteio-buttons {
        display: flex;
        gap: 1rem;
        margin-bottom: 2rem;
        justify-content: center;
      }
      
      .btn-sortear {
        background-color: #3b82f6;
        color: white;
        border: none;
        padding: 0.75rem 1.5rem;
        border-radius: 8px;
        cursor: pointer;
        font-size: 1rem;
        transition: background-color 0.3s;
      }
      
      .btn-sortear:hover {
        background-color: #2563eb;
      }
      
      .btn-resortear {
        background-color: #ef4444;
        color: white;
        border: none;
        padding: 0.75rem 1.5rem;
        border-radius: 8px;
        cursor: pointer;
        font-size: 1rem;
        transition: background-color 0.3s;
      }
      
      .btn-resortear:hover {
        background-color: #dc2626;
      }

      .aling_cards {
        display: inline-flex;
        justify-content: center;
        gap: 2em;
        width: 100%;
        flex-wrap: wrap;
      }
      
      .card-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 1.5em;
      }
      
      .card-grid .card {
        background-color: white;
        border-radius: 12px;
        padding: 1.5em;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
      }
      
      .card-grid .card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.15);
      }
      
      .card-grid .card h3 {
        margin: 0;
        font-size: 1.3rem;
        color: #111827;
      }
      
      .card-grid .card p {
        margin: 0.5em 0 1.2em;
        color: #6b7280;
      }
      
      .actions {
        display: flex;
        justify-content: space-between;
        gap: 0.5em;
      }
      
      .btn {
        flex: 1;
        border: none;
        padding: 0.6em;
        border-radius: 6px;
        cursor: pointer;
        font-size: 0.95rem;
        transition: 0.3s;
      }
      
      .btn.view {
        background-color: #3b82f6;
        color: white;
      }
      
      .btn.edit {
        background-color: #facc15;
        color: #111827;
      }
      
      .btn.delete {
        background-color: #ef4444;
        color: white;
      }
      
      .btn:hover {
        opacity: 0.85;
      }
      
      .btn-edit {
        background-color: #3b82f6;
        color: white;
      }
      
      .btn-disabled {
        background-color: #9ca3af;
        color: #6b7280;
        cursor: not-allowed;
        opacity: 0.6;
      }
      
      .btn-disabled:hover {
        opacity: 0.6;
      }
      
      .btn-reset {
        background-color: #f59e0b;
        color: white;
        margin-left: 0.5rem;
      }
      
      .btn-reset:hover {
        background-color: #d97706;
      }
      
      .botoes {
        display: flex;
        gap: 0.5rem;
        justify-content: center;
        flex-wrap: wrap;
      }
      
      .modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: 1050;
      }
      
      .modal-dialog {
        position: relative;
        width: auto;
        margin: 1.75rem;
        max-width: 500px;
      }
      
      .modal-content {
        position: relative;
        display: flex;
        flex-direction: column;
        width: 100%;
        background-color: #fff;
        border-radius: 0.5rem;
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
      }
      
      .modal-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 1rem 1rem;
        border-bottom: 1px solid #dee2e6;
      }
      
      .modal-body {
        position: relative;
        flex: 1 1 auto;
        padding: 1rem;
      }
      
      .modal-footer {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        padding: 1rem;
        border-top: 1px solid #dee2e6;
        gap: 0.5rem;
      }
      
      .jogador-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.5rem;
        border: 1px solid #dee2e6;
        border-radius: 0.25rem;
        margin-bottom: 0.5rem;
      }
      
      .form-group {
        margin-bottom: 1rem;
      }
      
      .form-label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 500;
      }
      
      .form-control {
        display: block;
        width: 100%;
        padding: 0.375rem 0.75rem;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: #212529;
        background-color: #fff;
        border: 1px solid #ced4da;
        border-radius: 0.375rem;
      }
      
      .table {
        width: 100%;
        margin-bottom: 1rem;
        color: #212529;
        border-collapse: collapse;
      }
      
      .table th,
      .table td {
        padding: 0.75rem;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
      }
      
      .table thead th {
        vertical-align: bottom;
        border-bottom: 2px solid #dee2e6;
        background-color: #f8f9fa;
      }
      
      .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, 0.05);
      }
      
      .alert {
        padding: 1rem;
        margin-bottom: 1rem;
        border: 1px solid transparent;
        border-radius: 0.375rem;
      }
      
      .alert-info {
        color: #0c5460;
        background-color: #d1ecf1;
        border-color: #bee5eb;
      }
      
      .alert-warning {
        color: #856404;
        background-color: #fff3cd;
        border-color: #ffeaa7;
      }
      
      .alert-danger {
        color: #721c24;
        background-color: #f8d7da;
        border-color: #f5c6cb;
      }
      
      .text-center {
        text-align: center;
      }
      
      .fa-spinner {
        animation: spin 1s linear infinite;
      }
      
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      
      .text-primary {
        color: #3b82f6 !important;
      }
      
      .text-success {
        color: #10b981 !important;
      }
      
      .text-muted {
        color: #6b7280 !important;
      }
      
      /* Estilos para o gerenciador de times */
      .times-manager {
        padding: 2rem;
      }
      
      .times-header {
        text-align: center;
        margin-bottom: 2rem;
        padding-bottom: 1rem;
        border-bottom: 2px solid #e5e7eb;
      }
      
      .times-header h2 {
        color: #1f2937;
        margin-bottom: 0.5rem;
      }
      
      .times-header p {
        color: #6b7280;
        margin: 0;
      }
      
      .team-manager-tabs {
        margin-top: 1rem;
      }
      
      .tab-buttons {
        display: flex;
        border-bottom: 2px solid #e5e7eb;
        margin-bottom: 2rem;
      }
      
      .tab-btn {
        background: none;
        border: none;
        padding: 1rem 2rem;
        cursor: pointer;
        font-weight: 600;
        color: #6b7280;
        border-radius: 8px 8px 0 0;
        transition: all 0.3s ease;
      }
      
      .tab-btn.active {
        background-color: #3b82f6;
        color: white;
      }
      
      .tab-btn:hover:not(.active) {
        background-color: #f3f4f6;
        color: #1f2937;
      }
      
      .tab-content {
        position: relative;
      }
      
      .tab-pane {
        display: none;
      }
      
      .tab-pane.active {
        display: block;
      }
      
      .add-player-section {
        background: #f9fafb;
        border-radius: 12px;
        padding: 1.5rem;
        margin-bottom: 2rem;
      }
      
      .add-player-section h4 {
        color: #1f2937;
        margin-bottom: 1rem;
      }
      
      .players-list-section h4 {
        color: #1f2937;
        margin-bottom: 1rem;
      }
      
      .players-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 1.5rem;
        margin-top: 1.5rem;
      }
      
      .player-card {
        background: white;
        border: 2px solid #e5e7eb;
        border-radius: 12px;
        padding: 1.5rem;
        transition: all 0.3s ease;
      }
      
      .player-card:hover {
        border-color: #3b82f6;
        transform: translateY(-2px);
        box-shadow: 0 4px 20px rgba(59, 130, 246, 0.1);
      }
      
      .player-card h5 {
        color: #1f2937;
        margin-bottom: 1rem;
        font-weight: 600;
      }
      
      .player-info {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 0.5rem;
        margin-bottom: 1rem;
      }
      
      .player-info small {
        color: #6b7280;
        font-weight: 500;
      }
      
      .player-actions {
        display: flex;
        gap: 0.5rem;
        margin-top: 1rem;
      }
      
      .player-actions .btn {
        flex: 1;
        padding: 0.5rem;
        font-size: 0.9rem;
      }
      
      .btn-sm {
        padding: 0.375rem 0.75rem;
        font-size: 0.875rem;
      }

      
      #classificacao {
        overflow-x: auto;
        background: linear-gradient(135deg, #f8fafc 0%, #ffffff 100%);
        border-radius: var(--radius-lg);
        padding: 1rem;
        /*display: flex;
        flex-wrap: nowrap;
        justify-content: center;*/
        align-items: center;
        text-align: center;
      }


      div.jQBracket {
        background: transparent !important;
        font-family: 'Poppins', sans-serif;
      }

      /*===========================================
        Cards dos times no bracket
      ===========================================*/
      div.jQBracket .team {
        background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%) !important;
        border: 1px solid #e2e8f0 !important;
        border-radius: 12px !important;
        padding: 6px 10px !important;
        /*margin: 4px 0 !important;
        min-height: 50px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;*/
        transition: all 0.3s ease !important;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08) !important;
      }

      div.jQBracket .team::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
        background: linear-gradient(135deg, #3b82f6, #1e40af);
        border-radius: 0 2px 2px 0;
      }

      div.jQBracket .team:hover {
        background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%) !important;
        border-color: #3b82f6 !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 4px 16px rgba(59, 130, 246, 0.15) !important;
      }

      /*============================================
        Nome do time no bracket
      ==========================================*/
      .team-name,
      div.jQBracket .team span,
      div.jQBracket .team .label,
      div.jQBracket span.label,
      div.jQBracket .team span.team-name {
        font-family: 'Poppins', sans-serif !important;
        font-size: 0.9rem !important;
        font-weight: 600 !important;
        color: #1e293b !important;
        white-space: nowrap !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        max-width: 140px !important;
        /*line-height: 1.4 !important;
        display: flex !important;
        align-items: center !important;*/
        flex: 1 !important;
        margin-right: 10px !important;
      }

      /*============================================
        Placar no bracket
      ==========================================*/
      div.jQBracket .team .score,
      div.jQBracket .team div.score {
        font-family: 'Poppins', sans-serif !important;
        font-size: 1rem !important;
        font-weight: 700 !important;
        color: #ffffff !important;
        background: linear-gradient(135deg, #3b82f6, #1e40af) !important;
        /*padding: 6px 12px !important;*/
        border-radius: 8px !important;
        /*min-width: 35px !important;
        text-align: center !important;*/
        margin-left: 12px !important;
        box-shadow: 0 2px 4px rgba(59, 130, 246, 0.3) !important;
        border: 1px solid rgba(255, 255, 255, 0.2) !important;
      }

      /*============================================
        Times vencedores
      ==========================================*/
      div.jQBracket .team.win {
        background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%) !important;
        border-color: #22c55e !important;
        box-shadow: 0 4px 16px rgba(34, 197, 94, 0.2) !important;
      }

      div.jQBracket .team.win::before {
        background: linear-gradient(135deg, #22c55e, #16a34a) !important;
      }

      div.jQBracket .team.win .score {
        background: linear-gradient(135deg, #22c55e, #16a34a) !important;
        color: #ffffff !important;
        font-weight: 800 !important;
        box-shadow: 0 2px 4px rgba(34, 197, 94, 0.4) !important;
      }

      /*============================================
        Times perdedores
      ==========================================*/
      div.jQBracket .team.lose {
        opacity: 0.7 !important;
        background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%) !important;
        border-color: #fca5a5 !important;
      }

      div.jQBracket .team.lose::before {
        background: linear-gradient(135deg, #ef4444, #dc2626) !important;
      }

      div.jQBracket .team.lose .score {
        background: linear-gradient(135deg, #ef4444, #dc2626) !important;
        color: #ffffff !important;
        opacity: 0.8 !important;
      }

      /*============================================
        Linhas de conexão do bracket
      ==========================================*/
      .bracket .connector,
      .bracket .connector div,
      div.jQBracket .connector {
        border-color: #3b82f6 !important;
        border-width: 2px !important;
        border-radius: 1px !important;        
      }

      /*============================================
        Rounds do bracket
      ==========================================*/
      /*div.jQBracket .round {
        background: linear-gradient(135deg, #f8fafc 0%, #ffffff 100%) !important;
        border-radius: 16px !important;
        padding: 20px !important;
        margin: 0 15px !important;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08) !important;
        border: 1px solid #e2e8f0 !important;
        position: relative !important;
        overflow: hidden !important;
      }

      div.jQBracket .round::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: linear-gradient(135deg, #3b82f6, #1e40af);
      }

      div.jQBracket .round h3 {
        color: #1e40af !important;
        font-weight: 700 !important;
        font-size: 1.1rem !important;
        margin-bottom: 15px !important;
        text-align: center !important;
        padding-bottom: 8px !important;
        border-bottom: 2px solid #e2e8f0 !important;
      }*/

      /*============================================
        Tools e edição desabilitados
      ==========================================*/
      div.jQBracket .tools {
        display: none !important;
      }

      /*============================================
        Garantir que elementos importantes estejam visíveis
      ==========================================*/              
      div.jQBracket .team span,
      div.jQBracket .team .label,
      div.jQBracket .team .score,
      div.jQBracket .team div,
      div.jQBracket .match,
      div.jQBracket .round {
        visibility: visible !important;
        opacity: 1 !important;
      }

      /*===========================================
        Nome do time dentro do span
      ==========================================*/
      div.jQBracket .team span.label,
      div.jQBracket .team > span:first-child {
        flex: 1;
        padding-right: 0.5rem;
      }

      /*============================================
        Desabilitar edição mas manter visível
      ==========================================*/
      .editable {
        pointer-events: none !important;
        cursor: default !important;
      }

      /*===========================================
        Resetar possíveis conflitos
      ==========================================*/
      div.jQBracket .team * {
        font-family: inherit;
        color: inherit;
      }

      /*============================================
        Estrutura do bracket
      ===========================================*/   
      div.jQBracket .connector {
        visibility: visible !important;
      }

      /*============================================
        Responsividade do bracket
      ===========================================*/
     /* @media (max-width: 768px) {
        #classificacao {
          padding: 1rem;
        }
        
        div.jQBracket .team {
          padding: 8px 12px !important;
          min-height: 45px !important;
        }
        
        .team-name,
        div.jQBracket .team span,
        div.jQBracket .team .label,
        div.jQBracket span.label,
        div.jQBracket .team span.team-name {
          font-size: 0.8rem !important;
          max-width: 100px !important;
        }
        
        div.jQBracket .team .score,
        div.jQBracket .team div.score {
          font-size: 0.9rem !important;
          padding: 4px 8px !important;
          min-width: 30px !important;
        }
        
        div.jQBracket .round {
          padding: 15px !important;
          margin: 0 10px !important;
        }
      }*/
      .btn-sortear:disabled {
        background-color: #6c757d;  /* cinza escuro */
        color: #ccc;                /* texto mais apagado */
        cursor: not-allowed;        /* ícone de proibido */
        opacity: 0.7;               /* levemente transparente */
      }
      .btn-resortear:disabled {
        background-color: #6c757d;  /* cinza escuro */
        color: #ccc;                /* texto mais apagado */
        cursor: not-allowed;        /* ícone de proibido */
        opacity: 0.7;               /* levemente transparente */
      }

      /* Notificações */
      #toast-container {
        position: fixed;
        top: 16px;
        right: 16px;
        z-index: 99999;
        display: flex;
        flex-direction: column;
        gap: 10px;
      }
      .toast {
        min-width: 280px;
        max-width: 360px;
        padding: 12px 14px;
        border-radius: 10px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        color: #0f172a;
        background: #fff;
        border: 1px solid #e5e7eb;
        display: flex;
        align-items: center;
        gap: 10px;
        opacity: 0;
        transform: translateY(-10px);
        transition: all .25s ease;
      }
      .toast.show { opacity: 1; transform: translateY(0); }
      .toast .icon { font-size: 1.1rem; }
      .toast.success { border-left: 4px solid #10b981; }
      .toast.success .icon { color: #10b981; }
      .toast.error { border-left: 4px solid #ef4444; }
      .toast.error .icon { color: #ef4444; }
      .toast.warning { border-left: 4px solid #f59e0b; }
      .toast.warning .icon { color: #f59e0b; }
      .toast.info { border-left: 4px solid #3b82f6; }
      .toast.info .icon { color: #3b82f6; }
      .toast .close {
        margin-left: auto;
        cursor: pointer;
        color: #64748b;
      }
    </style>
  </head>
  <body>
    <header>
      <div class="logo">
        <img
          src="https://cdn-icons-png.flaticon.com/512/3661/3661392.png"
          alt="Logo"
        />
        <span class="titulo_real">Painel de Gerenciamento</span>
      </div>

      <nav>
        <a href="php/escola/GerenciadorCampeonatos.php">Início</a>
        <a href="index.php">Sair</a>
      </nav>
    </header>

    <main>
      <div class="dashboard-header">
        <h1>Gerenciamento de Campeonato</h1>
      </div>

      <div class="grid-container">
        <div class="card" onclick="loadContent('partidas')">
          <i class="fa-solid fa-calendar-days"></i>
          <h3>Partidas</h3>
          <p>
            Agende partidas, registre resultados e acompanhe estatísticas em
            tempo real.
          </p>
          <button>Gerenciar</button>
        </div>

        <div class="card" onclick="loadContent('tabela')">
          <i class="fa-solid fa-chart-line"></i>
          <h3>Tabela de Pontuação</h3>
          <p>Veja a classificação dos times e o desempenho em tempo real.</p>
          <button>Ver Tabela</button>
        </div>

        <div class="card" onclick="loadContent('times')">
          <i class="fa-solid fa-users-gear"></i>
          <h3>Gerenciar Times</h3>
          <p>Adicione, edite ou remova times e seus jogadores.</p>
          <button>Gerenciar Times</button>
        </div>

        
      </div>

      <!-- Container dinâmico para conteúdo -->
      <div id="content-container" style="display: none;">
        <div class="content-header">
          <button onclick="hideContent()" class="btn-back">
            <i class="fa-solid fa-arrow-left"></i> Voltar
          </button>
        </div>
        <div id="dynamic-content"></div>
      </div>
      
      <div class="table-section">
        <!--
        <h2>Campeonatos Ativos</h2>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Nome</th>
              <th>Data de Início</th>
              <th>Tipo</th>
              <th>Times</th>
              <th>Status</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody id="Campeonatos">
            
            <tr>
              <td>Campeonato Interclasses</td>
              <td>20/09/2025</td>
              <td>6</td>
              <td>
                <span style="color: #f59e0b; font-weight: 500"
                  >Em andamento</span
                >
              </td>
              <td><button>Editar</button></td>
            </tr>
          </tbody>
        </table>
         -->
      </div>
     
    </main>

    <footer id="contato" style="background: #0b0b14; color: #ccc; text-align: center; padding: 2rem; margin-top: 2rem;">
      <p>© 2025 Interclasse. Todos os direitos reservados.</p>
      <p>Participe do maior campeonato estudantil do Brasil!</p>
      <p>Contatos</p>
      <div style="margin-top: 1rem;">
        <a href="mailto:tccMain@gmail.com" style="color:#4a90e2; margin:0 10px;"><i class="fa-regular fa-envelope"></i></a>
      </div>
    </footer>

    <!-- MODAIS -->
    <div class='modal' id='exampleModal' tabindex='-1' aria-labelledby='exampleModalLabel' aria-hidden='true'>
    <div class='modal-dialog modal-dialog-centered'>
      <div class='modal-content'>
        <div class='modal-header'>
          <h1 class='modal-title fs-5' id='exampleModalLabel'>Criar Campeonato</h1>
          <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
        </div>
        <div class='modal-body'>
            <div class='mb-3'>
              <label class='col-form-label'>
                <i class="fas fa-trophy"></i> Nome do Campeonato:
              </label>
              <input type='text' class='form-control' name='Nome' placeholder="Ex: Campeonato Inter-Classes 2025">
            </div>
            <div class='mb-3'>
              <label class='col-form-label'>
                <i class="fas fa-list-alt"></i> Tipo de Campeonato:
              </label>
              <select id='Tipo' name='Tipo' class='form-control'>
                <option value='Empyt' selected disabled> Selecione o formato </option>
                <!-- <option value='Copa'> Copa </option> -->
                <option value='Mata-Mata'> 🏆 Mata-Mata </option>
              </select>
            </div>
            <div class='mb-3'>
              <label class='col-form-label'>
                <i class="fas fa-users"></i> Quantidade de Times:
              </label>
              <input type='number' class='form-control' name='Quantidade' placeholder="Entre 2 e 20 times" step='2' min='2' max='20'>
            </div>
            <div class='mb-3'>
              <label class='col-form-label'>
                <i class="fas fa-calendar-alt"></i> Data de Início:
              </label>
              <input type='date' class='form-control' name='Data' min="<?php echo date('Y-m-d'); ?>" maxlength="10">
            </div>
            <div class="mb-3">
            <label class="form-label">
              <i class="fas fa-image"></i> Logo do Campeonato:
            </label>
             <!-- preview opcional -->
            <div id="preview" class="mt-2 d-flex justify-content-center mb-4" style="width:fit-content">
              <img
                  src="imagens/empty-1.jpeg" 
                  class="img-thumbnail w-25 mx-auto"
                  alt="Preview do logo"
              >
            </div>
            <!-- input escondido -->
                  
            <!-- botão estilizado -->
            <div class="input-group">
               <label for="fotoCamp" class="btn btn-primary mb-0">
                 <i class="fas fa-upload"></i> Escolher arquivo
               </label>
               <input type="text" id="fileName" class="form-control" placeholder="Nenhum arquivo selecionado" readonly>
               <label class="btn btn-danger mb-0 rounded-end" id='cancelUpload'>
                 <i class="fas fa-times"></i> Cancelar
               </label>
               <input type="file" class="form-control" id="fotoCamp" placeholder="Selecione um arquivo" aria-describedby="inputGroupFileAddon04" aria-label="Upload" accept="image/*" hidden>
            </div>

          </div>
        </div>
        <div class='modal-footer'>
          <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>
            <i class="fas fa-times"></i> Cancelar
          </button>
          <!-- <button type='button' class='btn btn-secondary' onclick='sobefoto()'>teste</button> -->
          <a id='cad_new_camp' class='btn btn-primary' onclick='ProximoPasso()'>
            <i class="fas fa-arrow-right"></i> Próximo Passo
          </a>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal Cadastrar PT-3 -->
   <div id="ModalCad3"> </div>

  <!-- Modal Remover-->
  <div class='modal fade' id='alterar' tabindex='-1' aria-labelledby='exampleModalLabel' aria-hidden='true'>
    <div class='modal-dialog modal-dialog-centered'>
      <div class='modal-content'>
        <div class='modal-header'>
          <h1 class='modal-title fs-5' id='exampleModalLabel'>Remover Campeonato</h1>
          <button type='button' class='btn-close btn-close-gray' data-bs-dismiss='modal' aria-label='Close'></button>
        </div>
        <div class='modal-body'>
        <form id='removeform' method='POST'>
          <div class='mb-3'>
            <label for='remover' id='selectLabel' class='col-form-label'>
              <i class="fas fa-list"></i> Selecione o campeonato para remover:
            </label>
            <select id='removeSelect' name='remover' size='4' class='form-select'>
            </select>
            <div class='mt-3 alert alert-warning' role='alert'>
              <i class="fas fa-exclamation-triangle"></i> 
              <strong>Atenção:</strong> Esta ação não pode ser desfeita!
            </div>
          </div>
        </div>
        <div class='modal-footer'>
            <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>
              <i class="fas fa-times"></i> Cancelar
            </button>
            <button id='cad_remove_camp' type='submit' class='btn btn-danger'>
              <i class="fas fa-trash-alt"></i> Remover
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
  </body>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-bracket/0.11.1/jquery.bracket.min.js"></script>
  <script>
    function showNotification(type, message) {
      const containerId = 'toast-container';
      let container = document.getElementById(containerId);
      if (!container) {
        container = document.createElement('div');
        container.id = containerId;
        document.body.appendChild(container);
      }
      const toast = document.createElement('div');
      toast.className = `toast ${type}`;
      const iconMap = { success: 'fa-circle-check', error: 'fa-triangle-exclamation', warning: 'fa-circle-exclamation', info: 'fa-circle-info' };
      toast.innerHTML = `
        <i class="fa-solid ${iconMap[type] || iconMap.info} icon"></i>
        <div class="msg">${message}</div>
        <i class="fa-solid fa-xmark close"></i>
      `;
      container.appendChild(toast);
      // Force reflow to trigger transition
      void toast.offsetWidth;
      toast.classList.add('show');
      const remove = () => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 250);
      };
      toast.querySelector('.close').addEventListener('click', remove);
      setTimeout(remove, 3000);
    }
    function loadContent(type) {
      const container = document.getElementById('content-container');
      const dynamicContent = document.getElementById('dynamic-content');
      const gridContainer = document.querySelector('.grid-container');
      const tableSection = document.querySelector('.table-section');
      
      
      // Esconder elementos principais
      gridContainer.style.display = 'none';
      tableSection.style.display = 'none';
      
      // Mostrar container de conteúdo
      container.style.display = 'block';
      
      switch(type) {
        case 'partidas':
          loadPartidasContent();
          break;
        case 'times':
          loadTimesContent();
          break;
        case 'tabela':
          loadTabelaContent();
          break;
      }
    }
    
    function hideContent() {
      const container = document.getElementById('content-container');
      const gridContainer = document.querySelector('.grid-container');
      const tableSection = document.querySelector('.table-section');
      
      container.style.display = 'none';
      gridContainer.style.display = 'grid';
      tableSection.style.display = 'block';
    }
    
    function loadPartidasContent() {
      const dynamicContent = document.getElementById('dynamic-content');
      dynamicContent.innerHTML = `
        <div class="sorteio-buttons">
          <button class="btn-sortear" onclick="sortearPartidas()">
            <i class="fa-solid fa-shuffle"></i> Sortear Partidas
          </button>
          <button class="btn-resortear" onclick="resortearPartidas()">
            <i class="fa-solid fa-rotate"></i> Resortear Partidas
          </button>
        </div>
        
        <div id="partidas-container">
          <div class="text-center">
            <i class="fa-solid fa-spinner fa-spin"></i> Carregando partidas...
          </div>
        </div>
      `;
      
      // Carregar partidas do banco de dados
      carregarPartidasDoBanco();
    }
    
    function carregarPartidasDoBanco() {
      const id_camp = getCampId();
      
      fetch(`Banco/api_campeonato.php?action=carregar_partidas&id_camp=${id_camp}`)
      .then(response => response.json())
      .then(data => {
        if (data.ok) {
          renderizarPartidas(data.data);
        } else {
          document.getElementById('partidas-container').innerHTML = `
            <div class="alert alert-warning">
              <i class="fa-solid fa-exclamation-triangle"></i> ${data.error}
            </div>
          `;
        }
      })
      .catch(error => {
        console.error('Erro:', error);
        document.getElementById('partidas-container').innerHTML = `
          <div class="alert alert-danger">
            <i class="fa-solid fa-exclamation-circle"></i> Erro ao carregar partidas
          </div>
        `;
      });
    }
    
    function renderizarPartidas(partidas) {
      const container = document.getElementById('partidas-container');
      const botaoSortear = document.querySelector('.btn-sortear');
      const botaoResortear = document.querySelector('.btn-resortear');
      if (Object.keys(partidas).length === 0) {
        container.innerHTML = `
          <div class="alert alert-info">
            <i class="fa-solid fa-info-circle"></i> Nenhuma partida encontrada. Clique em "Sortear Partidas" para começar.
          </div>
        `;
        if (botaoResortear) botaoResortear.disabled = true;
        if (botaoSortear) {
          botaoSortear.disabled = false;
        }
        return;
      }
      if (botaoSortear) {
        botaoSortear.disabled = true;
      }

      let html = '<div class="divisao_etapas">';
      
      // Ordenar fases (2, 3, 4, 5)
      const fases = Object.keys(partidas).sort((a, b) => parseInt(a) - parseInt(b));
      
      fases.forEach(fase => {
        const faseData = partidas[fase];
        html += `<h2 class="titulos">${faseData.nome}</h2>`;
        html += '<div class="aling_cards">';
        
        faseData.partidas.forEach(partida => {
          const statusClass = getStatusClass(partida.status);
          const statusText = getStatusText(partida.status);
          console.log(partida);
          // Verificar se pode editar a partida
          const podeEditar = partida.time1 !== 'TBD' && 
                           partida.time2 !== 'TBD' && 
                           partida.status === 'N';
          
          html += `
            <div class="card_times">
              <div class="titulos_times">
                <p>${partida.time1}</p>
                <p>${partida.time2}</p>
              </div>
              <div class="score">
                <div>
                  <span class="score-number1">${partida.gols_time1}</span>
                  <span class="score-separator">x</span>
                  <span class="score-number2">${partida.gols_time2}</span>
                </div>
                <p class="match-status ${statusClass}">${statusText}</p>
              </div>
              <div class="botoes">
                <button class="btn ${podeEditar ? 'btn-edit' : 'btn-disabled'}" 
                        ${podeEditar ? `onclick="abrirGerenciarPartida(${partida.id_partida}, ${partida.fk_fase})"` : 'disabled'}
                        title="${podeEditar ? 'Abrir gerenciamento da partida' : 'Partida não pode ser editada - Times TBD ou status inválido'}">
                  Modo Edição
                </button>
                <button class="btn btn-reset" 
                        onclick="reiniciarPartida(${partida.id_partida}, ${partida.fk_fase})"
                        title="Reiniciar partida - Apagar estatísticas e resetar gols">
                  <i class="fas fa-undo"></i> Reiniciar
                </button>
              </div>
            </div>
          `;
        });
        
        html += '</div>';
      });
      
      html += '</div>';
      container.innerHTML = html;
    }
    
    function getStatusClass(status) {
      switch(status) {
        case 'I': return 'text-primary';
        case 'T': return 'text-success';
        default: return 'text-muted';
      }
    }
    
    function getStatusText(status) {
      switch(status) {
        case 'I': return 'Ao Vivo';
        case 'T': return 'Encerrado';
        default: return 'A Iniciar';
      }
    }
    
    function alterarGol(idPartida, time, valor) {
      // Implementar alteração de gols
      console.log(`Alterar gol: Partida ${idPartida}, Time ${time}, Valor ${valor}`);
    }
    
    function salvarPartida(idPartida) {
      // Implementar salvamento de partida
      console.log(`Salvar partida: ${idPartida}`);
    }
    
    function loadTimesContent() {
      const dynamicContent = document.getElementById('dynamic-content');
      dynamicContent.innerHTML = `
        <div class="times-manager">
          <div class="times-header">
            <h2><i class="fas fa-users"></i> Gerenciar Times</h2>
            <p>Administre e edite os times participantes do campeonato</p>
          </div>
          
          <div id="times-container">
            <div class="text-center">
              <i class="fa-solid fa-spinner fa-spin"></i> Carregando times...
            </div>
          </div>
        </div>
      `;
      
      // Carregar times do banco de dados
      carregarTimesDoBanco();
    }
    
    function carregarTimesDoBanco() {
      const id_camp = getCampId();
      
      fetch(`Banco/api_campeonato.php?action=carregar_times&id_camp=${id_camp}`)
      .then(response => response.json())
      .then(data => {
        if (data.ok) {
          renderizarTimes(data.data);
        } else {
          document.getElementById('times-container').innerHTML = `
            <div class="alert alert-warning">
              <i class="fa-solid fa-exclamation-triangle"></i> ${data.error}
            </div>
          `;
        }
      })
      .catch(error => {
        console.error('Erro:', error);
        document.getElementById('times-container').innerHTML = `
          <div class="alert alert-danger">
            <i class="fa-solid fa-exclamation-circle"></i> Erro ao carregar times
          </div>
        `;
      });
    }
    
    function renderizarTimes(times) {
      const container = document.getElementById('times-container');
      
      let html = '<div class="card-grid">';
      
      // Botão para adicionar novo time
      html += `
        <div class="card" style="border: 2px dashed #3b82f6; background-color: #f8fafc;">
          <div style="text-align: center; padding: 2rem;">
            <i class="fas fa-plus-circle" style="font-size: 3rem; color: #3b82f6; margin-bottom: 1rem;"></i>
            <h3 style="color: #3b82f6; margin-bottom: 0.5rem;">Adicionar Novo Time</h3>
            <p style="color: #6b7280; margin-bottom: 1.5rem;">Clique para adicionar um novo time ao campeonato</p>
            <button class="btn" style="background-color: #3b82f6; color: white; width: 100%;" onclick="showAddTeamModal()">
              <i class="fas fa-plus"></i> Adicionar Time
            </button>
          </div>
        </div>
      `;
      
      if (times.length === 0) {
        html += `
          <div class="card" style="grid-column: 1 / -1; text-align: center; padding: 2rem;">
            <i class="fa-solid fa-info-circle" style="font-size: 2rem; color: #6b7280; margin-bottom: 1rem;"></i>
            <h3 style="color: #6b7280;">Nenhum time encontrado</h3>
            <p style="color: #6b7280;">Adicione o primeiro time ao campeonato usando o botão acima.</p>
          </div>
        `;
      } else {
        times.forEach(time => {
          html += `
            <div class="card">
              <h3><i class="fas fa-shield-alt"></i> ${time.nome}</h3>
              <p><i class="fas fa-layer-group"></i> Série: ${time.serie}</p>
              <p><i class="fas fa-users"></i> Jogadores: ${time.jogadores}</p>
              <div class="actions">
                <button class="btn edit" onclick="editTeam(${time.id})">
                  <i class="fas fa-edit"></i> Editar
                </button>
                <button class="btn delete" onclick="deleteTeam(${time.id}, '${time.nome}')">
                  <i class="fas fa-trash"></i> Excluir
                </button>
              </div>
            </div>
          `;
        });
      }
      
      html += '</div>';
      container.innerHTML = html;
    }
    

    

    function loadTabelaContent() {
      const dynamicContent = document.getElementById('dynamic-content');
      dynamicContent.innerHTML = `
        <div class="bracket-container">
          <h2 class="bracket-title">Chaveamento do Campeonato</h2>
          <div id="bracket-display">
            <div class="text-center">
              <i class="fa-solid fa-spinner fa-spin"></i> Carregando chaveamento...
            </div>
          </div>
        </div>
      `;
      
      // Carregar dados do bracket
      carregarBracketDoBanco();
    }
    
    function carregarBracketDoBanco() {
      const id_camp = getCampId();
      
      fetch(`Banco/api_campeonato.php?action=carregar_bracket&id_camp=${id_camp}`)
      .then(response => response.json())
      .then(data => {
        if (data.ok) {
          renderizarBracket(data.data);
        } else {
          document.getElementById('bracket-display').innerHTML = `
            <div class="alert alert-warning">
              <i class="fa-solid fa-exclamation-triangle"></i> ${data.error}
            </div>
          `;
        }
      })
      .catch(error => {
        console.error('Erro:', error);
        document.getElementById('bracket-display').innerHTML = `
          <div class="alert alert-danger">
            <i class="fa-solid fa-exclamation-circle"></i> Erro ao carregar chaveamento
          </div>
        `;
      });
    }
    
    function renderizarBracket(bracketData) {
      const container = document.getElementById('dynamic-content');
      
      if (!bracketData.teams || bracketData.teams.length === 0) {
        container.innerHTML = `
          <div class="alert alert-info">
            <i class="fa-solid fa-info-circle"></i> Nenhum chaveamento encontrado. Sorteie as partidas primeiro.
          </div>
        `;
        return;
      }
      console.log(bracketData);
      // Criar o HTML para o bracket
      container.innerHTML = '<div id="classificacao"></div>';
      
      // Inicializar o bracket
      $('#classificacao').bracket({
        init: bracketData,
        teamWidth: 160,
        scoreWidth: 30,
        matchMargin: 90,
        roundMargin: 70,
        save: function(){}, 
        decorator: { render: renderTeam, edit: function(){} }
      });
    }
    
    // Função para renderizar cada time no bracket
    function renderTeam(container, data, score, state) {
      if (!data) return;
      const [name, flag] = data;
      $(container).html(`
        
        <span class="team-name">${name}</span>
        
      `);
    }

    // Monta o bracket
    
    
    
    
    function sortearPartidas() {
      const id_camp = getCampId();
      
      fetch('Banco/api_campeonato.php?action=sortear_partidas&id_camp=' + id_camp, {
        method: 'GET'
      })
      .then(response => response.json())
      .then(data => {
        if (data.ok) {
          showNotification('success', 'Partidas sorteadas com sucesso!');
          loadPartidasContent();
        } else {
          showNotification('error', 'Erro: ' + data.error);
        }
      })
      .catch(error => {
        console.error('Erro:', error);
        showNotification('error', 'Erro ao sortear partidas');
      });
    }
    
    function resortearPartidas() {
      if(confirm('Tem certeza que deseja resortear as partidas? Isso apagará as partidas existentes.')) {
        const id_camp = getCampId();
        
        fetch('Banco/api_campeonato.php?action=resortear_partidas&id_camp=' + id_camp, {
          method: 'GET'
        })
        .then(response => response.json())
        .then(data => {
          if (data.ok) {
            showNotification('success', 'Partidas resorteadas com sucesso!');
            loadPartidasContent();
          } else {
            showNotification('error', 'Erro: ' + data.error);
          }
        })
        .catch(error => {
          console.error('Erro:', error);
          showNotification('error', 'Erro ao resortear partidas');
        });
      }
    }
    
    function getCampId() {
      // Por enquanto retorna um ID fixo, mas pode ser obtido da URL ou sessão
      const urlParams = new URLSearchParams(window.location.search);
      const id_camp = urlParams.get('id_camp');
      if (!id_camp) {
        showNotification('warning', 'Nenhum ID de campeonato foi definido. Retorne à tela anterior e selecione um campeonato.');
      }
      return id_camp;
    }
    
    /**
     * Abre a tela de gerenciamento de partida
     * @param {number} id_partida - ID da partida
     * @param {number} id_fase - ID da fase
     */
    function abrirGerenciarPartida(id_partida, id_fase) {
      const id_camp = getCampId();
      
      if (!id_camp) {
        showNotification('error', 'ID do campeonato não encontrado!');
        return;
      }
      
      // Redirecionar para a tela de gerenciamento de partida
      const url = `php/escola/GerenciarPartida.php?id_camp=${id_camp}&id_partida=${id_partida}&id_fase=${id_fase}`;
      window.open(url, '_self');
    }
    
    /**
     * Reinicia uma partida (apaga estatísticas, reseta gols e vencedor)
     * @param {number} id_partida - ID da partida
     * @param {number} id_fase - ID da fase
     */
    function reiniciarPartida(id_partida, id_fase) {
      if (!confirm('Tem certeza que deseja reiniciar esta partida?\n\nIsso irá:\n- Apagar todas as estatísticas\n- Resetar os gols para 0x0\n- Remover o vencedor\n- Voltar o status para "Não iniciada"\n\nEsta ação não pode ser desfeita!')) {
        return;
      }
      
      const id_camp = getCampId();
      
      if (!id_camp) {
        showNotification('error', 'ID do campeonato não encontrado!');
        return;
      }
      
      // Mostrar loading
      const loadingMsg = document.createElement('div');
      loadingMsg.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Reiniciando partida...';
      loadingMsg.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 1rem; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.3); z-index: 9999;';
      document.body.appendChild(loadingMsg);
      
      // Fazer requisição para reiniciar partida
      fetch('Banco/api_campeonato.php?action=reiniciar_partida&id_camp=' + id_camp + '&id_partida=' + id_partida + '&id_fase=' + id_fase, {
        method: 'GET'
      })
      .then(response => response.json())
      .then(data => {
        // Remover loading
        document.body.removeChild(loadingMsg);
        
        if (data.ok) {
          showNotification('success', 'Partida reiniciada com sucesso!');
          // Recarregar a lista de partidas
          loadPartidasContent();
        } else {
          showNotification('error', 'Erro: ' + data.error);
        }
      })
      .catch(error => {
        // Remover loading
        document.body.removeChild(loadingMsg);
        console.error('Erro:', error);
        showNotification('error', 'Erro ao reiniciar partida');
      });
      
    }
    
    function viewTeam(teamId) {
      showEditTeamModal(teamId);
    }
    
    function editTeam(teamId) {
      showEditTeamModal(teamId);
    }
    
    function deleteTeam(teamId, teamName) {
      if (confirm(`Tem certeza que deseja excluir o time "${teamName}"?\n\nEsta ação não pode ser desfeita e todos os jogadores do time serão removidos.`)) {
        // Implementar exclusão de time
        id_camp = getCampId();
        fetch('Banco/api_campeonato.php?action=delete_team&id_camp=' + id_camp + '&id_time=' + teamId, {
          method: 'GET'
        })
        .then(response => response.json())
        .then(data => {
          if (data.ok) {
            showNotification('success', 'Time excluído com sucesso!');
            loadTimesContent();
          } else {
            showNotification('error', 'Erro: ' + data.error);
          }
        })
        .catch(error => {
          console.error('Erro:', error);
          showNotification('error', 'Erro ao excluir time');
        });
      }
    }
    
    function showAddTeamModal() {
      // Criar modal dinamicamente
      const modal = document.createElement('div');
      modal.className = 'modal fade show';
      modal.style.display = 'block';
      modal.innerHTML = `
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title"><i class="fas fa-plus"></i> Adicionar Novo Time</h5>
              <button type="button" class="btn-close" onclick="closeAddTeamModal()"></button>
            </div>
            <div class="modal-body">
              <form id="addTeamForm">
                <div class="mb-3">
                  <label for="new-team-name" class="form-label">Nome do Time</label>
                  <input type="text" class="form-control" id="new-team-name" placeholder="Digite o nome do time" required>
                </div>
                <div class="mb-3">
                  <label for="new-team-serie" class="form-label">Série</label>
                  <input type="text" class="form-control" id="new-team-serie" placeholder="Digite a série do time" required>
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" onclick="closeAddTeamModal()">Cancelar</button>
              <button type="button" class="btn btn-primary" onclick="addNewTeam()">
                <i class="fas fa-plus"></i> Adicionar Time
              </button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
    }
    
    function closeAddTeamModal() {
      const modal = document.querySelector('.modal');
      if (modal) {
        modal.remove();
      }
    }
    
    function addNewTeam() {
      const nome = document.getElementById('new-team-name').value.trim();
      const serie = document.getElementById('new-team-serie').value.trim();
      
      if (!nome || !serie) {
        showNotification('warning', 'Preencha todos os campos!');
        return;
      }
      
      const id_camp = getCampId();
      
      fetch('Banco/api_campeonato.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=adicionar_time&id_camp=${id_camp}&nome=${encodeURIComponent(nome)}&serie=${encodeURIComponent(serie)}`
      })
      .then(response => response.json())
      .then(data => {
        if (data.ok) {
          showNotification('success', 'Time adicionado com sucesso!');
          closeAddTeamModal();
          loadTimesContent(); // Recarregar lista de times
        } else {
          showNotification('error', 'Erro: ' + data.error);
        }
      })
      .catch(error => {
        console.error('Erro:', error);
        showNotification('error', 'Erro ao adicionar time');
      });
    }
    
    function showEditTeamModal(teamId) {
      // Criar modal dinamicamente
      const modal = document.createElement('div');
      modal.className = 'modal fade show';
      modal.style.display = 'block';
      modal.innerHTML = `
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title"><i class="fas fa-users"></i> Gerenciador de Time</h5>
              <button type="button" class="btn-close" onclick="closeModal()"></button>
            </div>
            <div class="modal-body">
              <div class="team-manager-tabs">
                <div class="tab-buttons">
                  <button class="tab-btn active" onclick="switchTab('team-info')">
                    <i class="fas fa-shield-alt"></i> Time
                  </button>
                  <button class="tab-btn" onclick="switchTab('players')">
                    <i class="fas fa-users"></i> Jogadores
                  </button>
                </div>
                
                <div class="tab-content">
                  <div id="team-info-tab" class="tab-pane active">
                    <h4><i class="fas fa-edit"></i> Informações do Time</h4>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="mb-3">
                          <label class="form-label"><i class="fas fa-shield-alt"></i> Nome do Time:</label>
                          <input type="text" class="form-control" id="team-name" value="">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="mb-3">
                          <label class="form-label"><i class="fas fa-layer-group"></i> Série:</label>
                          <input type="text" class="form-control" id="team-serie" value="">
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div id="players-tab" class="tab-pane">
                    <div class="add-player-section">
                      <h4><i class="fas fa-user-plus"></i> Adicionar Novo Jogador</h4>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Nome do Jogador:</label>
                            <input type="text" class="form-control" id="player-name">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Número da Camisa:</label>
                            <input type="number" class="form-control" id="player-number" min="1" max="99">
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Posição:</label>
                            <select class="form-control" id="player-position">
                              <option value="">Selecione a posição</option>
                              <option value="Goleiro">Goleiro</option>
                              <option value="Zagueiro">Zagueiro</option>
                              <option value="Lateral">Lateral</option>
                              <option value="Volante">Volante</option>
                              <option value="Meio-campo">Meio-campo</option>
                              <option value="Atacante">Atacante</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="mb-3">
                            <label class="form-label">Idade:</label>
                            <input type="number" class="form-control" id="player-age" min="10" max="50">
                          </div>
                        </div>
                      </div>
                      <button class="btn btn-success" onclick="addJogador(${teamId})">
                        <i class="fas fa-plus"></i> Adicionar Jogador
                      </button>
                    </div>
                    
                    <div class="players-list-section">
                      <h4><i class="fas fa-users"></i> Jogadores do Time</h4>
                      <div class="jogadores-list" id="jogadores-list">
                        <div class="text-center">
                          <i class="fa-solid fa-spinner fa-spin"></i> Carregando jogadores...
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" onclick="closeModal()">Fechar</button>
              <button type="button" class="btn btn-primary" onclick="saveTeam(${teamId}, ${getCampId()})">
                <i class="fas fa-save"></i> Salvar Alterações
              </button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
      
      // Carregar dados do time e jogadores
      carregarDadosTime(teamId);
    }
    
    function carregarDadosTime(teamId) {
      // Carregar dados do time primeiro
      const id_camp = getCampId();
      fetch(`Banco/api_campeonato.php?action=carregar_times&id_camp=${id_camp}`)
      .then(response => response.json())
      .then(data => {
        if (data.ok) {
          const time = data.data.find(t => t.id == teamId);
          if (time) {
            const nameInput = document.getElementById('team-name');
            const serieInput = document.getElementById('team-serie');
            nameInput.value = time.nome;
            serieInput.value = time.serie;
            // Guardar valores originais para detecção de alterações
            nameInput.setAttribute('data-original', time.nome);
            serieInput.setAttribute('data-original', time.serie);
          }
        }
      });
      
      // Carregar jogadores
      fetch(`Banco/api_campeonato.php?action=carregar_jogadores&id_camp=${id_camp}&id_time=${teamId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      })
      .then(response => response.json())
      .then(data => {
        if (data.ok) {
          renderizarJogadores(data.data);
        } else {
          document.getElementById('jogadores-list').innerHTML = `
            <div class="alert alert-warning">
              <i class="fa-solid fa-exclamation-triangle"></i> ${data.error}
            </div>
          `;
        }
      })
      .catch(error => {
        console.error('Erro:', error);
        document.getElementById('jogadores-list').innerHTML = `
          <div class="alert alert-danger">
            <i class="fa-solid fa-exclamation-circle"></i> Erro ao carregar jogadores
          </div>
        `;
      });
    }
    
    function renderizarJogadores(jogadores) {
      const container = document.getElementById('jogadores-list');
      
      if (jogadores.length === 0) {
        container.innerHTML = `
          <div class="alert alert-info">
            <i class="fa-solid fa-info-circle"></i> Nenhum jogador encontrado.
          </div>
        `;
        return;
      }
      
      let html = '<div class="players-grid">';
      jogadores.forEach(jogador => {
        html += `
          <div class="player-card" data-player-id="${jogador.id}" data-team-id="${jogador.fkid_time}">
            <h5><i class="fas fa-user"></i> ${jogador.nome}</h5>
            <div class="player-info">
              <small><strong>Número:</strong> ${jogador.numero}</small>
              <small><strong>Posição:</strong> ${jogador.posicao}</small>
              <small><strong>Idade:</strong> ${jogador.idade || 'N/A'}</small>
              <small><strong>Gols:</strong> ${jogador.gols}</small>
              <small><strong>Assistências:</strong> ${jogador.assistencias}</small>
              <small><strong>Cartões Amarelos:</strong> ${jogador.cartoes_amarelos}</small>
              <small><strong>Cartões Vermelhos:</strong> ${jogador.cartoes_vermelhos}</small>
            </div>
            <div class="player-actions">
              <button class="btn btn-warning btn-sm" onclick="editJogador(${jogador.id}, ${jogador.fkid_time})">
                <i class="fas fa-edit"></i> Editar
              </button>
              <button class="btn btn-danger btn-sm" onclick="removerJogador(${jogador.id}, ${jogador.fkid_time})">
                <i class="fas fa-trash"></i> Remover
              </button>
            </div>
          </div>
        `;
      });
      html += '</div>';
      
      container.innerHTML = html;
    }
    
    function closeModal() {
      const modal = document.querySelector('.modal.show');
      if(modal) {
        modal.remove();
      }
    }
    
    function addJogador(teamId) {
      const nome = document.getElementById('player-name').value;
      const numero = document.getElementById('player-number').value;
      const posicao = document.getElementById('player-position').value;
      const idade = document.getElementById('player-age').value;
      
      if (!nome || !numero || !posicao) {
        showNotification('warning', 'Preencha todos os campos obrigatórios!');
        return;
      }
      
      fetch('Banco/api_campeonato.php?id_camp=' + getCampId() + '&action=adicionar_jogador&id_time=' + teamId + '&nome=' + nome + '&numero=' + numero + '&posicao=' + posicao + '&idade=' + idade)
      .then(response => response.json())
      .then(data => {
        if (data.ok) {
          showNotification('success', 'Jogador adicionado com sucesso!');
          // Limpar formulário
          document.getElementById('player-name').value = '';
          document.getElementById('player-number').value = '';
          document.getElementById('player-position').value = '';
          document.getElementById('player-age').value = '';
          carregarDadosTime(teamId); // Recarregar lista
        } else {
          showNotification('error', 'Erro: ' + data.error);
        }
      })
      .catch(error => {
        console.error('Erro:', error);
        showNotification('error', 'Erro ao adicionar jogador');
      });
    }
    
    function removerJogador(jogadorId, fkid_time) {
      if(confirm('Tem certeza que deseja remover este jogador?')) {
        fetch('Banco/api_campeonato.php?action=remover_jogador&id_jogador=' + jogadorId + '&id_camp=' + getCampId())
        .then(response => response.json())
        .then(data => {
          if (data.ok) {
            showNotification('success', 'Jogador removido com sucesso!');
            // Recarregar lista de jogadores
            carregarDadosTime(fkid_time);
          } else {
            showNotification('error', 'Erro: ' + data.error);
          }
        })
        .catch(error => {
          console.error('Erro:', error);
          showNotification('error', 'Erro ao remover jogador');
        });
      }
    }
    
    function saveTeam(teamId, id_camp) {
      const nome = document.getElementById('team-name').value;
      const serie = document.getElementById('team-serie').value;
      
      if (!nome || !serie) {
        showNotification('warning', 'Preencha todos os campos!');
        return;
      }
      
      // Verificar se houve mudanças
      const nameInput = document.getElementById('team-name');
      const serieInput = document.getElementById('team-serie');
      const originalName = nameInput.getAttribute('data-original') || '';
      const originalSerie = serieInput.getAttribute('data-original') || '';
      const changed = (nome !== originalName) || (serie !== originalSerie);
      if (!changed) {
        showNotification('info', 'Nenhuma alteração para salvar.');
        return;
      }

      const formData = new FormData();
      formData.append('action', 'salvar_time');
      formData.append('id_time', teamId);
      formData.append('nome', nome);  
      formData.append('serie', serie);

      console.log(formData.toString());
      fetch('Banco/api_campeonato.php?id_camp=' + id_camp + '&action=salvar_time&id_time=' + teamId + '&nome=' + encodeURIComponent(nome) + '&serie=' + encodeURIComponent(serie), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData.toString()
      })
      .then(response => response.json())
      .then(data => {
        if (data.ok) {
          showNotification('success', 'Time salvo com sucesso!');
          closeModal();
          loadTimesContent(); // Recarregar lista de times
        } else {
          showNotification('error', 'Erro: ' + data.error);
        }
      })
      .catch(error => {
        console.error('Erro:', error);
        showNotification('error', 'Erro ao salvar time');
      });
    }
    
    // Função para trocar abas no modal
    function switchTab(tabName) {
      // Remover active de todas as abas
      document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
      document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));
      
      // Adicionar active na aba selecionada
      event.target.classList.add('active');
      document.getElementById(tabName + '-tab').classList.add('active');
    }
    
    // Função para editar jogador
    function editJogador(jogadorId, fkid_time) {
      // Buscar dados do jogador atual
      const id_camp = getCampId();
      fetch(`Banco/api_campeonato.php?id_camp=${id_camp}&action=carregar_jogadores&id_time=${fkid_time}`)
        .then(response => response.json())
        .then(data => {
          if (!data.ok) return;
          const jogador = data.data.find(p => p.id == jogadorId);
          if (!jogador) return;
          const card = document.querySelector(`.player-card[data-player-id="${jogadorId}"]`);
          if (!card) return;
          card.innerHTML = `
            <h5><i class="fas fa-user"></i> <input type="text" class="form-control" id="edit-name-${jogadorId}" value="${jogador.nome.replace(/"/g, '&quot;')}"></h5>
            <div class="player-info">
              <div style="display:flex; flex-direction:column; gap:6px;">
                <small><strong>Número:</strong></small>
                <input type="number" class="form-control" id="edit-number-${jogadorId}" min="1" max="99" value="${jogador.numero}">
              </div>
              <div style="display:flex; flex-direction:column; gap:6px;">
                <small><strong>Posição:</strong></small>
                <select class="form-control" id="edit-position-${jogadorId}">
                  <option value="">Selecione a posição</option>
                  <option value="Goleiro">Goleiro</option>
                  <option value="Zagueiro">Zagueiro</option>
                  <option value="Lateral">Lateral</option>
                  <option value="Volante">Volante</option>
                  <option value="Meio-campo">Meio-campo</option>
                  <option value="Atacante">Atacante</option>
                </select>
              </div>
              <div style="display:flex; flex-direction:column; gap:6px;">
                <small><strong>Idade:</strong></small>
                <input type="number" class="form-control" id="edit-age-${jogadorId}" min="10" max="50" value="${jogador.idade || ''}">
              </div>
              <small><strong>Gols:</strong> ${jogador.gols}</small>
              <small><strong>Assistências:</strong> ${jogador.assistencias}</small>
              <small><strong>Cartões Amarelos:</strong> ${jogador.cartoes_amarelos}</small>
              <small><strong>Cartões Vermelhos:</strong> ${jogador.cartoes_vermelhos}</small>
            </div>
            <div class="player-actions">
              <button class="btn btn-primary btn-sm" onclick="saveJogadorInline(${jogadorId}, ${fkid_time})">
                <i class="fas fa-save"></i> Salvar
              </button>
              <button class="btn btn-secondary btn-sm" onclick="cancelarJogadorEdicao(${fkid_time})">
                <i class="fas fa-times"></i> Cancelar
              </button>
            </div>
          `;

          // Selecionar a posição atual
          const sel = document.getElementById(`edit-position-${jogadorId}`);
          if (sel) sel.value = jogador.posicao || '';
          // Guardar valores originais nos inputs para detecção de alterações
          document.getElementById(`edit-name-${jogadorId}`).setAttribute('data-original', jogador.nome);
          document.getElementById(`edit-number-${jogadorId}`).setAttribute('data-original', String(jogador.numero));
          document.getElementById(`edit-position-${jogadorId}`).setAttribute('data-original', jogador.posicao || '');
          document.getElementById(`edit-age-${jogadorId}`).setAttribute('data-original', jogador.idade ? String(jogador.idade) : '');
        })
        .catch(() => {});
    }

    function saveJogadorInline(jogadorId, fkid_time) {
      const nome = document.getElementById(`edit-name-${jogadorId}`).value.trim();
      const numero = document.getElementById(`edit-number-${jogadorId}`).value;
      const posicao = document.getElementById(`edit-position-${jogadorId}`).value;
      const idade = document.getElementById(`edit-age-${jogadorId}`).value;

      if (!nome || !numero || !posicao) {
        showNotification('warning', 'Preencha todos os campos obrigatórios!');
        return;
      }
      // Verificar alterações
      const on = document.getElementById(`edit-name-${jogadorId}`).getAttribute('data-original') || '';
      const onum = document.getElementById(`edit-number-${jogadorId}`).getAttribute('data-original') || '';
      const opos = document.getElementById(`edit-position-${jogadorId}`).getAttribute('data-original') || '';
      const oage = document.getElementById(`edit-age-${jogadorId}`).getAttribute('data-original') || '';
      const changed = (nome !== on) || (String(numero) !== onum) || (posicao !== opos) || (String(idade || '') !== oage);
      if (!changed) {
        showNotification('info', 'Nenhuma alteração para salvar.');
        cancelarJogadorEdicao(fkid_time);
        return;
      }

      fetch('Banco/api_campeonato.php?id_camp=' + getCampId() + '&action=editar_jogador&id_jogador=' + jogadorId + '&nome=' + encodeURIComponent(nome) + '&numero=' + encodeURIComponent(numero) + '&posicao=' + encodeURIComponent(posicao) + '&idade=' + encodeURIComponent(idade))
        .then(response => response.json())
        .then(data => {
          if (data.ok) {
            showNotification('success', 'Jogador atualizado com sucesso!');
            carregarDadosTime(fkid_time);
          } else {
            showNotification('error', 'Erro: ' + data.error);
          }
        })
        .catch(error => {
          console.error('Erro:', error);
          showNotification('error', 'Erro ao atualizar jogador');
        });
    }

    function cancelarJogadorEdicao(fkid_time) {
      carregarDadosTime(fkid_time);
    }
    
    // Função para cancelar edição de jogador
    function cancelarEdicaoJogador(fkid_time) {
      // Limpar formulário
      document.getElementById('player-name').value = '';
      document.getElementById('player-number').value = '';
      document.getElementById('player-position').value = '';
      document.getElementById('player-age').value = '';
      
      // Resetar botão
      const addBtn = document.querySelector('button[onclick*="saveJogadorEdit"]');
      if (addBtn) {
        addBtn.innerHTML = '<i class="fas fa-plus"></i> Adicionar Jogador';
        addBtn.onclick = () => addJogador(fkid_time);
      }
      
      // Remover botão de cancelar
      const cancelBtn = document.querySelector('.add-player-section .btn-secondary');
      if (cancelBtn) {
        cancelBtn.remove();
      }
    }
    
    // Função para salvar edição do jogador
    function saveJogadorEdit(jogadorId, fkid_time) {
      const nome = document.getElementById('player-name').value;
      const numero = document.getElementById('player-number').value;
      const posicao = document.getElementById('player-position').value;
      const idade = document.getElementById('player-age').value;
      
      if (!nome || !numero || !posicao) {
        alert('Preencha todos os campos obrigatórios!');
        return;
      }
      
      fetch('Banco/api_campeonato.php?action=editar_jogador&id_jogador=' + jogadorId + '&nome=' + nome + '&numero=' + numero + '&posicao=' + posicao + '&idade=' + idade)
      .then(response => response.json())
      .then(data => {
        if (data.ok) {
          alert('Jogador atualizado com sucesso!');
          // Limpar formulário e resetar botão
          document.getElementById('player-name').value = '';
          document.getElementById('player-number').value = '';
          document.getElementById('player-position').value = '';
          document.getElementById('player-age').value = '';
          
          // Resetar botão de adicionar
          const addBtn = document.querySelector('button[onclick*="saveJogadorEdit"]');
          if (addBtn) {
            addBtn.innerHTML = '<i class="fas fa-plus"></i> Adicionar Jogador';
            addBtn.onclick = () => addJogador(fkid_time);
          }
          
          // Remover botão de cancelar
          const cancelBtn = document.querySelector('.add-player-section .btn-secondary');
          if (cancelBtn) {
            cancelBtn.remove();
          }
          
          carregarDadosTime(fkid_time);
        } else {
          alert('Erro: ' + data.error);
        }
      })
      .catch(error => {
        console.error('Erro:', error);
        alert('Erro ao atualizar jogador');
      });
    }
  </script>
</html>
