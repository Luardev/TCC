<?php
  require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesGerenciar.php';

  if (isset($_GET['id_camp']) & isset($_GET['id_partida']) & isset($_GET['id_fase'])) {
    $id_camp = $_GET['id_camp'];
    $id_partida = $_GET['id_partida'];
    $id_fase = $_GET['id_fase'];
    $campeonato = buscarCampeonato($id_camp);
    $partida = buscarTimes($id_camp, $id_partida, $id_fase);
  }
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Partida - Gerenciar</title>

 <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&icon_names=add" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <!-- CSS base herdado do style.css -->
  <!-- <link rel="stylesheet" href="../../CSS/style.css"> -->
  <!-- CSS específico da tela de gerenciamento (prioridade) -->
  <link rel="stylesheet" href="../../CSS/gerenciar_partida.css" />
  <link rel="stylesheet" href="../../CSS/gerenciadorEscola.css">
</head>

<body>
<header>
  <div class="logo">
    <img
      src="https://cdn-icons-png.flaticon.com/512/3661/3661392.png"
      alt="Logo"
    />
    <span class="titulo_real">Painel de Gerenciamento</span>
  </div>

  <nav>
    <a href="php/escola/GerenciadorCampeonatos.php">Início</a>
    <a href="index.php">Sair</a>
  </nav>
</header>

  <main>
    <div class="dashboard-header">
      <button onclick="window.location.href='EdicaoCampeonato.php?id_camp=<?php echo $id_camp; ?>'" class="btn-back">
        <i class="fa-solid fa-arrow-left"></i> Voltar
      </button>
    </div>

    <section class="section" style="text-align: center;">
      <?php
        $row = $campeonato->fetch_assoc();
        echo "<h2>" . htmlspecialchars($row['nome']) . "</h2>";
        echo "<p>" . htmlspecialchars($row['escola']) . " | ". htmlspecialchars($row['ano']) ."</h2>";
      ?>  
    </section>

    <!-- Controles da Partida -->
    <section class="match-controls">
      <div class="control-buttons">
        <button id="btnIniciarPartida" class="btn-control iniciar" onclick="iniciarPartida()">
          <i class="fas fa-play"></i>
          INICIAR PARTIDA
        </button>
        <button id="btnEncerrarPartida" class="btn-control encerrar" onclick="encerrarPartida()" disabled>
          <i class="fas fa-stop"></i>
          ENCERRAR PARTIDA
        </button>
      </div>
      <div class="match-status-display">
        <span id="statusPartida" class="status-text">Partida não iniciada</span>
        <span id="tempoPartida" class="time-text">00:00</span>
      </div>
    </section>
    <?php
      $linha = $partida->fetch_assoc();
    ?>
    <section class="scoreboard-modern">
      <div class="team">
        <?php   
          echo '<a href="">';
            echo "<h3>".htmlspecialchars($linha['TIME_1'])."</h3>";
          echo '</a>';
        ?>
      </div>

      <div class="btn_gols">
        <button class="add_gols" onclick="mostrarSelecaoGol(1)">
          <i class="fas fa-futbol"></i>
          GOL
        </button>
        <button class="remove_gols" onclick="Remover_Gol_time_1()">
          <i class="fas fa-undo"></i>
          DESFAZER
        </button>
      </div>

      <div class="score">
        <?php echo '<span class="score-number1" id="gol_time_1">'.htmlspecialchars($linha['GOLS_TIME1']).'</span>';
        echo '<span class="score-separator">x</span>';
        echo '<span class="score-number2" id="gol_time_2">'.htmlspecialchars($linha['GOLS_TIME2']).'</span>';?>
      </div>

       <div class="btn_gols">
        <button class="add_gols" onclick="mostrarSelecaoGol(2)">
          <i class="fas fa-futbol"></i>
          GOL
        </button>
        <button class="remove_gols" onclick="Remover_Gol_time_2()">
          <i class="fas fa-undo"></i>
          DESFAZER
        </button>
      </div>

      <div class="team">
        <?php   
          echo '<a href="">';
            echo "<h3>".htmlspecialchars($linha['TIME_2'])."</h3>";
          echo '</a>';
        ?>
      </div>
    </section>

    <section class="section">
      <h2>Estatísticas</h2>
     
      <div class="stats-container">
    <div class="divisor_estatísticas">    
      <div class="title_estatisticas">Chutes ao Gol:</div>
      <div class="aling_estatisticas">
          <div class="add_estatisticas">
          
          <div style="display: flex; flex-direction: column; gap: 0.3em;">
          <button class="add" onclick="mostrarSelecaoEstatistica('Chute ao Gol', 1)">
            <i class="fas fa-plus"></i>
          </button>
          <button class="remove" onclick="removerEstatistica('Chute ao Gol', 1)">
            <i class="fas fa-minus"></i>
          </button>
          </div>
        </div>

       <div class="score" style="display: flex; flex-direction: row; align-items: center; gap: 3em;">
        <span class="score-number1">0</span>
        <span class="score-separator">x</span>
        <span class="score-number2">0</span>
      </div>


        <div class="add_estatisticas">
          
          <div style="display: flex; flex-direction: column; gap: 0.3em;">
          <button class="add" onclick="mostrarSelecaoEstatistica('Chute ao Gol', 2)">
            <i class="fas fa-plus"></i>
          </button>
          <button class="remove" onclick="removerEstatistica('Chute ao Gol', 2)">
            <i class="fas fa-minus"></i>
          </button>
          </div>
        </div>
      </div>
      </div>

 <div class="divisor_estatísticas">
        <div class="title_estatisticas">Faltas:</div>
      <div class="aling_estatisticas">
          <div class="add_estatisticas">
            <div style="display: flex; flex-direction: column; gap: 0.3em;">
              <button class="add" onclick="mostrarSelecaoEstatistica('Falta', 1)">+</button>
              <button class="remove" onclick="removerEstatistica('Falta', 1)">-</button>
          </div>
        </div>
      <div class="score" style="display: flex; flex-direction: row; align-items: center; gap: 3em;">
        <span class="score-number1">0</span>
        <span class="score-separator">x</span>
        <span class="score-number2">0</span>
      </div>

        <div class="add_estatisticas">
          <div style="display: flex; flex-direction: column; gap: 0.3em;">
          <button class="add" onclick="mostrarSelecaoEstatistica('Falta', 2)">+</button>
             <button class="remove" onclick="removerEstatistica('Falta', 2)">-</button>
          </div>
           
        </div>
        </div>
      </div>
      
      <div class="divisor_estatísticas">
       <div class="title_estatisticas">Cartões Amarelos:</div>
       <div class="aling_estatisticas">
          <div class="add_estatisticas">

          <div style="display: flex; flex-direction: column; gap: 0.3em;">
          <button class="add" onclick="mostrarSelecaoEstatistica('Cartão Amarelo', 1)">+</button>
           <button class="remove" onclick="removerEstatistica('Cartão Amarelo', 1)">-</button>
          </div>
        </div>
     <div class="score" style="display: flex; flex-direction: row; align-items: center; gap: 3em;">
        <span class="score-number1">0</span>
        <span class="score-separator">x</span>
        <span class="score-number2">0</span>
      </div>

        <div class="add_estatisticas">
          <div style="display: flex; flex-direction: column; gap: 0.3em;">
          <button class="add" onclick="mostrarSelecaoEstatistica('Cartão Amarelo', 2)">+</button>
            <button class="remove" onclick="removerEstatistica('Cartão Amarelo', 2)">-</button>
          </div>
           
        </div>
       </div>
      </div>
       
      <div class="divisor_estatísticas">
     <div class="title_estatisticas">Cartões Vermelhos:</div>
      <div class="aling_estatisticas">
          <div class="add_estatisticas">
            
          <div style="display: flex; flex-direction: column; gap: 0.3em;">
          <button class="add" onclick="mostrarSelecaoEstatistica('Cartão Vermelho', 1)">+</button>
           <button class="remove" onclick="removerEstatistica('Cartão Vermelho', 1)">-</button>
          </div>
        </div>
      <div class="score" style="display: flex; flex-direction: row; align-items: center; gap: 3em;">
        <span class="score-number1">0</span>
        <span class="score-separator">x</span>
        <span class="score-number2">0</span>
      </div>

        <div class="add_estatisticas">
          <div style="display: flex; flex-direction: column; gap: 0.3em;">
          <button class="add" onclick="mostrarSelecaoEstatistica('Cartão Vermelho', 2)">+</button>
            <button class="remove" onclick="removerEstatistica('Cartão Vermelho', 2)">-</button>
          </div>
           
        </div>
      </div>
    </section>

    <section class="section">
      <h2>Escalações</h2>
      <div class="lineup-container">        
          <?php 
            $id_time_1 = $linha['FKID_TIME1'];
            $id_camp = $linha['FKID_CAMP'];
            $result_jogadores_time1 = buscarJogadores($id_camp, $id_time_1);
            if (is_string($result_jogadores_time1)) {
              echo "<p>" . htmlspecialchars($result_jogadores_time1) . "</p>";
            } else {
              echo "<div class=\"lineup\">
                      <h3>" . htmlspecialchars($linha['TIME_1']) . "</h3>
                      <div class=\"players\">";
              while ($jogador = $result_jogadores_time1->fetch_assoc()) {
                $list_jogadores_time1[$jogador['ID_JOGADOR']] = [
                  'NOME' => $jogador['NOME'],
                  'POSICAO' => $jogador['POSICAO'],
                  'TIME' => $jogador['TIME'],
                  'QTD_GOL' => $jogador['QTD_GOL'],
                  'QTD_ASS' => $jogador['QTD_ASS'],
                  'AGE' => $jogador['IDADE'],
                  'ALTURA' => $jogador['ALTURA'],
                  'FALTAS' => $jogador['FALTAS'],
                  'CARTOES_AMARELOS' => $jogador['CARTOES_AMARELOS'],
                  'CARTOES_VERMELHOS' => $jogador['CARTOES_VERMELHOS'],
                  'NUMERO' => $jogador['NUMERO']
                ];
                echo "<button class=\"player-btn\" data-player=\"" . htmlspecialchars($jogador['ID_JOGADOR']) . "\">" . htmlspecialchars($jogador['NOME']) . "</button>";
              }
              echo "    </div>
                    </div>";
            }
          ?>
           
        <?php 
            $id_time_2 = $linha['FKID_TIME2'];
            $id_camp = $linha['FKID_CAMP'];
            $result_jogadores_time2 = buscarJogadores($id_camp, $id_time_2);
            if (is_string($result_jogadores_time2)) {
              echo "<p>" . htmlspecialchars($result_jogadores_time2) . "</p>";
            } else {
              echo "<div class=\"lineup\">
                      <h3>" . htmlspecialchars($linha['TIME_2']) . "</h3>
                      <div class=\"players\">";
              while ($jogador = $result_jogadores_time2->fetch_assoc()) {
                $list_jogadores_time2[$jogador['ID_JOGADOR']] = [
                  'NOME' => $jogador['NOME'],
                  'POSICAO' => $jogador['POSICAO'],
                  'TIME' => $jogador['TIME'],
                  'QTD_GOL' => $jogador['QTD_GOL'],
                  'QTD_ASS' => $jogador['QTD_ASS'],
                  'AGE' => $jogador['IDADE'],
                  'ALTURA' => $jogador['ALTURA'],
                  'FALTAS' => $jogador['FALTAS'],
                  'CARTOES_AMARELOS' => $jogador['CARTOES_AMARELOS'],
                  'CARTOES_VERMELHOS' => $jogador['CARTOES_VERMELHOS'],
                  'NUMERO' => $jogador['NUMERO']
                ];
                echo "<button class=\"player-btn\" data-player=\"" . htmlspecialchars($jogador['ID_JOGADOR']) . "\">" . htmlspecialchars($jogador['NOME']) . "</button>";
              }
              echo "    </div>
                    </div>";
            }
          ?>
      </div>
    </section>

    <div id="playerModal">
      <div>
        <button class="player-btn" onclick="closeModal()"><span>&#10005;</span></button>
        <h2 id="modalName"></h2>

        <p><strong>Idade:</strong> <span id="modalAge"></span></p>
        <p><strong>Faltas:</strong> <span id="modalFouls"></span></p>
        <p><strong>Time:</strong> <span id="modalTeam"></span></p>
        <p><strong>Gols:</strong> <span id="modalGoals"></span></p>
        <p><strong>Cartões Amarelos:</strong> <span id="modalYellow"></span></p>
        <p><strong>Cartões Vermelhos:</strong> <span id="modalRed"></span></p>

      </div>
    </div>

    <!-- Modal de Seleção de Jogador para Gol -->
    <div id="modalGol" class="modal-jogador">
      <div class="modal-content">
        <div class="modal-header">
          <h3 id="modalGolTitulo">Registrar Gol</h3>
          <button class="btn-close" onclick="fecharModalGol()">&times;</button>
        </div>
        <div class="modal-body">
          <div class="player-selection">
            <label>Jogador que fez o gol:</label>
            <select id="jogadorGol" class="selecao_jog_modal">
              <option value="">Selecione o jogador...</option>
            </select> 
            </select>
          </div>
          <div class="player-selection">
            <label>Jogador que deu a assistência (opcional):</label>
            <select id="jogadorAssistencia" class="selecao_jog_modal">
              <option value="">Selecione a assistência...</option>
              <option value="1">João Silva</option>
              <option value="2">Lucas Ferreira</option>
              <option value="3">Pedro Souza</option>
              <option value="4">Mateus Lima</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-confirm" onclick="registrarGol()">
            <i class="fas fa-save"></i>
            Registrar Gol
          </button>
          <button class="btn-cancel" onclick="fecharModalGol()">Cancelar</button>
        </div>
      </div>
    </div>

    <!-- Modal de Seleção de Jogador para Estatística -->
    <div id="modalEstatistica" class="modal-jogador">
      <div class="modal-content">
        <div class="modal-header">
          <h3 id="modalEstatisticaTitulo">Registrar Ação</h3>
          <button class="btn-close" onclick="fecharModalEstatistica()">&times;</button>
        </div>
        <div class="modal-body">
          <div class="player-selection">
            <label id="labelJogador">Selecione o jogador:</label>
            <select id="jogadorEstatistica" class="selecao_jog_modal">
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-confirm" onclick="registrarEstatistica()">
            <i class="fas fa-save"></i>
            Registrar Ação
          </button>
          <button class="btn-cancel" onclick="fecharModalEstatistica()">Cancelar</button>
        </div>
      </div>
    </div>
  </main>

  <footer id="contato" style="background: #0b0b14; color: #ccc; text-align: center; padding: 2rem; margin-top: 2rem;">
      <p>© 2025 Interclasse. Todos os direitos reservados.</p>
      <p>Participe do maior campeonato estudantil do Brasil!</p>
      <p>Contatos</p>
      <div style="margin-top: 1rem;">
        <a href="mailto:tccMain@gmail.com" style="color:#4a90e2; margin:0 10px;"><i class="fa-regular fa-envelope"></i></a>
      </div>
    </footer>

  <script>
    /* ===========================================
       VARIÁVEIS GLOBAIS
       =========================================== */
    let partidaIniciada = false; // Controla se a partida foi iniciada
    let tempoInicio = null; // Armazena o momento de início da partida
    let intervaloTempo = null; // Intervalo do cronômetro
    let acaoAtual = { tipo: '', time: 0, estatistica: '' }; // Armazena ação atual sendo processada
    const jogadoresTime1 = <?php
    $jogadores1 = [];
    $result_jogadores_time1 = buscarJogadores($linha['FKID_CAMP'], $linha['FKID_TIME1']);
    if (!is_string($result_jogadores_time1)) {
      while ($jogador = $result_jogadores_time1->fetch_assoc()) {
        $jogadores1[] = [
          'ID_JOGADOR' => $jogador['ID_JOGADOR'],
          'NOME' => $jogador['NOME']
        ];
      }
    }
    echo json_encode($jogadores1, JSON_UNESCAPED_UNICODE);
  ?>;
  const jogadoresTime2 = <?php
    $jogadores2 = [];
    $result_jogadores_time2 = buscarJogadores($linha['FKID_CAMP'], $linha['FKID_TIME2']);
    if (!is_string($result_jogadores_time2)) {
      while ($jogador = $result_jogadores_time2->fetch_assoc()) {
        $jogadores2[] = [
          'ID_JOGADOR' => $jogador['ID_JOGADOR'],
          'NOME' => $jogador['NOME']
        ];
      }
    }
    echo json_encode($jogadores2, JSON_UNESCAPED_UNICODE);
  ?>;
    /* ===========================================
       CONTROLE DA PARTIDA
       =========================================== */
    
    /**
     * Inicia a partida, ativando cronômetro e habilitando ações
     */
    function iniciarPartida() {
      if (!partidaIniciada) {
        // Obter parâmetros da URL
        const urlParams = new URLSearchParams(window.location.search);
        const id_camp = urlParams.get('id_camp');
        const id_partida = urlParams.get('id_partida');
        const id_fase = urlParams.get('id_fase');

        
        
        // Verificar se os parâmetros existem
        if (!id_camp || !id_partida || !id_fase) {
          mostrarNotificacao('Parâmetros da partida não encontrados!', 'error');
          return;
        }
        
        // Fazer requisição AJAX para iniciar partida no banco
        fetch('../../Banco/endpoints/iniciar_partida.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: `id_camp=${id_camp}&id_partida=${id_partida}&id_fase=${id_fase}`
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            partidaIniciada = true;
            tempoInicio = new Date();
            
            // Atualizar interface
            document.getElementById('btnIniciarPartida').disabled = true;
            document.getElementById('btnEncerrarPartida').disabled = false;
            document.getElementById('statusPartida').textContent = 'Partida em andamento';
            document.getElementById('statusPartida').className = 'status-text ativo';
            
            // Iniciar cronômetro (atualiza a cada segundo)
            intervaloTempo = setInterval(atualizarTempo, 1000);
            
            // Feedback visual
            mostrarNotificacao(data.message, 'success');
          } else {
            mostrarNotificacao(data.message, 'error');
          }
        })
        .catch(error => {
          console.error('Erro:', error);
          mostrarNotificacao('Erro ao iniciar partida no servidor!', 'error');
        });
      }
    }

    /**
     * Encerra a partida e salva os dados
     */
    function encerrarPartida() {
      if (partidaIniciada) {
        // Obter parâmetros da URL
        const urlParams = new URLSearchParams(window.location.search);
        const id_camp = urlParams.get('id_camp');
        const id_partida = urlParams.get('id_partida');
        const id_fase = urlParams.get('id_fase');
        
        // Verificar se os parâmetros existem
        if (!id_camp || !id_partida || !id_fase) {
          mostrarNotificacao('Parâmetros da partida não encontrados!', 'error');
          return;
        }
        
        // Fazer requisição AJAX para encerrar partida no banco
        fetch('../../Banco/endpoints/encerrar_partida.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: `id_camp=${id_camp}&id_partida=${id_partida}&id_fase=${id_fase}`
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            partidaIniciada = false;
            clearInterval(intervaloTempo);
            
            // Atualizar interface
            document.getElementById('btnIniciarPartida').disabled = true;
            document.getElementById('btnEncerrarPartida').disabled = true;
            document.getElementById('statusPartida').textContent = 'Partida encerrada';
            document.getElementById('statusPartida').className = 'status-text encerrada';
            
            // Feedback visual
            mostrarNotificacao(data.message, 'info');
          } else {
            mostrarNotificacao(data.message, 'error');
          }

          setTimeout(() => {
            window.location.href = 'EdicaoCampeonato.php?id_camp=' + id_camp;
          }, 2000);
        })
        .catch(error => {
          console.error('Erro:', error);
          mostrarNotificacao('Erro ao encerrar partida no servidor!', 'error');
          setTimeout(() => {
            window.location.href = 'EdicaoCampeonato.php?id_camp=' + id_camp;
          }, 2000);
        });
      }
    }

    /**
     * Atualiza o cronômetro da partida
     */
    function atualizarTempo() {
      if (tempoInicio) {
        const agora = new Date();
        const diferenca = Math.floor((agora - tempoInicio) / 1000);
        const minutos = Math.floor(diferenca / 60);
        const segundos = diferenca % 60;
        document.getElementById('tempoPartida').textContent = 
          `${minutos.toString().padStart(2, '0')}:${segundos.toString().padStart(2, '0')}`;
      }
    }
    /* ===========================================
       SISTEMA DE GOLS
       =========================================== */
    
    /**
     * Abre modal para seleção de jogador que fez o gol
     * @param {number} time - Número do time (1 ou 2)
     */
    function mostrarSelecaoGol(time) {
      if (!partidaIniciada) {
        mostrarNotificacao('Inicie a partida antes de registrar gols!', 'warning');
        return;
      }
      
      acaoAtual = { tipo: 'gol', time: time };
      document.getElementById('modalGolTitulo').textContent = `Registrar Gol - Time ${time === 1 ? 'A' : 'B'}`;
      document.getElementById('modalGol').style.display = 'flex';
      const jogadores = time === 1 ? jogadoresTime1 : jogadoresTime2;
      const selectGol = document.getElementById('jogadorGol');
      const selectAssist = document.getElementById('jogadorAssistencia');
      selectGol.innerHTML = '<option value="">Selecione o jogador...</option>';
      selectAssist.innerHTML = '<option value="">Selecione a assistência...</option>';
      jogadores.forEach(j => {
        selectGol.innerHTML += `<option value="${j.ID_JOGADOR}">${j.NOME}</option>`;
        selectAssist.innerHTML += `<option value="${j.ID_JOGADOR}">${j.NOME}</option>`;
      });
    }

    function registrarGol() {
      const jogadorGol = document.getElementById('jogadorGol').value;
      const jogadorAssistencia = document.getElementById('jogadorAssistencia').value;

      const campo = document.getElementById('jogadorGol');
      campo.focus();                         // coloca foco no campo
      document.getElementById('modalGol').scrollIntoView({ behavior: 'smooth', block: 'center' });  // rola suavemente até o formulário
      
      // Validação obrigatória
      if (!jogadorGol) {
        mostrarNotificacao('Selecione o jogador que fez o gol!', 'warning');
        return;
      }
      
      // Atualizar placar na interface
      const div = document.getElementById(`gol_time_${acaoAtual.time}`);
      let valorAtual = parseInt(div.textContent, 10);
      div.textContent = valorAtual + 1;
      
      // Animação de feedback
      div.style.transform = 'scale(1.2)';
      setTimeout(() => {
        div.style.transform = 'scale(1)';
      }, 200);
      
      // Salvar no banco de dados
      salvarGolNoBanco(jogadorGol, jogadorAssistencia, acaoAtual.time);
      
      // Fechar modal e limpar campos
      fecharModalGol();
      
      // Feedback ao usuário
      mostrarNotificacao('Gol registrado com sucesso!', 'success');
    }

    function salvarGolNoBanco(jogadorGol, jogadorAssistencia, time) {
      const urlParams = new URLSearchParams(window.location.search);
      const id_camp = urlParams.get('id_camp');
      const id_partida = urlParams.get('id_partida');
      const id_fase = urlParams.get('id_fase');
      const id_time = (time === 1) ? '<?php echo $linha['FKID_TIME1']; ?>' : '<?php echo $linha['FKID_TIME2']; ?>';

      fetch('../../Banco/endpoints/salvar_gol.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id_camp: id_camp,
          id_partida: id_partida,
          id_fase: id_fase,
          time: time,
          id_time: id_time,
          jogador_gol: jogadorGol,
          jogador_assistencia: jogadorAssistencia
        })
      })
      .then(response => response.json())
      .then(data => {
        if (!data.success) {
          mostrarNotificacao(data.message, 'error');
        }
      });
    }

    function fecharModalGol() {
      document.getElementById('modalGol').style.display = 'none';
      document.getElementById('jogadorGol').value = '';
      document.getElementById('jogadorAssistencia').value = '';
    }
    /* ===========================================
       SISTEMA DE ESTATÍSTICAS
       =========================================== */

    function mostrarSelecaoEstatistica(tipo, time) {
      if (!partidaIniciada) {
        mostrarNotificacao('Inicie a partida antes de registrar estatísticas!', 'warning');
        return;
      }
      
      acaoAtual = { tipo: 'estatistica', time: time, estatistica: tipo };
      
      // Configurar texto do modal baseado no tipo de estatística
      let titulo = '';
      let label = '';
      switch(tipo) {
        case 'Chute ao Gol':
          titulo = `Registrar Chute ao Gol - Time ${time === 1 ? 'A' : 'B'}`;
          label = 'Jogador que chutou ao gol:';
          break;
        case 'Falta':
          titulo = `Registrar Falta - Time ${time === 1 ? 'A' : 'B'}`;
          label = 'Jogador que cometeu a falta:';
          break;
        case 'Cartão Amarelo':
          titulo = `Registrar Cartão Amarelo - Time ${time === 1 ? 'A' : 'B'}`;
          label = 'Jogador que recebeu o cartão:';
          break;
        case 'Cartão Vermelho':
          titulo = `Registrar Cartão Vermelho - Time ${time === 1 ? 'A' : 'B'}`;
          label = 'Jogador que recebeu o cartão:';
          break;
      }
      
      // Atualizar interface do modal
      document.getElementById('modalEstatisticaTitulo').textContent = titulo;
      document.getElementById('labelJogador').textContent = label;
      document.getElementById('modalEstatistica').style.display = 'flex';
      document.getElementById('jogadorEstatistica').focus();                         // coloca foco no campo
      document.getElementById('modalEstatistica').scrollIntoView({ behavior: 'smooth', block: 'center' });  // rola suavemente até o formulário
      const jogadores = time === 1 ? jogadoresTime1 : jogadoresTime2;
      const select = document.getElementById('jogadorEstatistica');
      select.innerHTML = '<option value="">Selecione o jogador...</option>';
      jogadores.forEach(j => {
        select.innerHTML += `<option value="${j.ID_JOGADOR}">${j.NOME}</option>`;
      });
    }

    function registrarEstatistica() {
      const jogador = document.getElementById('jogadorEstatistica').value;
      
      // Validação obrigatória
      if (!jogador) {
        mostrarNotificacao('Selecione o jogador!', 'warning');
        return;
      }
      
      // Atualizar contador na interface
      const seletor = `.divisor_estatísticas:nth-of-type(${getNumeroSecao()}) .score-number${acaoAtual.time}`;
      const scoreElement = document.querySelector(seletor);
      if (scoreElement) {
        let valorAtual = parseInt(scoreElement.textContent, 10);
        scoreElement.textContent = valorAtual + 1;
        
        // Animação de feedback
        scoreElement.style.transform = 'scale(1.2)';
        setTimeout(() => {
          scoreElement.style.transform = 'scale(1)';
        }, 200);
      }
      console.log(jogador, acaoAtual.estatistica, acaoAtual.time);
      // Salvar no banco de dados
      salvarEstatisticaNoBanco(jogador, acaoAtual.estatistica, acaoAtual.time);
      
      // Fechar modal e limpar campos
      fecharModalEstatistica();
      
      // Feedback ao usuário
      mostrarNotificacao('Ação registrada com sucesso!', 'success');
    }

    function removerEstatistica(tipo, time) {
      if (!partidaIniciada) {
        mostrarNotificacao('A partida deve estar em andamento para remover estatísticas!', 'warning');
        return;
      }

      acaoAtual = { tipo: 'estatistica', time: time, estatistica: tipo };
      const seletor = `.divisor_estatísticas:nth-of-type(${getNumeroSecao()}) .score-number${time}`;
      const scoreElement = document.querySelector(seletor);
      
      if (scoreElement) {
        let valorAtual = parseInt(scoreElement.textContent, 10);
        if (valorAtual > 0) {
          // Obter parâmetros da URL
          const urlParams = new URLSearchParams(window.location.search);
          const id_camp = urlParams.get('id_camp');
          const id_partida = urlParams.get('id_partida');
          const id_fase = urlParams.get('id_fase');
          const id_time = (time === 1) ? '<?php echo $linha['FKID_TIME1']; ?>' : '<?php echo $linha['FKID_TIME2']; ?>';

          // Chamar endpoint para remover estatística do banco
          fetch('../../Banco/endpoints/remover_estatistica.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              id_camp: id_camp,
              id_partida: id_partida,
              id_fase: id_fase,
              time: time,
              id_time: id_time,
              tipo: tipo
            })
          })
          .then(response => response.json())
          .then(data => {
            if (data.success) {
              scoreElement.textContent = valorAtual - 1;
              
              // Animação de feedback
              scoreElement.style.transform = 'scale(0.8)';
              setTimeout(() => {
                scoreElement.style.transform = 'scale(1)';
              }, 200);
              
              mostrarNotificacao(data.message, 'success');
            } else {
              mostrarNotificacao(data.message, 'error');
            }
          })
          .catch(error => {
            console.error('Erro:', error);
            mostrarNotificacao('Erro ao remover estatística!', 'error');
          });
        } else {
          mostrarNotificacao('Não há estatísticas para remover!', 'warning');
        }
      }
    }

    function getNumeroSecao() {
      switch(acaoAtual.estatistica) {
        case 'Chute ao Gol': return 1;
        case 'Falta': return 2;
        case 'Cartão Amarelo': return 3;
        case 'Cartão Vermelho': return 4;
        default: return 1;
      }
    }

    function salvarEstatisticaNoBanco(jogador, tipo, time) {    
      const urlParams = new URLSearchParams(window.location.search);
      const id_camp = urlParams.get('id_camp');
      const id_partida = urlParams.get('id_partida');
      const id_fase = urlParams.get('id_fase');
      const id_time = (time === 1) ? '<?php echo $linha['FKID_TIME1']; ?>' : '<?php echo $linha['FKID_TIME2']; ?>';

      fetch('../../Banco/endpoints/salvar_estatisticas.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jogador: jogador,
          tipo: tipo,
          time: time,
          id_time: id_time,
          id_camp: id_camp,
          id_partida: id_partida,
          id_fase: id_fase
        })
      })
      .then(response => response.json())
      .then(data => {
        if (!data.success) {
          mostrarNotificacao(data.message, 'error');
        }
      }); 
      
    }

    /**
     * Fecha modal de estatística e limpa campos
     */
    function fecharModalEstatistica() {
      document.getElementById('modalEstatistica').style.display = 'none';
      document.getElementById('jogadorEstatistica').value = '';
    }

    /* ===========================================
       FUNÇÕES AUXILIARES
       =========================================== */
    
    /**
     * Funções de compatibilidade para gols (redirecionam para novo sistema)
     */
    function Adicionar_Gol_time_1() {
      mostrarSelecaoGol(1);
    }

    function Adicionar_Gol_time_2() {
      mostrarSelecaoGol(2);
    }

    /**
     * Exibe notificação toast para o usuário
     * @param {string} mensagem - Mensagem a ser exibida
     * @param {string} tipo - Tipo da notificação (success, warning, error, info)
     */
    function mostrarNotificacao(mensagem, tipo = 'info') {
      // Criar elemento de notificação
      const notificacao = document.createElement('div');
      notificacao.className = `notificacao ${tipo}`;
      notificacao.innerHTML = `
        <i class="fas fa-${getIconeNotificacao(tipo)}"></i>
        <span>${mensagem}</span>
      `;
      
      // Adicionar ao body
      document.body.appendChild(notificacao);
      
      // Mostrar com animação
      setTimeout(() => {
        notificacao.classList.add('show');
      }, 100);
      
      // Remover após 3 segundos
      setTimeout(() => {
        notificacao.classList.remove('show');
        setTimeout(() => {
          if (document.body.contains(notificacao)) {
            document.body.removeChild(notificacao);
          }
        }, 300);
      }, 3000);
    }

    /**
     * Retorna ícone baseado no tipo de notificação
     * @param {string} tipo - Tipo da notificação
     * @returns {string} Nome do ícone FontAwesome
     */
    function getIconeNotificacao(tipo) {
      switch(tipo) {
        case 'success': return 'check-circle';
        case 'warning': return 'exclamation-triangle';
        case 'error': return 'times-circle';
        default: return 'info-circle';
      }
    }

    /* ===========================================
       EVENT LISTENERS
       =========================================== */
    
    /**
     * Fecha modais ao clicar fora deles
     */
    window.onclick = function(event) {
      const modalGol = document.getElementById('modalGol');
      const modalEstatistica = document.getElementById('modalEstatistica');
      
      if (event.target === modalGol) {
        fecharModalGol();
      }
      if (event.target === modalEstatistica) {
        fecharModalEstatistica();
      }
    }

    /**
     * Remove gol do time 1 (função de compatibilidade)
     */
    function Remover_Gol_time_1() {
      if (!partidaIniciada) {
        mostrarNotificacao('A partida deve estar em andamento para remover gols!', 'warning');
        return;
      }

      const div = document.getElementById("gol_time_1");
      let valorAtual = parseInt(div.textContent, 10);
      if (valorAtual > 0) {
        // Obter parâmetros da URL
        const urlParams = new URLSearchParams(window.location.search);
        const id_camp = urlParams.get('id_camp');
        const id_partida = urlParams.get('id_partida');
        const id_fase = urlParams.get('id_fase');
        const id_time = '<?php echo $linha['FKID_TIME1']; ?>';

        // Chamar endpoint para remover gol do banco
        fetch('../../Banco/endpoints/remover_gol.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id_camp: id_camp,
            id_partida: id_partida,
            id_fase: id_fase,
            time: 1,
            id_time: id_time
          })
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            div.textContent = valorAtual - 1;
            // Animação de feedback
            div.style.transform = 'scale(0.8)';
            setTimeout(() => {
              div.style.transform = 'scale(1)';
            }, 200);
            mostrarNotificacao(data.message, 'success');
          } else {
            mostrarNotificacao(data.message, 'error');
          }
        })
        .catch(error => {
          console.error('Erro:', error);
          mostrarNotificacao('Erro ao remover gol!', 'error');
        });
      } else {
        mostrarNotificacao('Não há gols para remover!', 'warning');
      }
    }

    /**
     * Remove gol do time 2 (função de compatibilidade)
     */
    function Remover_Gol_time_2() {
      if (!partidaIniciada) {
        mostrarNotificacao('A partida deve estar em andamento para remover gols!', 'warning');
        return;
      }

      const div = document.getElementById("gol_time_2");
      let valorAtual = parseInt(div.textContent, 10);
      if (valorAtual > 0) {
        // Obter parâmetros da URL
        const urlParams = new URLSearchParams(window.location.search);
        const id_camp = urlParams.get('id_camp');
        const id_partida = urlParams.get('id_partida');
        const id_fase = urlParams.get('id_fase');
        const id_time = '<?php echo $linha['FKID_TIME2']; ?>';

        // Chamar endpoint para remover gol do banco
        fetch('../../Banco/endpoints/remover_gol.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id_camp: id_camp,
            id_partida: id_partida,
            id_fase: id_fase,
            time: 2,
            id_time: id_time
          })
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            div.textContent = valorAtual - 1;
            // Animação de feedback
            div.style.transform = 'scale(0.8)';
            setTimeout(() => {
              div.style.transform = 'scale(1)';
            }, 200);
            mostrarNotificacao(data.message, 'success');
          } else {
            mostrarNotificacao(data.message, 'error');
          }
        })
        .catch(error => {
          console.error('Erro:', error);
          mostrarNotificacao('Erro ao remover gol!', 'error');
        });
      } else {
        mostrarNotificacao('Não há gols para remover!', 'warning');
      }
    }

  </script>
</body>
</html>
