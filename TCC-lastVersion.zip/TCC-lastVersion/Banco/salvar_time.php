<?php
header('Content-Type: application/json; charset=utf-8');

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';

function ok($data) { 
    echo json_encode(['ok' => true, 'data' => $data], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

function err($msg) { 
    http_response_code(400); 
    echo json_encode(['ok' => false, 'error' => $msg], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

$id_time = isset($_POST['id_time']) ? intval($_POST['id_time']) : 0;
$nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
$serie = isset($_POST['serie']) ? trim($_POST['serie']) : '';

if ($id_time <= 0 || empty($nome) || empty($serie)) {
    err('Dados inválidos');
}

try {
    global $con;
    
    // Atualizar time
    $sql = "UPDATE times SET NOME = ?, SERIE = ? WHERE ID_TIME = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param('ssi', $nome, $serie, $id_time);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        ok(['message' => 'Time atualizado com sucesso']);
    } else {
        err('Erro ao atualizar time');
    }
    
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
}
?>
