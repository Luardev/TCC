<?php
header('Content-Type: application/json; charset=utf-8');

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';

function ok($data) { 
    echo json_encode(['ok' => true, 'data' => $data], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

function err($msg) { 
    http_response_code(400); 
    echo json_encode(['ok' => false, 'error' => $msg], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

$id_jogador = isset($_POST['id_jogador']) ? intval($_POST['id_jogador']) : 0;

if ($id_jogador <= 0) {
    err('ID do jogador inválido');
}

try {
    global $con;
    
    // Remover jogador
    $sql = "DELETE FROM jogadores WHERE ID_JOGADOR = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param('i', $id_jogador);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        ok(['message' => 'Jogador removido com sucesso']);
    } else {
        err('Jogador não encontrado');
    }
    
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
}
?>
