<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesBuscaCliente.php';

function ok($data) { 
    echo json_encode(['ok' => true, 'data' => $data], JSON_UNESCAPED_UNICODE); 
    exit; 
}

function err($msg) { 
    http_response_code(400); 
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE); 
    exit; 
}

// Verificar se é uma requisição OPTIONS (CORS preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$id_time = isset($_GET['id_time']) ? intval($_GET['id_time']) : 0;
$id_camp = isset($_GET['id_camp']) ? intval($_GET['id_camp']) : 0;

if ($id_time <= 0 || $id_camp <= 0) {    
    err('Parâmetros inválidos');
}

try {
    // Buscar estatísticas do time
    $result_time = buscarTimeEstatisticas($id_time, $id_camp);
    if (is_string($result_time)) {
        err($result_time);
    }
    $time_data = $result_time->fetch_assoc();

    // Buscar jogadores do time
    $result_jogadores = buscarJogadoresTime($id_camp, $id_time);
    $jogadores = [];
    if (!is_string($result_jogadores)) {
        while ($row = $result_jogadores->fetch_assoc()) {
            $jogadores[] = $row;
        }
        
        // Ordenar por gols (artilheiros)
        usort($jogadores, function($a, $b) {
            if ($b['QTD_GOL'] == $a['QTD_GOL']) {
                return 0;
            }
            return ($b['QTD_GOL'] < $a['QTD_GOL']) ? -1 : 1;
        });
    }

    // Calcular aproveitamento
    $totalPartidas = $time_data['Npartidas'];
    $vitorias = $time_data['VITORIAS'];
    $derrotas = $time_data['DERROTA'];
    
    $vitoriasPercent = $totalPartidas > 0 ? ($vitorias / $totalPartidas) * 100 : 0;
    $derrotasPercent = $totalPartidas > 0 ? ($derrotas / $totalPartidas) * 100 : 0;

    // Retornar dados consolidados
    ok([
        'time' => $time_data,
        'estatisticas' => [
            'partidas' => $time_data['Npartidas'],
            'vitorias' => $time_data['VITORIAS'],
            'derrotas' => $time_data['DERROTA'],
            'golsMarcados' => $time_data['GolsMarcados'],
            'golsSofridos' => $time_data['GolsSofridos'],
            'faltas' => $time_data['FALTA'],
            'cartoesAmarelos' => $time_data['CartoesAmarelos'],
            'cartoesVermelhos' => $time_data['CartoesVermelhos'],
            'jogadores' => $time_data['Njogadores']
        ],
        'artilheiros' => $jogadores,
        'aproveitamento' => [
            'totalPartidas' => $totalPartidas,
            'vitoriasPercent' => $vitoriasPercent,
            'derrotasPercent' => $derrotasPercent
        ],
        'timestamp' => time()
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
?>
