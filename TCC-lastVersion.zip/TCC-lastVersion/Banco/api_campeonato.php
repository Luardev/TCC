<?php
header('Content-Type: application/json; charset=utf-8');

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesOrganizarPartidas.php';

function ok($data) { 
    echo json_encode(['ok' => true, 'data' => $data], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

function err($msg) { 
    http_response_code(400); 
    echo json_encode(['ok' => false, 'error' => $msg], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}
        

$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';
$id_camp = isset($_REQUEST['id_camp']) ? $_REQUEST['id_camp'] : 0;

if ($id_camp <= 0) {    
    err('ID do campeonato inválido');
}

try {
    global $con;
    
    switch($action) {
        case 'sortear_partidas':
            $criados = preGerarChaveamento($id_camp, null, 5);
            $faseInicial = isset($criados['fase_inicial']) ? $criados['fase_inicial'] : 2;
            $preenchimento = preencherFaseInicialComTimes($id_camp, $faseInicial);
            ok(['message' => 'Partidas sorteadas com sucesso!', 'preGerado' => $criados, 'preenchimento' => $preenchimento]);
            break;
            
        case 'resortear_partidas':
            // Remover partidas existentes
            $sql = "DELETE FROM partidas WHERE FKID_CAMP = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_camp);
            $stmt->execute();
            
            // Remover estatísticas
            $sql = "DELETE FROM estatisticas_partida WHERE fkid_camp = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_camp);
            $stmt->execute();
            
            // Sortear novamente
            $criados = preGerarChaveamento($id_camp, null, 5);
            $faseInicial = isset($criados['fase_inicial']) ? $criados['fase_inicial'] : 2;
            $preenchimento = preencherFaseInicialComTimes($id_camp, $faseInicial);
            ok(['message' => 'Partidas resorteadas com sucesso!', 'preGerado' => $criados, 'preenchimento' => $preenchimento]);
            break;

        case 'reiniciar_partida':
            $id_partida = isset($_GET['id_partida']) ? intval($_GET['id_partida']) : 0;
            $id_camp = isset($_GET['id_camp']) ? intval($_GET['id_camp']) : 0;
            $id_fase = isset($_GET['id_fase']) ? intval($_GET['id_fase']) : 0;

            $sql = "UPDATE times
                INNER JOIN partidas 
                    ON partidas.FKID_TIME1 = times.ID_TIME 
                    AND partidas.FKID_CAMP = times.FKID_CAMP
                SET 
                    times.Npartidas = GREATEST(times.Npartidas - 1, 0),
                    times.GolsSofridos = GREATEST(times.GolsSofridos - partidas.GOLS_TIME2, 0),
                    times.GolsMarcados = GREATEST(times.GolsMarcados - partidas.GOLS_TIME1, 0)
                WHERE 
                    partidas.ID_PARTIDA = ?
                    AND partidas.FKID_CAMP = ?
                    AND partidas.FK_FASE = ?;
                ";

            $stmtTime1 = $con->prepare($sql);
            $stmtTime1->bind_param('iii', $id_partida, $id_camp, $id_fase);
            $stmtTime1->execute();

            $sql = "UPDATE times
                INNER JOIN partidas 
                    ON partidas.FKID_TIME2 = times.ID_TIME 
                    AND partidas.FKID_CAMP = times.FKID_CAMP
                SET 
                    times.Npartidas = GREATEST(times.Npartidas - 1, 0),
                    times.GolsSofridos = GREATEST(times.GolsSofridos - partidas.GOLS_TIME1, 0),
                    times.GolsMarcados = GREATEST(times.GolsMarcados - partidas.GOLS_TIME2, 0)
                WHERE 
                    partidas.ID_PARTIDA = ?
                    AND partidas.FKID_CAMP = ?
                    AND partidas.FK_FASE = ?;
                ";

            $stmtTime2 = $con->prepare($sql);
            $stmtTime2->bind_param('iii', $id_partida, $id_camp, $id_fase);
            $stmtTime2->execute();

            $sql = "UPDATE partidas A
                    INNER JOIN times B 
                        ON B.NOME = 'TBD' 
                    SET 
                        A.STATUS = 'N', 
                        A.GOLS_TIME1 = 0, 
                        A.GOLS_TIME2 = 0, 
                        A.FKID_TIME_VENCEDOR = B.ID_TIME
                    WHERE 
                        A.ID_PARTIDA = ? 
                        AND A.FKID_CAMP = ? 
                        AND A.FK_FASE = ?";
                        
            $stmt = $con->prepare($sql);
            $stmt->bind_param('iii', $id_partida, $id_camp, $id_fase);
            $stmt->execute();

            $sql = "DELETE FROM estatisticas_partida WHERE fkid_partida = ? AND fkid_fase = ? AND fkid_camp = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('iii', $id_partida, $id_fase, $id_camp);
            $stmt->execute();            

            ok(['message' => 'Partida reiniciada com sucesso']);
            break;
            
        case 'carregar_partidas':
            $sql = "SELECT 
                        A.ID_PARTIDA,
                        A.FK_FASE,
                        A.FKID_CAMP,
                        A.FKID_TIME1,
                        B.NOME AS TIME_1,
                        A.GOLS_TIME1,
                        A.FKID_TIME2,
                        C.NOME AS TIME_2,
                        A.GOLS_TIME2,
                        A.DATA_PARTIDA,
                        A.STATUS,
                        D.DETALHE AS FASE_NOME
                    FROM partidas A
                    LEFT JOIN times B ON A.FKID_TIME1 = B.ID_TIME AND A.FKID_CAMP = B.FKID_CAMP
                    LEFT JOIN times C ON A.FKID_TIME2 = C.ID_TIME AND A.FKID_CAMP = C.FKID_CAMP
                    INNER JOIN fases D ON A.FK_FASE = D.ID_FASE
                    WHERE A.FKID_CAMP = ?
                    ORDER BY A.FK_FASE, A.ID_PARTIDA";
            
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_camp);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $partidas = [];
            while ($row = $result->fetch_assoc()) {
                $fase = $row['FK_FASE'];
                if (!isset($partidas[$fase])) {
                    $partidas[$fase] = ['nome' => $row['FASE_NOME'], 'partidas' => []];
                }
                $partidas[$fase]['partidas'][] = [
                    'id_partida' => $row['ID_PARTIDA'],
                    'time1' => $row['TIME_1'] ?: 'TBD',
                    'time2' => $row['TIME_2'] ?: 'TBD',
                    'gols_time1' => $row['GOLS_TIME1'],
                    'gols_time2' => $row['GOLS_TIME2'],
                    'status' => $row['STATUS'],
                    'data' => $row['DATA_PARTIDA'],
                    'fase_nome' => $row['FASE_NOME'],
                    'fk_fase' => $row['FK_FASE'],
                    'fkid_camp' => $row['FKID_CAMP'],
                    'fkid_time1' => $row['FKID_TIME1'],
                    'fkid_time2' => $row['FKID_TIME2'],
                ];
            }
            ok($partidas);
            break;
            
        case 'carregar_times':
            $sql = "SELECT 
                        t.ID_TIME,
                        t.NOME,
                        t.SERIE,
                        COUNT(j.ID_JOGADOR) as total_jogadores
                    FROM times t
                    LEFT JOIN jogadores j ON t.ID_TIME = j.FKID_TIME
                    WHERE t.FKID_CAMP = ? AND t.NOME != 'TBD'
                    GROUP BY t.ID_TIME, t.NOME, t.SERIE
                    ORDER BY t.NOME";
            
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_camp);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $times = [];
            while ($row = $result->fetch_assoc()) {
                $times[] = [
                    'id' => $row['ID_TIME'],
                    'nome' => $row['NOME'],
                    'serie' => $row['SERIE'],
                    'jogadores' => $row['total_jogadores']
                ];
            }
            ok($times);
            break;
            
        case 'carregar_jogadores':
            $id_time = isset($_GET['id_time']) ? intval($_GET['id_time']) : 0;
            if ($id_time <= 0) err('ID do time inválido');
            
            $sql = "SELECT 
                        j.ID_JOGADOR,
                        j.NOME,
                        j.NUMERO,
                        j.POSICAO,
                        j.IDADE,
                        j.QTD_GOL,
                        j.QTD_ASS,
                        j.CARTOES_AMARELOS,
                        j.CARTOES_VERMELHOS,
                        j.FALTAS,
                        j.FKID_TIME
                    FROM jogadores j
                    WHERE j.FKID_TIME = ?
                    ORDER BY j.NUMERO";
            
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_time);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $jogadores = [];
            while ($row = $result->fetch_assoc()) {
                $jogadores[] = [
                    'id' => $row['ID_JOGADOR'],
                    'nome' => $row['NOME'],
                    'numero' => $row['NUMERO'],
                    'posicao' => $row['POSICAO'],
                    'idade' => $row['IDADE'],
                    'gols' => $row['QTD_GOL'],
                    'assistencias' => $row['QTD_ASS'],
                    'cartoes_amarelos' => $row['CARTOES_AMARELOS'],
                    'cartoes_vermelhos' => $row['CARTOES_VERMELHOS'],
                    'faltas' => $row['FALTAS'],
                    'fkid_time' => $row['FKID_TIME']
                ];
            }
            ok($jogadores);
            break;
            
        case 'adicionar_jogador':
            $id_time = isset($_REQUEST['id_time']) ? intval($_REQUEST['id_time']) : 0;
            $nome = isset($_REQUEST['nome']) ? trim($_REQUEST['nome']) : '';
            $numero = isset($_REQUEST['numero']) ? intval($_REQUEST['numero']) : 0;
            $posicao = isset($_REQUEST['posicao']) ? trim($_REQUEST['posicao']) : '';
            $idade = isset($_REQUEST['idade']) ? intval($_REQUEST['idade']) : 0;
            
            if ($id_time <= 0 || empty($nome) || $numero <= 0 || empty($posicao)) {
                err('Dados inválidos');
            }
            
            // Verificar se o número já existe
            $sql = "SELECT ID_JOGADOR FROM jogadores WHERE FKID_TIME = ? AND NUMERO = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('ii', $id_time, $numero);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                err('Número da camisa já existe neste time');
            }
            
            // Inserir jogador
            $sql = "INSERT INTO jogadores (FKID_TIME, NOME, NUMERO, POSICAO, IDADE, QTD_GOL, QTD_ASS, CARTOES_AMARELOS, CARTOES_VERMELHOS, FALTAS) 
                    VALUES (?, ?, ?, ?, ?, 0, 0, 0, 0, 0)";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('isisi', $id_time, $nome, $numero, $posicao, $idade);
            $stmt->execute();
            
            if ($stmt->affected_rows > 0) {
                ok(['message' => 'Jogador adicionado com sucesso', 'id' => $stmt->insert_id]);
            } else {
                err('Erro ao adicionar jogador');
            }
            break;
            
        case 'remover_jogador':
            $id_jogador = isset($_REQUEST['id_jogador']) ? intval($_REQUEST['id_jogador']) : 0;
            if ($id_jogador <= 0) err('ID do jogador inválido');
            
            $sql = "DELETE FROM jogadores WHERE ID_JOGADOR = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_jogador);
            $stmt->execute();
            
            if ($stmt->affected_rows > 0) {
                ok(['message' => 'Jogador removido com sucesso']);
            } else {
                err('Jogador não encontrado');
            }
            break;
            
        case 'salvar_time':
            $id_time = isset($_REQUEST['id_time']) ? intval($_REQUEST['id_time']) : 0;
            $nome = isset($_REQUEST['nome']) ? trim($_REQUEST['nome']) : '';
            $serie = isset($_REQUEST['serie']) ? trim($_REQUEST['serie']) : '';
            
            if ($id_time <= 0 || empty($nome) || empty($serie)) {
                err('Dados inválidos');
            }
            
            $sql = "UPDATE times SET NOME = ?, SERIE = ? WHERE ID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('ssi', $nome, $serie, $id_time);
            $stmt->execute();
            
            if ($stmt->affected_rows > 0) {
                ok(['message' => 'Time atualizado com sucesso']);
            } else {
                err('Erro ao atualizar time: ' . $stmt->error);
            }
            break;
        case 'delete_team':
            $id_time = isset($_REQUEST['id_time']) ? intval($_REQUEST['id_time']) : 0;
            if ($id_time <= 0) err('ID do time inválido');
            
            $sql = "DELETE FROM times WHERE ID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_time);
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                ok(['message' => 'Time removido com sucesso']);
            } else {
                err('Erro ao remover time');
            }
            break;
        case 'editar_jogador':
            $id_jogador = isset($_REQUEST['id_jogador']) ? intval($_REQUEST['id_jogador']) : 0;
            $nome = isset($_REQUEST['nome']) ? trim($_REQUEST['nome']) : '';
            $numero = isset($_REQUEST['numero']) ? intval($_REQUEST['numero']) : 0;
            $posicao = isset($_REQUEST['posicao']) ? trim($_REQUEST['posicao']) : '';
            $idade = isset($_REQUEST['idade']) ? intval($_REQUEST['idade']) : 0;
            
            if ($id_jogador <= 0 || empty($nome) || $numero <= 0 || empty($posicao)) {
                err('Dados inválidos');
            }
            
            // Verificar se o número já existe em outro jogador do mesmo time
            $sql = "SELECT ID_JOGADOR FROM jogadores WHERE FKID_TIME = (SELECT FKID_TIME FROM jogadores WHERE ID_JOGADOR = ?) AND NUMERO = ? AND ID_JOGADOR != ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('iii', $id_jogador, $numero, $id_jogador);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                err('Número da camisa já existe neste time');
            }
            
            // Atualizar jogador
            $sql = "UPDATE jogadores SET NOME = ?, NUMERO = ?, POSICAO = ?, IDADE = ? WHERE ID_JOGADOR = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('sissi', $nome, $numero, $posicao, $idade, $id_jogador);
            $stmt->execute();
            
            if ($stmt->affected_rows > 0) {
                ok(['message' => 'Jogador atualizado com sucesso']);
            } else {
                err('Erro ao atualizar jogador');
            }
            break;
            
        case 'adicionar_time':
            $nome = isset($_REQUEST['nome']) ? trim($_REQUEST['nome']) : '';
            $serie = isset($_REQUEST['serie']) ? trim($_REQUEST['serie']) : '';
            
            if (empty($nome) || empty($serie)) {
                err('Nome e série são obrigatórios');
            }
            
            // Verificar se já existe um time com o mesmo nome no campeonato
            $sql = "SELECT ID_TIME FROM times WHERE FKID_CAMP = ? AND NOME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('is', $id_camp, $nome);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                err('Já existe um time com este nome no campeonato');
            }
            
            // Inserir novo time
            $sql = "INSERT INTO times (FKID_CAMP, NOME, SERIE, GolsMarcados, GolsSofridos, Npartidas, CartoesAmarelos, CartoesVermelhos, Falta) 
                    VALUES (?, ?, ?, 0, 0, 0, 0, 0, 0)";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('iss', $id_camp, $nome, $serie);
            $stmt->execute();
            
            if ($stmt->affected_rows > 0) {
                ok(['message' => 'Time adicionado com sucesso', 'id_time' => $stmt->insert_id]);
            } else {
                err('Erro ao adicionar time');
            }
            break;
            
        case 'carregar_bracket':
            $sql = "SELECT 
                            A.ID_PARTIDA,
                            A.FK_FASE,
                            Z.DETALHE,
                            A.DATA_PARTIDA,
                            B.NOME AS TIME1,
                            A.GOLS_TIME1,
                            C.NOME AS TIME2,
                            A.GOLS_TIME2
                    FROM partidas A
                    INNER JOIN fases Z
                        ON A.FK_FASE = Z.ID_FASE
                    LEFT JOIN (
                        SELECT ID_TIME, NOME, FKID_CAMP FROM times
                    ) B ON A.FKID_TIME1 = B.ID_TIME AND A.FKID_CAMP = B.FKID_CAMP
                    LEFT JOIN (
                        SELECT ID_TIME, NOME, FKID_CAMP FROM times
                    ) C ON A.FKID_TIME2 = C.ID_TIME AND A.FKID_CAMP = C.FKID_CAMP
                    WHERE A.FKID_CAMP = ?
                    ORDER BY A.FK_FASE, A.ID_PARTIDA";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_camp);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {

                $id_fase_atual = null;
                $teams = [];
                $results = [];
                $menor_fase = PHP_INT_MAX;
                while ($row_fase = $result->fetch_assoc()) {
                    if ($row_fase['FK_FASE'] < $menor_fase) {
                      $menor_fase = $row_fase['FK_FASE'];
                    }
                }
                $result->data_seek(0);
                while ($row = $result->fetch_assoc()) {
                    // Pegar os jogos das primeiras fases para fazer a visualização do chaveamento
                    if ($row['FK_FASE'] == $menor_fase) {
                      $teams[] = [ [$row['TIME1']], [$row['TIME2']] ];
                    }
                    // Pegar os resultados de todos os jogos para apresentar:
                    $fase = (int)$row['FK_FASE'];
                    if (!isset($rounds[$fase])) {
                      $rounds[$fase] = [];
                    }
                    $rounds[$fase][] = [
                        "time1" => $row['TIME1'],
                        "time2" => $row['TIME2'],
                        "gols1" => (int)$row['GOLS_TIME1'],
                        "gols2" => (int)$row['GOLS_TIME2']
                    ];
                }
                ksort($rounds);

                // Apenas os valores em sequência (sub-arrays por fase)
                $results = [];
                foreach ($rounds as $fase => $partidas) {
                    $fase_result = [];
                    foreach ($partidas as $p) {
                        $fase_result[] = [ $p['gols1'], $p['gols2'] ];
                    }
                    $results[] = $fase_result;
                }
                ok(['teams' => $teams, 'results' => $results]);
            }
            else {
                err('Não foi possível carregar o chaveamento');
            }
            break;

        default:
        err('Ação inválida');
    }

    
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
}
?>
