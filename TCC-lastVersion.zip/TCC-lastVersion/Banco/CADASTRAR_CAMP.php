<?php
session_start();
require_once "../conexao.php";

if (!isset($_SESSION['login'])) {
    header('Location: ../login.php');
    exit();
}

// cadastrar o campeonato, depois cadastrar o nome, série e a FKID_CAMP nos times e por fim os jogadores altura, idade, nome e FKID_TIME

function test_input($data) {

    $data = trim($data);        // Remove espaços em branco no início e no fim
    $data = stripslashes($data); // Remove barras invertidas
    $data = htmlspecialchars($data); // Converte caracteres especiais em HTML

    // Verifica se o valor é numérico (float ou inteiro) e retorna o valor como float se for o caso
    if (is_numeric($data)) {
        return floatval($data); // Converte para float caso seja numérico
    }
    
    return $data; // Retorna o valor original se não for numérico
}

// Pega o JSON enviado via POST
$input = file_get_contents('php://input');
$data = json_decode($input, true);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST');
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Max-Age: 86400');

//$_SESSION['login']; == 'ANCHIETA'
// Verificação dos dados obrigatórios
if (
    empty($data['Nome']) || 
    empty($data['Tipo']) || 
    empty($data['Quantidade']) || 
    empty($data['Data']) || 
    empty($data['Estatisticas_Times']) || 
    !is_array($data['Estatisticas_Times'])
) {
    echo json_encode([
        'status' => false,
        'message' => 'Todos os campos são obrigatórios e Estatisticas_Times deve ser uma lista.'
    ]);
    exit;
}

try {
    $pega_IDESCOLA = $con->prepare("SELECT ID_ESCOLA FROM ESCOLAS WHERE NOME = ?");
    if (!$pega_IDESCOLA) {
        throw new Exception('Erro ao preparar a query para pegar o ID da escola: ' . $con->error);
    }

    $pega_IDESCOLA->bind_param('s', $_SESSION['login']);

    if (!$pega_IDESCOLA->execute()) {
        throw new Exception("Erro ao executar a query de selecionar o ID_ESCOLA: " . $pega_IDESCOLA->error);
    }

    // Aqui você precisa usar fetch_assoc para pegar os resultados
    $resultado = $pega_IDESCOLA->get_result();
    if ($resultado->num_rows > 0) {
        $ID = $resultado->fetch_assoc()['ID_ESCOLA'];
    } else {
        throw new Exception("Nenhuma escola encontrada para o nome: " . $_SESSION['login']);
    }

    $pega_IDESCOLA->close();

    $nome = test_input($data['Nome']);
    $tipo = test_input($data['Tipo']);
    $quantidade = (int) $data['Quantidade'];
    $data_campeonato = test_input($data['Data']);
    $nome_concat = '['.$ID.'] '.$nome;

    // Insere o campeonato
    $stmt = $con->prepare("INSERT INTO campeonato (fkid_escolas, nome, tipo, quantidade, data) VALUES (?, ?, ?, ?, ?)");
    if (!$stmt) throw new Exception("Erro ao preparar a query do campeonato: " . $con->error);

    $stmt->bind_param("sssis", $ID, $nome_concat, $tipo, $quantidade, $data_campeonato);

    if (!$stmt->execute()) {
        throw new Exception("Erro ao executar a query do campeonato: " . $stmt->error);
    }

    // Primeiro, insere o time
    $campeonato_id = $stmt->insert_id; // Presumo que você já tenha inserido o campeonato
    $stmt->close();

    // Pega o ID do campeonato inserido
    foreach ($data['Estatisticas_Times'] as $time) {
    
        // Insere o time
        $stmt_time = $con->prepare("INSERT INTO times (FKID_CAMP, NOME, SERIE) VALUES (?, ?, ?)");
        if (!$stmt_time) throw new Exception("Erro ao preparar a query do time: " . $con->error);
    
        $nome_time = test_input($time['Nome_time']);  // Acessando o Nome_time
        $serie = test_input($time['Serie']);          // Acessando a Serie
    
        $stmt_time->bind_param("iss", $campeonato_id, $nome_time, $serie);
    
        if (!$stmt_time->execute()) {
            throw new Exception("Erro ao executar a query do time: " . $stmt_time->error);
        }
    
        $time_id = $stmt_time->insert_id;
        $stmt_time->close();
    
        // Agora, insere os jogadores do time
        if (!empty($time['Jogadores'])) {
            
            $stmt_jogador = $con->prepare("INSERT INTO jogadores (FKID_TIME, NOME, ALTURA, IDADE) VALUES (?, ?, ?, ?)");
            if (!$stmt_jogador) throw new Exception("Erro ao preparar a query dos jogadores: " . $con->error);
    
            foreach ($time['Jogadores'] as $jogador) {
                $nome_jogador = test_input($jogador['nome']);    // Nome do jogador
                $altura = test_input($jogador['altura']);        // Altura do jogador 1.2,1.45,1.2
                $idade = test_input($jogador['idade']);          // Idade do jogador
    
                $stmt_jogador->bind_param("isdi", $time_id, $nome_jogador, $altura, $idade);
    
                if (!$stmt_jogador->execute()) {
                    throw new Exception("Erro ao executar a query do jogador: " . $stmt_jogador->error);
                }
            }
    
            $stmt_jogador->close();
        }
    }

    echo json_encode([
        'status' => true,
        'message' => 'Campeonato e jogadores cadastrados com sucesso!'
    ]);

} catch (Exception $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Erro: ' . $e->getMessage()
    ]);
    exit;
}
?>
