<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
    date_default_timezone_set('America/Sao_Paulo');

    function organizarPartidasBuscarTimes($id_camp){
        global $con;
        $sql = "SELECT ID_TIME, NOME, SERIE FROM times WHERE FKID_CAMP = ? and NOME != 'TBD' ORDER BY ID_TIME";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('i', $id_camp);
        $stmt->execute();
        $result = $stmt->get_result();

        $times = [];
        while ($row = $result->fetch_assoc()) {
            $times[] = $row; // ['ID_TIME' => int, 'NOME' => string, 'SERIE' => string]
        }

        return $times; // retorna array (pode estar vazio)
    }

    /**
     * Garante a existência de um time placeholder (ex.: 'TBD') para um campeonato e retorna seu ID.
     * Necessário pois a tabela de partidas exige NOT NULL e FKs para times.
     */
    function getOrCreatePlaceholderTime($id_camp){
        global $con;
        $nome = 'TBD';
        $serie = 'N/A';

        $check = $con->prepare("SELECT ID_TIME FROM times WHERE FKID_CAMP = ? AND NOME = ? LIMIT 1");
        $check->bind_param('is', $id_camp, $nome);
        $check->execute();
        $res = $check->get_result();
        if ($row = $res->fetch_assoc()) {
            return (int)$row['ID_TIME'];
        }

        $ins = $con->prepare("INSERT INTO times (FKID_CAMP, NOME, SERIE) VALUES (?, ?, ?)");
        $ins->bind_param('iss', $id_camp, $nome, $serie);
        $ins->execute();
        return (int)$ins->insert_id;
    }

    /**
     * Insere partidas "vazias" para uma fase, preenchendo com time placeholder.
     * Retorna as partidas criadas.
     */
    function inserirPartidasVazias($id_camp, $id_fase, $num_partidas){
        global $con;

        $placeholderId = getOrCreatePlaceholderTime($id_camp);

        $sqlMax = "SELECT COALESCE(MAX(ID_PARTIDA), 0) AS max_id FROM partidas WHERE FKID_CAMP = ? AND FK_FASE = ?";
        $stmtMax = $con->prepare($sqlMax);
        $stmtMax->bind_param('ii', $id_camp, $id_fase);
        $stmtMax->execute();
        $resMax = $stmtMax->get_result()->fetch_assoc();
        $nextId = ((int)$resMax['max_id']) + 1;

        $sqlInsert = "INSERT INTO partidas 
            (ID_PARTIDA, FK_FASE, FKID_CAMP, FKID_TIME1, FKID_TIME2, GOLS_TIME1, GOLS_TIME2, FKID_TIME_VENCEDOR)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sqlInsert);

        $created = [];
        for ($i = 0; $i < $num_partidas; $i++) {
            $t1 = $placeholderId;
            $t2 = $placeholderId;
            $g1 = 0;
            $g2 = 0;
            $vencedorPlaceholder = $placeholderId;

            $stmt->bind_param('iiiiiiis', $nextId, $id_fase, $id_camp, $t1, $t2, $g1, $g2, $vencedorPlaceholder);
            $stmt->execute();

            $created[] = [
                'ID_PARTIDA' => $nextId,
                'FK_FASE' => $id_fase,
                'FKID_CAMP' => $id_camp,
                'FKID_TIME1' => $t1,
                'FKID_TIME2' => $t2
            ];
            $nextId++;
        }

        return $created;
    }

    
    /**
     * Pré-gerar o chaveamento a partir da fase calculada até a final (5), criando jogos vazios com placeholder.
     * Retorna partidas criadas por fase e metadados do bracket.
     */
    function preGerarChaveamento($id_camp, $fase_inicial = null, $fase_final = 5){
        $calc = calcularBracketEFaseInicial($id_camp);
        $faseStart = $fase_inicial !== null ? $fase_inicial : $calc['fase_inicial'];
        $bracket = $calc['bracket'];

        $created = [];
        // No início (faseStart), número de jogos = bracket / 2; depois divide por 2 a cada fase
        for ($fase = $faseStart, $k = 0; $fase <= $fase_final; $fase++, $k++) {
            $numJogos = (int) max(1, $bracket / (1 << ($k + 1)));
            if ($numJogos < 1) { break; }
            $created[$fase] = inserirPartidasVazias($id_camp, $fase, $numJogos);
        }

        return [ 'created' => $created, 'fase_inicial' => $faseStart, 'bracket' => $bracket, 'num_times' => $calc['num_times'] ];
    }

    /**
     * Determina o bracket (potência de 2) e a fase inicial com base no número de times.
     * Retorna ['fase_inicial' => int, 'bracket' => int, 'num_times' => int].
     */
    function calcularBracketEFaseInicial($id_camp){
        $times = organizarPartidasBuscarTimes($id_camp);
        $numTimes = count($times);
        if ($numTimes < 2) {
            return [ 'fase_inicial' => 5, 'bracket' => 2, 'num_times' => $numTimes ];
        }
        // próxima potência de 2
        $bracket = 1;
        while ($bracket < $numTimes && $bracket < 16) { $bracket <<= 1; }
        if ($bracket < 2) { $bracket = 2; }
        if ($bracket > 16) { $bracket = 16; }

        // mapeia bracket para fase inicial suportada (2..5)
        // 16 -> fase 2, 8 -> fase 3, 4 -> fase 4, 2 -> fase 5
        $map = [ 16 => 2, 8 => 3, 4 => 4, 2 => 5 ];
        $faseInicial = isset($map[$bracket]) ? $map[$bracket] : 2;

        return [ 'fase_inicial' => $faseInicial, 'bracket' => $bracket, 'num_times' => $numTimes ];
    }

    /**
     * Preenche a fase inicial com os times existentes (embaralhados) e placeholders se necessário.
     */
    function preencherFaseInicialComTimes($id_camp, $fase_inicial){
        global $con;
        $calc = calcularBracketEFaseInicial($id_camp);
        $bracket = $calc['bracket'];

        // número de jogos na fase inicial = bracket / 2
        $numJogos = (int) max(1, $bracket / 2);

        $times = organizarPartidasBuscarTimes($id_camp);
        $ids = array_map(function($t){ return (int)$t['ID_TIME']; }, $times);
        shuffle($ids);

        $placeholderId = getOrCreatePlaceholderTime($id_camp);

        // Monta pares e atualiza partidas 1..$numJogos na fase inicial
        for ($jogo = 1, $i = 0; $jogo <= $numJogos; $jogo++, $i += 2) {
            $t1 = isset($ids[$i]) ? $ids[$i] : $placeholderId;
            $t2 = isset($ids[$i+1]) ? $ids[$i+1] : $placeholderId;
            $sql = "UPDATE partidas SET FKID_TIME1 = ?, FKID_TIME2 = ? WHERE FKID_CAMP = ? AND FK_FASE = ? AND ID_PARTIDA = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('iiiii', $t1, $t2, $id_camp, $fase_inicial, $jogo);
            $stmt->execute();
        }

        return [ 'fase_inicial' => $fase_inicial, 'num_jogos' => $numJogos ];
    }
    /**
     * Atualiza vencedor da partida atual e propaga para a próxima fase:
     * - próxima fase = fase_atual + 1
     * - partida de destino = ceil(id_partida_atual / 2)
     * - se id_partida_atual for ímpar, ocupa FKID_TIME1; se par, FKID_TIME2
     */
    function registrarVencedorEPropagar($id_camp, $fase_atual, $id_partida_atual){
        global $con;

        // 1) Atualiza vencedor na partida atual
        $upd = $con->prepare("UPDATE partidas SET FKID_TIME_VENCEDOR = IF(GOLS_TIME1 > GOLS_TIME2, FKID_TIME1, FKID_TIME2) WHERE FKID_CAMP = ? AND FK_FASE = ? AND ID_PARTIDA = ?");
        $upd->bind_param('iii',  $id_camp, $fase_atual, $id_partida_atual);
        $upd->execute();


        // 2) Calcula destino
        $proximaFase = $fase_atual + 1;
        $destinoPartida = (int)ceil($id_partida_atual / 2);
        $ocupaTime1 = ($id_partida_atual % 2 === 1);

        $sql = "SELECT 
                    A.FKID_TIME_VENCEDOR
                FROM partidas A
                WHERE A.FKID_CAMP = ? AND A.ID_PARTIDA = ? AND A.FK_FASE = ?;";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('iii', $id_camp, $id_partida_atual, $fase_atual);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $id_time_vencedor = $row['FKID_TIME_VENCEDOR'];

            // 3) Atualiza a partida destino
            if ($ocupaTime1) {
                $sql = "UPDATE partidas SET FKID_TIME1 = ? WHERE FKID_CAMP = ? AND FK_FASE = ? AND ID_PARTIDA = ?";
            } else {
                $sql = "UPDATE partidas SET FKID_TIME2 = ? WHERE FKID_CAMP = ? AND FK_FASE = ? AND ID_PARTIDA = ?";
            }
            $upd2 = $con->prepare($sql);
            $upd2->bind_param('iiii', $id_time_vencedor, $id_camp, $proximaFase, $destinoPartida);
            $upd2->execute();
            return [
                'fase_destino' => $proximaFase,
                'partida_destino' => $destinoPartida,
                'posicao' => $ocupaTime1 ? 'FKID_TIME1' : 'FKID_TIME2'
            ];
        } else {
            return "Não apresenta vencedor";
        }       
        
        
    }

    