<?php
// Test runner for FuncoesGerenciarPartidas.php
// Usage examples:
//  - pregerar (DB):
//    /tcc-main/Banco/tests/runner_partidas.php?action=pregerar&id_camp=83&data=2025-09-01
//  - propagar (DB):
//    /tcc-main/Banco/tests/runner_partidas.php?action=propagar&id_camp=83&fase_atual=2&id_partida=1&id_time_vencedor=23
//  - auto (DB): pregera fases 2-5 e preenche oitavas com times sorteados
//    /tcc-main/Banco/tests/runner_partidas.php?action=auto&id_camp=83&data=2025-09-01

header('Content-Type: application/json; charset=utf-8');

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesGerenciarPartidas.php';

function ok($data){ echo json_encode(['ok' => true, 'data' => $data], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); exit; }
function err($msg){ http_response_code(400); echo json_encode(['ok' => false, 'error' => $msg], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); exit; }

$action = isset($_GET['action']) ? $_GET['action'] : '';

/*
Endpoints:
Auto (pregera + preenche): .../runner_partidas.php?action=auto&id_camp=SEU_ID&data=YYYY-MM-DD
Propagar vencedor: .../runner_partidas.php?action=propagar&id_camp=SEU_ID&fase_atual=F&id_partida=N&id_time_vencedor=ID



*/





try {
    if ($action === 'propagar') {
        // Requires DB and existing partidas
        $idCamp = isset($_GET['id_camp']) ? intval($_GET['id_camp']) : 0;
        $faseAtual = isset($_GET['fase_atual']) ? intval($_GET['fase_atual']) : 0;
        $idPartida = isset($_GET['id_partida']) ? intval($_GET['id_partida']) : 0;
        $idVencedor = isset($_GET['id_time_vencedor']) ? intval($_GET['id_time_vencedor']) : 0;
        if ($idCamp <= 0 || $faseAtual <= 0 || $idPartida <= 0 || $idVencedor <= 0) {
            err('Parâmetros inválidos. Envie id_camp, fase_atual, id_partida, id_time_vencedor');
        }
        $res = registrarVencedorEPropagar($idCamp, $faseAtual, $idPartida, $idVencedor);
        ok($res);
    }

    if ($action === 'auto') {
        $idCamp = isset($_GET['id_camp']) ? intval($_GET['id_camp']) : 0;
        if ($idCamp <= 0) { err('id_camp inválido'); }

        // 1) Pré-gerar partidas vazias desde a fase correta até a final
        $criados = preGerarChaveamento($idCamp, null, 5, $data);

        // 2) Preencher a fase inicial calculada com os times atuais
        $faseInicial = isset($criados['fase_inicial']) ? $criados['fase_inicial'] : 2;
        $preenchimento = preencherFaseInicialComTimes($idCamp, $faseInicial);

        ok([
            'preGerado' => $criados,
            'preenchimento' => $preenchimento
        ]);
    }

    err('Ação inválida. Use action=pregerar|propagar|auto');
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
}


