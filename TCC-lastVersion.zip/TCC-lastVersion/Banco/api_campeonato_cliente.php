<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesBuscaCliente.php';

function ok($data) { 
    echo json_encode(['ok' => true, 'data' => $data], JSON_UNESCAPED_UNICODE); 
    exit; 
}

function err($msg) { 
    http_response_code(400); 
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE); 
    exit; 
}

// Verificar se é uma requisição OPTIONS (CORS preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$id_camp = isset($_GET['id_camp']) ? intval($_GET['id_camp']) : 0;
$id_partida = isset($_GET['id_partida']) ? intval($_GET['id_partida']) : null;
$fk_fase = isset($_GET['fk_fase']) ? intval($_GET['fk_fase']) : null;

if ($id_camp <= 0) {    
    err('ID do campeonato inválido');
}

try {
    // Buscar dados do campeonato
    $result_campeonato = buscarCampeonatos($id_camp);
    if (is_string($result_campeonato)) {
        err($result_campeonato);
    }
    $campeonato = $result_campeonato->fetch_assoc();

    // Buscar partidas com filtros opcionais
    $result_partidas = buscarPartidasFiltradas($id_camp, $id_partida, $fk_fase);
    $partidas = [];
    if (!is_string($result_partidas)) {
        while ($row = $result_partidas->fetch_assoc()) {
            $partidas[] = [
                'ID_PARTIDA' => $row['ID_PARTIDA'],
                'FK_FASE' => $row['FK_FASE'],
                'DETALHE' => $row['DETALHE'],
                'DATA_PARTIDA' => $row['DATA_PARTIDA'],
                'TIME1' => $row['TIME1'],
                'GOLS_TIME1' => $row['GOLS_TIME1'],
                'TIME2' => $row['TIME2'],
                'GOLS_TIME2' => $row['GOLS_TIME2'],
                'STATUS' => $row['STATUS']
            ];
        }
    }

    // Buscar artilheiros
    $result_artilheiros = buscarJogadores($id_camp);
    $artilheiros = [];
    if (!is_string($result_artilheiros)) {
        $artilheirosList = [];
        while ($row = $result_artilheiros->fetch_assoc()) {
            $artilheirosList[] = $row;
        }
        usort($artilheirosList, function($a, $b) {
            if ($a['QTD_GOL'] == $b['QTD_GOL']) {
                return 0;
            }
            return ($a['QTD_GOL'] < $b['QTD_GOL']) ? 1 : -1;
        });
        $artilheiros = array_slice($artilheirosList, 0, 10);
    }

    // Preparar dados para o chaveamento
    $teams = [];
    $results = [];
    if (!empty($partidas)) {
        $menor_fase = PHP_INT_MAX;
        foreach ($partidas as $partida) {
            if ($partida['FK_FASE'] < $menor_fase) {
                $menor_fase = $partida['FK_FASE'];
            }
        }

        $rounds = [];
        foreach ($partidas as $partida) {
            if ($partida['FK_FASE'] == $menor_fase) {
                $teams[] = [[$partida['TIME1']], [$partida['TIME2']]];
            }
            
            $fase = (int)$partida['FK_FASE'];
            if (!isset($rounds[$fase])) {
                $rounds[$fase] = [];
            }
            $rounds[$fase][] = [
                "time1" => $partida['TIME1'],
                "time2" => $partida['TIME2'],
                "gols1" => (int)$partida['GOLS_TIME1'],
                "gols2" => (int)$partida['GOLS_TIME2']
            ];
        }
        
        ksort($rounds);
        foreach ($rounds as $fase => $partidas_fase) {
            $fase_result = [];
            foreach ($partidas_fase as $p) {
                $fase_result[] = [$p['gols1'], $p['gols2']];
            }
            $results[] = $fase_result;
        }
    }

    // Retornar dados consolidados
    ok([
        'campeonato' => $campeonato,
        'partidas' => $partidas,
        'artilheiros' => $artilheiros,
        'chaveamento' => [
            'teams' => $teams,
            'results' => $results
        ],
        'filtros' => [
            'id_camp' => $id_camp,
            'id_partida' => $id_partida,
            'fk_fase' => $fk_fase
        ],
        'timestamp' => time()
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
?>
