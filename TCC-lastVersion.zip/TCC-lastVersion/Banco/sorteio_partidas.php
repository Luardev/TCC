<?php
header('Content-Type: application/json; charset=utf-8');

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesOrganizarPartidas.php';

function ok($data) { 
    echo json_encode(['ok' => true, 'data' => $data], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

function err($msg) { 
    http_response_code(400); 
    echo json_encode(['ok' => false, 'error' => $msg], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

$action = isset($_POST['action']) ? $_POST['action'] : '';
$id_camp = isset($_POST['id_camp']) ? intval($_POST['id_camp']) : 0;

if ($id_camp <= 0) {
    err('ID do campeonato inválido');
}

try {
    if ($action === 'sortear') {
        // Sortear partidas pela primeira vez
        $data = date('Y-m-d');
        $criados = preGerarChaveamento($id_camp, null, 5, $data);
        
        $faseInicial = isset($criados['fase_inicial']) ? $criados['fase_inicial'] : 2;
        $preenchimento = preencherFaseInicialComTimes($id_camp, $faseInicial);
        
        ok([
            'message' => 'Partidas sorteadas com sucesso!',
            'preGerado' => $criados,
            'preenchimento' => $preenchimento
        ]);
        
    } elseif ($action === 'resortear') {
        // Remover partidas existentes e sortear novamente
        global $con;
        
        // Deletar todas as partidas do campeonato
        $sql = "DELETE FROM partidas WHERE FKID_CAMP = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('i', $id_camp);
        $stmt->execute();
        
        // Deletar estatísticas relacionadas
        $sql = "DELETE FROM estatisticas_partida WHERE fkid_camp = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('i', $id_camp);
        $stmt->execute();
        
        // Sortear novamente
        $data = date('Y-m-d');
        $criados = preGerarChaveamento($id_camp, null, 5, $data);
        
        $faseInicial = isset($criados['fase_inicial']) ? $criados['fase_inicial'] : 2;
        $preenchimento = preencherFaseInicialComTimes($id_camp, $faseInicial);
        
        ok([
            'message' => 'Partidas resorteadas com sucesso!',
            'preGerado' => $criados,
            'preenchimento' => $preenchimento
        ]);
        
    } else {
        err('Ação inválida. Use action=sortear|resortear');
    }
    
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
}
?>
