<?php
header('Content-Type: application/json; charset=utf-8');

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesGerenciar.php';

function ok($data) { 
    echo json_encode(['ok' => true, 'data' => $data], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

function err($msg) { 
    http_response_code(400); 
    echo json_encode(['ok' => false, 'error' => $msg], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

$id_camp = isset($_GET['id_camp']) ? intval($_GET['id_camp']) : 0;

if ($id_camp <= 0) {
    err('ID do campeonato inválido');
}

try {
    global $con;
    
    // Buscar partidas por fase
    $sql = "SELECT 
                A.ID_PARTIDA,
                A.FK_FASE,
                A.FKID_CAMP,
                A.FKID_TIME1,
                B.NOME AS TIME_1,
                A.GOLS_TIME1,
                A.FKID_TIME2,
                C.NOME AS TIME_2,
                A.GOLS_TIME2,
                A.DATA_PARTIDA,
                A.STATUS,
                D.NOME AS FASE_NOME
            FROM partidas A
            LEFT JOIN times B ON A.FKID_TIME1 = B.ID_TIME AND A.FKID_CAMP = B.FKID_CAMP
            LEFT JOIN times C ON A.FKID_TIME2 = C.ID_TIME AND A.FKID_CAMP = C.FKID_CAMP
            INNER JOIN fases D ON A.FK_FASE = D.ID_FASE
            WHERE A.FKID_CAMP = ?
            ORDER BY A.FK_FASE, A.ID_PARTIDA";
    
    $stmt = $con->prepare($sql);
    $stmt->bind_param('i', $id_camp);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $partidas = [];
    while ($row = $result->fetch_assoc()) {
        $fase = $row['FK_FASE'];
        if (!isset($partidas[$fase])) {
            $partidas[$fase] = [
                'nome' => $row['FASE_NOME'],
                'partidas' => []
            ];
        }
        
        $partidas[$fase]['partidas'][] = [
            'id_partida' => $row['ID_PARTIDA'],
            'time1' => $row['TIME_1'] ?: 'TBD',
            'time2' => $row['TIME_2'] ?: 'TBD',
            'gols_time1' => $row['GOLS_TIME1'],
            'gols_time2' => $row['GOLS_TIME2'],
            'status' => $row['STATUS'],
            'data' => $row['DATA_PARTIDA']
        ];
    }
    
    ok($partidas);
    
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
}
?>
