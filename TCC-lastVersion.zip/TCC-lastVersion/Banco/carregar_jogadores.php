<?php
header('Content-Type: application/json; charset=utf-8');

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';

function ok($data) { 
    echo json_encode(['ok' => true, 'data' => $data], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

function err($msg) { 
    http_response_code(400); 
    echo json_encode(['ok' => false, 'error' => $msg], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

$id_time = isset($_GET['id_time']) ? intval($_GET['id_time']) : 0;

if ($id_time <= 0) {
    err('ID do time inválido');
}

try {
    global $con;
    
    // Buscar jogadores do time
    $sql = "SELECT 
                j.ID_JOGADOR,
                j.NOME,
                j.NUMERO,
                j.POSICAO,
                j.QTD_GOL,
                j.QTD_ASS,
                j.CARTOES_AMARELOS,
                j.CARTOES_VERMELHOS,
                j.FALTAS
            FROM jogadores j
            WHERE j.FKID_TIME = ?
            ORDER BY j.NUMERO";
    
    $stmt = $con->prepare($sql);
    $stmt->bind_param('i', $id_time);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $jogadores = [];
    while ($row = $result->fetch_assoc()) {
        $jogadores[] = [
            'id' => $row['ID_JOGADOR'],
            'nome' => $row['NOME'],
            'numero' => $row['NUMERO'],
            'posicao' => $row['POSICAO'],
            'gols' => $row['QTD_GOL'],
            'assistencias' => $row['QTD_ASS'],
            'cartoes_amarelos' => $row['CARTOES_AMARELOS'],
            'cartoes_vermelhos' => $row['CARTOES_VERMELHOS'],
            'faltas' => $row['FALTAS']
        ];
    }
    
    ok($jogadores);
    
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
}
?>
