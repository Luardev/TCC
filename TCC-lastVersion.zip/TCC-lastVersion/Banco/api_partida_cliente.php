<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesBuscaCliente.php';

// Funções de retorno
function ok($data) { 
    echo json_encode(['ok' => true, 'data' => $data], JSON_UNESCAPED_UNICODE); 
    exit; 
}

function err($msg) { 
    http_response_code(400); 
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE); 
    exit; 
}

// Função auxiliar para fetch_assoc seguro
function fetchAssocSafe($result) {
    if ($result && !is_string($result)) {
        return $result->fetch_assoc();
    }
    return null;
}

// Verificar se é uma requisição OPTIONS (CORS preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Receber parâmetros
$id_partida = isset($_GET['id_partida']) ? intval($_GET['id_partida']) : 0;
$id_camp = isset($_GET['id_camp']) ? intval($_GET['id_camp']) : 0;
$id_fase = isset($_GET['id_fase']) ? intval($_GET['id_fase']) : 0;

if ($id_partida <= 0 || $id_camp <= 0 || $id_fase <= 0) {    
    err('Parâmetros inválidos');
}

try {
    // Buscar dados da partida
    $partida = fetchAssocSafe(buscarUmaPartida($id_partida, $id_camp, $id_fase));
    if (!$partida) {
        err('Partida não encontrada');
    }

    // Buscar eventos da partida
    $result_eventos = buscarEventosPartida($id_partida, $id_fase, $id_camp);
    $eventos = [];
    if ($result_eventos && !is_string($result_eventos)) {
        while ($row = $result_eventos->fetch_assoc()) {
            $time = isset($row['FKID_TIME']) ? $row['FKID_TIME'] : 0;
            $jogador = isset($row['JOGADOR']) ? $row['JOGADOR'] : "";
            $evento = isset($row['TIPO_EVENTO']) ? $row['TIPO_EVENTO'] : "";
            $minuto = isset($row['minutos_partida']) ? $row['minutos_partida'] : 0;

            switch ($evento) {
                case "Gol": $classe = "gol"; $icone = "⚽"; break;
                case "Cartões amarelos": $classe = "amarelo"; $icone = "🟨"; break;
                case "Cartões vermelhos": $classe = "vermelho"; $icone = "🟥"; break;
                case "Faltas": $classe = "falta"; $icone = "🚩"; break;
                case "Chutes a gol": $classe = "chute"; $icone = "🎯"; break;
                case "Inicio Partida": $classe = "inicio"; $icone = "🕑"; break;
                case "Final Partida": $classe = "fim"; $icone = "🔔"; break;
                default: $classe = ""; $icone = "📌"; break;
            }

            if ($evento === "Inicio Partida" || $evento === "Final Partida") {
                $lado = "center";
            } else {
                $lado = ($time == $partida['FKID_TIME1']) ? "left" : "right";
            }

            $eventos[] = [
                'tipo' => $evento,
                'jogador' => $jogador,
                'minuto' => $minuto,
                'icone' => $icone,
                'classe' => $classe,
                'lado' => $lado,
                'time_id' => $time
            ];
        }
    }

    // Estatísticas dos times
    $estatisticas_time1 = [];
    $result_estatisticas_time1 = buscarEstatisticasAgrupadas($id_partida, $id_fase, $id_camp, $partida['FKID_TIME1']);
    if ($result_estatisticas_time1 && !is_string($result_estatisticas_time1)) {
        while ($row = $result_estatisticas_time1->fetch_assoc()) {
            $estatisticas_time1[$row['TIPO_EVENTO']] = $row['COUNT(*)'];
        }
    }

    $estatisticas_time2 = [];
    $result_estatisticas_time2 = buscarEstatisticasAgrupadas($id_partida, $id_fase, $id_camp, $partida['FKID_TIME2']);
    if ($result_estatisticas_time2 && !is_string($result_estatisticas_time2)) {
        while ($row = $result_estatisticas_time2->fetch_assoc()) {
            $estatisticas_time2[$row['TIPO_EVENTO']] = $row['COUNT(*)'];
        }
    }

    // Jogadores dos times
    $jogadores_time1 = [];
    $result_jogadores_time1 = buscarJogadoresTime($id_camp, $partida['FKID_TIME1']);
    if ($result_jogadores_time1 && !is_string($result_jogadores_time1)) {
        while ($jogador = $result_jogadores_time1->fetch_assoc()) {
            $jogadores_time1[$jogador['ID_JOGADOR']] = [
                'NOME' => $jogador['NOME'],
                'POSICAO' => $jogador['POSICAO'],
                'TIME' => $jogador['TIME'],
                'QTD_GOL' => $jogador['QTD_GOL'],
                'QTD_ASS' => $jogador['QTD_ASS'],
                'AGE' => $jogador['IDADE'],
                'ALTURA' => $jogador['ALTURA'],
                'FALTAS' => $jogador['FALTAS'],
                'CARTOES_AMARELOS' => $jogador['CARTOES_AMARELOS'],
                'CARTOES_VERMELHOS' => $jogador['CARTOES_VERMELHOS'],
                'NUMERO' => $jogador['NUMERO']
            ];
        }
    }

    $jogadores_time2 = [];
    $result_jogadores_time2 = buscarJogadoresTime($id_camp, $partida['FKID_TIME2']);
    if ($result_jogadores_time2 && !is_string($result_jogadores_time2)) {
        while ($jogador = $result_jogadores_time2->fetch_assoc()) {
            $jogadores_time2[$jogador['ID_JOGADOR']] = [
                'NOME' => $jogador['NOME'],
                'POSICAO' => $jogador['POSICAO'],
                'TIME' => $jogador['TIME'],
                'QTD_GOL' => $jogador['QTD_GOL'],
                'QTD_ASS' => $jogador['QTD_ASS'],
                'AGE' => $jogador['IDADE'],
                'ALTURA' => $jogador['ALTURA'],
                'FALTAS' => $jogador['FALTAS'],
                'CARTOES_AMARELOS' => $jogador['CARTOES_AMARELOS'],
                'CARTOES_VERMELHOS' => $jogador['CARTOES_VERMELHOS'],
                'NUMERO' => $jogador['NUMERO']
            ];
        }
    }

    // Retornar dados
    ok([
        'partida' => $partida,
        'placar' => ['time1' => $partida['GOLS_TIME1'], 'time2' => $partida['GOLS_TIME2']],
        'eventos' => $eventos,
        'estatisticas' => [
            'Chutes a Gol' => [
                'time1' => isset($estatisticas_time1['Chute ao Gol']) ? $estatisticas_time1['Chute ao Gol'] : 0,
                'time2' => isset($estatisticas_time2['Chute ao Gol']) ? $estatisticas_time2['Chute ao Gol'] : 0
            ],
            'Faltas' => [
                'time1' => isset($estatisticas_time1['Falta']) ? $estatisticas_time1['Falta'] : 0,
                'time2' => isset($estatisticas_time2['Falta']) ? $estatisticas_time2['Falta'] : 0
            ],
            'Cartões Amarelos' => [
                'time1' => isset($estatisticas_time1['Cartão Amarelo']) ? $estatisticas_time1['Cartão Amarelo'] : 0,
                'time2' => isset($estatisticas_time2['Cartão Amarelo']) ? $estatisticas_time2['Cartão Amarelo'] : 0
            ],
            'Cartões Vermelhos' => [
                'time1' => isset($estatisticas_time1['Cartão Vermelho']) ? $estatisticas_time1['Cartão Vermelho'] : 0,
                'time2' => isset($estatisticas_time2['Cartão Vermelho']) ? $estatisticas_time2['Cartão Vermelho'] : 0
            ]
        ],
        'jogadores' => ['time1' => $jogadores_time1, 'time2' => $jogadores_time2],
        'status' => isset($partida['STATUS']) ? $partida['STATUS'] : '',
        'timestamp' => time()
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
?>
