<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
    
    function buscarCampeonatos($id_camp) {
        global $con;
        $sql = "SELECT 
                    A.nome,
                    B.NOME AS escola,
                    year(A.data) as ano 
                FROM tcc_3infob.campeonato A
                INNER JOIN tcc_3infob.escolas B
                    ON A.fkid_escolas = B.id_escola
                WHERE A.id_camp = ?;";

        $query = $con->prepare($sql);
        $query->bind_param('i', $id_camp) ;
        $query->execute();
        $result = $query->get_result();

        if ($result->num_rows > 0) {
            return $result;
        }
        else {
            return "Não apresenta campeonato";
        }
    }

    function buscarPartidas($id_camp){
        global $con;
        $sql_partidas = "SELECT 
                            A.ID_PARTIDA,
                            A.FK_FASE,
                            Z.DETALHE,
                            A.DATA_PARTIDA,
                            B.NOME AS TIME1,
                            A.GOLS_TIME1,
                            C.NOME AS TIME2,
                            A.GOLS_TIME2,
                            A.STATUS
                    FROM partidas A
                    INNER JOIN fases Z
                        ON A.FK_FASE = Z.ID_FASE
                    LEFT JOIN (
                        SELECT ID_TIME, NOME, FKID_CAMP FROM times
                    ) B ON A.FKID_TIME1 = B.ID_TIME AND A.FKID_CAMP = B.FKID_CAMP
                    LEFT JOIN (
                        SELECT ID_TIME, NOME, FKID_CAMP FROM times
                    ) C ON A.FKID_TIME2 = C.ID_TIME AND A.FKID_CAMP = C.FKID_CAMP
                    WHERE A.FKID_CAMP = ?
                    ORDER BY A.FK_FASE, A.ID_PARTIDA";
        $query = $con->prepare($sql_partidas);
        $query->bind_param('i', $id_camp);
        $query->execute();
        $result_partidas = $query->get_result();
        if ($result_partidas->num_rows > 0){
            return $result_partidas;
        } else {
            return "Não apresenta partidas";
        }
    }

    function buscarUmaPartida($id_partida, $id_camp, $id_fase_atual){
        global $con;
        $sql_partidas = "SELECT 
                            A.ID_PARTIDA,
                            A.FK_FASE,
                            A.FKID_CAMP,
                            A.FKID_TIME1,
                            B.NOME AS TIME_1,
                            A.GOLS_TIME1,
                            A.FKID_TIME2,
                            C.NOME AS TIME_2,
                            A.GOLS_TIME2,
                            A.DATA_PARTIDA,
                            A.STATUS
                        FROM partidas A
                        LEFT JOIN times B
                            ON A.FKID_TIME1 = B.ID_TIME AND A.FKID_CAMP = B.FKID_CAMP
                        LEFT JOIN times C
                            ON A.FKID_TIME2 = C.ID_TIME AND A.FKID_CAMP = C.FKID_CAMP
                        INNER JOIN fases D
                            ON A.FK_FASE = D.ID_FASE
                        WHERE A.FKID_CAMP = ?
                            AND A.ID_PARTIDA = ?
                            AND A.FK_FASE = ?;";
        $query = $con->prepare($sql_partidas);
        $query->bind_param('iii', $id_camp, $id_partida, $id_fase_atual);
        $query->execute();
        $result_partidas = $query->get_result();
        if ($result_partidas->num_rows > 0){
            return $result_partidas;
        } else {
            return "Não apresenta partidas";
        }
    }

    function buscarJogadores($id_camp){
        global $con;
        $sql_jogadores = "SELECT 
            A.NOME,
            B.NOME AS TIME,
            A.QTD_GOL
        FROM jogadores a
        INNER JOIN times b
            ON a.FKID_TIME = b.ID_TIME
        INNER JOIN campeonato c
            ON b.FKID_CAMP = c.ID_CAMP
        WHERE C.ID_CAMP = ?
            ORDER BY QTD_GOL
        ;";
        $query = $con->prepare($sql_jogadores);
        $query->bind_param('i', $id_camp);
        $query->execute();
        $result_jogadores = $query->get_result();
        if ($result_jogadores->num_rows > 0){
            return $result_jogadores;
        } else {
            return "Não apresenta jogadores";
        }
    }
    function buscarJogadoresTime($id_camp, $id_time){
        global $con;
        $sql_jogadores = "SELECT 
            A.*,
            B.NOME AS TIME
        FROM jogadores a
        INNER JOIN times b
            ON a.FKID_TIME = b.ID_TIME
        WHERE B.FKID_CAMP = ?
            AND A.FKID_TIME = ?
            ORDER BY QTD_GOL
        ;";
        $query = $con->prepare($sql_jogadores);
        $query->bind_param('ii', $id_camp, $id_time);
        $query->execute();
        $result_jogadores = $query->get_result();
        if ($result_jogadores->num_rows > 0){
            return $result_jogadores;
        } else {
            return "Não apresenta jogadores";
        }
    }

    function buscarEstatisticasAgrupadas($id_partida, $id_fase_atual, $id_camp, $id_time) {
        global $con;
        $sql = "SELECT 
                    TIPO_EVENTO,
                    COUNT(*)
                FROM tcc_3infob.estatisticas_partida	A
                WHERE A.FKID_PARTIDA = ? AND A.FKID_FASE = ? AND A.FKID_CAMP = ? and FKID_TIME = ?
                GROUP BY TIPO_EVENTO;
            ";
        $query = $con->prepare($sql);
        $query->bind_param('iiii', $id_partida, $id_fase_atual, $id_camp, $id_time);
        $query->execute();
        $result = $query->get_result();
        if ($result->num_rows > 0) {
            return $result;
        } else {
            return False;
        }
    }

    function buscarEventosPartida($id_partida, $id_fase_atual, $id_camp) {
        global $con;
        $sql = "SELECT 
                A.ID_EVENTO,
                A.FKID_TIME,
                A.FKID_JOGADOR,
                B.NOME AS JOGADOR,
                A.TIPO_EVENTO,
                A.HORARIO,
                TIMESTAMPDIFF(MINUTE, Z.HORARIO, A.HORARIO) AS minutos_partida
            from estatisticas_partida A
            LEFT JOIN jogadores B
                ON A.FKID_JOGADOR = B.ID_JOGADOR 
                    AND A.FKID_TIME = B.FKID_TIME
            INNER JOIN estatisticas_partida	Z
                ON A.FKID_PARTIDA = Z.FKID_PARTIDA 
                AND A.FKID_CAMP = Z.FKID_CAMP 
                AND A.FKID_FASE = Z.FKID_FASE 
                AND Z.TIPO_EVENTO = 'Inicio Partida'
            WHERE A.FKID_PARTIDA = ? AND A.FKID_FASE = ? AND A.FKID_CAMP = ?
            ORDER BY A.HORARIO ASC;
            ";
        $query = $con->prepare($sql);
        $query->bind_param('iii', $id_partida, $id_fase_atual, $id_camp);
        $query->execute();
        $result = $query->get_result();
        if ($result->num_rows > 0) {
            return $result;
        } else {
            return "Não apresenta estatísticas";
        }
    }

    function buscarTimeEstatisticas($id_time, $id_camp) {
        global $con;
        $sql = "SELECT    
                    A.ID_TIME,
                    A.FKID_CAMP,
                    A.NOME AS TIME,
                    A.SERIE,
                    C.NOME AS ESCOLA,
                    A.Npartidas,
                    A.GolsMarcados,
                    A.GolsSofridos,
                    A.FALTA,
                    A.CartoesAmarelos,
                    A.CartoesVermelhos,
                    A.PONTOS,
                    A.NM_LOGO,
                    D.Njogadores,
                    E.VITORIAS,
                    E.DERROTA,
                    year(B.DATA) AS ANO    
                FROM tcc_3infob.times	A
                INNER JOIN campeonato	B
                    ON A.FKID_CAMP = B.ID_CAMP
                INNER JOIN escolas 		C
                    ON B.FKID_ESCOLAS = C.ID_ESCOLA
				left JOIN (
					SELECT FKID_TIME, COUNT(*) AS Njogadores
                    FROM jogadores
                    group by fkid_time
                ) D ON A.ID_TIME = D.FKID_TIME
                left join(
					SELECT 
						A.ID_TIME,
						A.FKID_CAMP,
						SUM(IF(A.ID_TIME = B.FKID_TIME_VENCEDOR, 1, 0)) AS VITORIAS,
						SUM(IF((A.ID_TIME != B.FKID_TIME_VENCEDOR) and (B.STATUS = 'T'), 1, 0)) AS DERROTA
					FROM times A
					INNER JOIN partidas	B
						ON (A.ID_TIME = B.FKID_TIME1 OR A.ID_TIME = B.FKID_TIME2) AND A.FKID_CAMP = B.FKID_CAMP
					GROUP BY A.ID_TIME, A.FKID_CAMP
                ) E ON A.ID_TIME = E.ID_TIME AND A.FKID_CAMP = E.FKID_CAMP
                WHERE A.ID_TIME = ? AND A.FKID_CAMP = ?;";
        $query = $con->prepare($sql);
        $query->bind_param('ii', $id_time, $id_camp);
        $query->execute();
        $result = $query->get_result();
        if ($result->num_rows > 0) {
            return $result;
        } else {
            return "Não apresenta time";
        }
    }
    function buscarPartidasFiltradas($id_camp, $id_partida = 0, $fk_fase = 0) {
        global $con;
        
        $sql = "SELECT 
                    A.ID_PARTIDA,
                    A.FK_FASE,
                    Z.DETALHE,
                    A.DATA_PARTIDA,
                    B.NOME AS TIME1,
                    A.GOLS_TIME1,
                    C.NOME AS TIME2,    
                    A.GOLS_TIME2,
                    A.STATUS
                FROM partidas A
                INNER JOIN fases Z
                    ON A.FK_FASE = Z.ID_FASE
                LEFT JOIN (
                    SELECT ID_TIME, NOME, FKID_CAMP FROM times
                ) B ON A.FKID_TIME1 = B.ID_TIME AND A.FKID_CAMP = B.FKID_CAMP
                LEFT JOIN (
                    SELECT ID_TIME, NOME, FKID_CAMP FROM times
                ) C ON A.FKID_TIME2 = C.ID_TIME AND A.FKID_CAMP = C.FKID_CAMP
                WHERE A.FKID_CAMP = ?";
        
        $params = [$id_camp];
        $types = 'i';
        
        if ($id_partida > 0) {
            $sql .= " AND A.ID_PARTIDA = ?";
            $params[] = $id_partida;
            $types .= 'i';
        }
        
        if ($fk_fase > 0) {
            $sql .= " AND A.FK_FASE = ?";
            $params[] = $fk_fase;
            $types .= 'i';
        }
        
        $sql .= " ORDER BY A.FK_FASE, A.ID_PARTIDA";
        
        $query = $con->prepare($sql);
        if ($query === false) {
            // Debug: retornar mensagem de erro do mysqli (opcional)
            return "Erro ao preparar a query: " . htmlspecialchars($con->error);
        }
    
        // bind_param requer variáveis por referência — usar call_user_func_array com refs
        // Primeiro montamos o array com o tipo como primeiro elemento
        $bind_params = array_merge([$types], $params);
    
        // Agora precisamos criar um array de referências (compatível com PHP < 5.6)
        $refs = [];
        foreach ($bind_params as $key => $value) {
            $refs[$key] = &$bind_params[$key];
        }
    
        // Executa bind_param dinamicamente
        call_user_func_array([$query, 'bind_param'], $refs);
    
        $query->execute();
        $result_partidas = $query->get_result();
    
        // Retorna resultado (mysqli_result) ou array vazio se não houver linhas
        if ($result_partidas && $result_partidas->num_rows > 0) {
            return $result_partidas;
        } else {
            return [];
        }
    }
    
?>