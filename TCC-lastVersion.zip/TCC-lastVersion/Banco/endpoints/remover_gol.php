<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesGerenciar.php';

// Configurar cabeçalhos para JSON
header('Content-Type: application/json');

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$id_camp = isset($data['id_camp']) ? intval($data['id_camp']) : null;
$id_partida = isset($data['id_partida']) ? intval($data['id_partida']) : null;
$id_fase = isset($data['id_fase']) ? intval($data['id_fase']) : null;
$time = isset($data['time']) ? intval($data['time']) : null;
$id_time = isset($data['id_time']) ? intval($data['id_time']) : null;

// Validar parâmetros
if (!$id_camp || !$id_partida || !$id_fase || !$time || !$id_time) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Parâmetros obrigatórios ausentes']);
    exit;
}

// Verificar se a partida está em andamento
$status = VerificarStatusPartida($id_camp, $id_partida, $id_fase);
if ($status !== 'I') {
    echo json_encode(['success' => false, 'message' => 'A partida deve estar em andamento para remover gols!']);
    exit;
}

try {
    // Chamar a função para remover o último gol
    $result = RemoverUltimoGol($id_camp, $id_fase, $id_partida, $time, $id_time);
    
    if ($result === true) {
        echo json_encode(['success' => true, 'message' => 'Gol removido com sucesso!']);
    } else {
        echo json_encode(['success' => false, 'message' => $result]);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro interno do servidor: ' . $e->getMessage()]);
}
?>

