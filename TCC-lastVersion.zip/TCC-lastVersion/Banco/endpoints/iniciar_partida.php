<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesGerenciar.php';
#require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesBuscaCliente.php';

// Configurar cabeçalhos para JSON
#header('Content-Type: application/json');

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

// Verificar se todos os parâmetros necessários foram enviados
$required_params = ['id_camp', 'id_partida', 'id_fase'];
foreach ($required_params as $param) {
    if (!isset($_POST[$param]) || empty($_POST[$param])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => "Parâmetro '$param' é obrigatório"]);
        exit;
    }
}

try {
    $id_camp = intval($_POST['id_camp']);
    $id_partida = intval($_POST['id_partida']);
    $id_fase = intval($_POST['id_fase']);
    
    $status = 'Inicio Partida';
    
    // Chamar a função para atualizar o status da partida
    $resultado = UpdateInicioFimPartida($id_camp, $id_partida, $id_fase, $status);
    if ($resultado) {
        echo json_encode([
            'success' => true, 
            'message' => 'Partida iniciada com sucesso!',
            'data' => [
                'id_camp' => $id_camp,
                'id_partida' => $id_partida,
                'id_fase' => $id_fase,
                'status' => $status
            ]
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Erro ao iniciar partida']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro interno do servidor: ' . $e->getMessage()]);
}
?>
