<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesGerenciar.php';

$data = json_decode(file_get_contents('php://input'), true);

$id_camp = isset($data['id_camp']) ? $data['id_camp'] : null;
$id_partida = isset($data['id_partida']) ? $data['id_partida'] : null;
$id_fase = isset($data['id_fase']) ? $data['id_fase'] : null;
$time = isset($data['time']) ? $data['time'] : null;
$id_time = isset($data['id_time']) ? $data['id_time'] : null;
$id_jogador = isset($data['jogador']) ? $data['jogador'] : null;
$tipo = isset($data['tipo']) ? $data['tipo'] : null;
echo "<pre>" . print_r($data, true) . "</pre>";
// Chama a função GerenciarEstatísticas
$result = GerenciarEstatisticas($id_camp, $id_fase, $id_partida, $time, $id_time, $id_jogador, $tipo);

if ($result === true) {
    echo json_encode(['success' => true, 'message' => 'Estatística registrada!']);
} else {
    echo json_encode(['success' => false, 'message' => $result]);
}
?>