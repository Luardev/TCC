<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesGerenciar.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesOrganizarPartidas.php';

date_default_timezone_set('America/Sao_Paulo');
// Configurar cabeçalhos para JSON
#header('Content-Type: application/json');

// Verificar se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

// Verificar se todos os parâmetros necessários foram enviados
$required_params = ['id_camp', 'id_partida', 'id_fase'];
foreach ($required_params as $param) {
    if (!isset($_POST[$param]) || empty($_POST[$param])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => "Parâmetro '$param' é obrigatório"]);
        exit;
    }
}

try {
    $id_camp = intval($_POST['id_camp']);
    $id_partida = intval($_POST['id_partida']);
    $id_fase = intval($_POST['id_fase']);
    
    $status = 'Final Partida';
    
    // Chamar a função para atualizar o status da partida
    $resultado = UpdateInicioFimPartida($id_camp, $id_partida, $id_fase, $status);
    $proxima_partida = registrarVencedorEPropagar($id_camp, $id_fase, $id_partida);
    
    if ($resultado) {
        echo json_encode([
            'success' => true, 
            'message' => 'Partida encerrada com sucesso!',
            'data' => [
                'id_camp' => $id_camp,
                'id_partida' => $id_partida,
                'id_fase' => $id_fase,
                'status' => $status
            ]
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Erro ao encerrar partida']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro interno do servidor: ' . $e->getMessage()]);
}

