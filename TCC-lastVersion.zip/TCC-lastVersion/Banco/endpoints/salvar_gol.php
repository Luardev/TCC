<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/Banco/FuncoesGerenciar.php';

$data = json_decode(file_get_contents('php://input'), true);

$id_camp = isset($data['id_camp']) ? $data['id_camp'] : null;
$id_partida = isset($data['id_partida']) ? $data['id_partida'] : null;
$id_fase = isset($data['id_fase']) ? $data['id_fase'] : null;
$time = isset($data['time']) ? $data['time'] : null;
$id_time = isset($data['id_time']) ? $data['id_time'] : null;
$jogador_gol = isset($data['jogador_gol']) ? $data['jogador_gol'] : null;
$jogador_assistencia = isset($data['jogador_assistencia']) ? $data['jogador_assistencia'] : null;


// Chama a função GerenciarGols
$result = GerenciarGols($id_camp, $id_fase, $id_partida, $time, $id_time,  $jogador_gol, $jogador_assistencia);

if ($result === true) {
    echo json_encode(['success' => true, 'message' => 'Gol registrado!']);
} else {
    echo json_encode(['success' => false, 'message' => $result]);
}
?>