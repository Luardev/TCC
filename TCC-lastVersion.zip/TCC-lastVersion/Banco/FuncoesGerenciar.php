<?php

    require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
    date_default_timezone_set('America/Sao_Paulo');

    function buscarCampeonato($id_camp) {
        global $con;
        $sql = "SELECT 
                    A.nome,
                    B.NOME AS escola,
                    year(A.data) as ano 
                FROM tcc_3infob.campeonato A
                INNER JOIN tcc_3infob.escolas B
                    ON A.fkid_escolas = B.id_escola
                WHERE A.id_camp = ?;";

        $query = $con->prepare($sql);
        $query->bind_param('i', $id_camp) ;
        $query->execute();
        $result = $query->get_result();

        if ($result->num_rows > 0) {
            return $result;
        }
        else {
            return "Não apresenta campeonato";
        }
    }

    function buscarTimes($id_camp, $id_partida, $fase){
        global $con;
        $sql = "SELECT 
                    A.ID_PARTIDA,
                    A.FK_FASE,
                    A.FKID_CAMP,
                    A.FKID_TIME1,
                    B.NOME AS TIME_1,
                    A.GOLS_TIME1,
                    A.FKID_TIME2,
                    C.NOME AS TIME_2,
                    A.GOLS_TIME2,
                    A.DATA_PARTIDA,
                    A.STATUS
                FROM partidas A
                LEFT JOIN times B
                    ON A.FKID_TIME1 = B.ID_TIME AND A.FKID_CAMP = B.FKID_CAMP
                LEFT JOIN times C
                    ON A.FKID_TIME2 = C.ID_TIME AND A.FKID_CAMP = C.FKID_CAMP
                INNER JOIN fases D
                    ON A.FK_FASE = D.ID_FASE
                WHERE A.FKID_CAMP = ?
                    AND A.ID_PARTIDA = ?
                    AND A.FK_FASE = ?;";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('iii', $id_camp, $id_partida, $fase);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            return $result;
        } else {
            return "Não apresenta times";
        }
    }

    function buscarJogadores($id_camp, $id_time){
        global $con;
        $sql = "SELECT 
                    A.*,
                    B.NOME AS TIME
                FROM jogadores A
                INNER JOIN times B
                    ON A.FKID_TIME = B.ID_TIME
                WHERE B.ID_TIME = ? and  B.FKID_CAMP = ?;";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('ii', $id_time, $id_camp);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            return $result;
        } else {
            return "Não apresenta jogadores";
        }
    }

    function UpdateInicioFimPartida($id_camp, $id_partida, $id_fase, $status){
        global $con;
        $sql = "UPDATE partidas SET STATUS = ? WHERE FKID_CAMP = ? AND ID_PARTIDA = ? AND FK_FASE = ?";
        $stmt = $con->prepare($sql);
        if ($status == 'Inicio Partida') {
            $novoStatus = 'I';
        } else {
            $novoStatus = 'T';

            $sqlData = "UPDATE partidas SET DATA_PARTIDA = NOW() WHERE FKID_CAMP = ? AND ID_PARTIDA = ? AND FK_FASE = ?";
            $stmtData = $con->prepare($sqlData);
            $stmtData->bind_param('iii', $id_camp, $id_partida, $id_fase);
            $stmtData->execute();
            // Quando encerrar a partida, atualizar GolsSofridos
            // Buscar os gols da partida
            $sqlGols = "SELECT FKID_TIME1, GOLS_TIME1, FKID_TIME2, GOLS_TIME2 
                        FROM partidas 
                        WHERE FKID_CAMP = ? AND ID_PARTIDA = ? AND FK_FASE = ?";
            $stmtGols = $con->prepare($sqlGols);
            $stmtGols->bind_param('iii', $id_camp, $id_partida, $id_fase);
            $stmtGols->execute();
            $resultGols = $stmtGols->get_result();
            
            if ($rowGols = $resultGols->fetch_assoc()) {
                $id_time1 = $rowGols['FKID_TIME1'];
                $gols_time1 = $rowGols['GOLS_TIME1'];
                $id_time2 = $rowGols['FKID_TIME2'];
                $gols_time2 = $rowGols['GOLS_TIME2'];
                
                // Time 1 sofreu os gols do Time 2
                $sqlUpdate1 = "UPDATE times SET GolsSofridos = GolsSofridos + ?, Npartidas = Npartidas + 1 WHERE ID_TIME = ?";
                $stmtUpdate1 = $con->prepare($sqlUpdate1);
                $stmtUpdate1->bind_param('ii', $gols_time2, $id_time1);
                $stmtUpdate1->execute();
                
                // Time 2 sofreu os gols do Time 1
                $sqlUpdate2 = "UPDATE times SET GolsSofridos = GolsSofridos + ?, Npartidas = Npartidas + 1 WHERE ID_TIME = ?";
                $stmtUpdate2 = $con->prepare($sqlUpdate2);
                $stmtUpdate2->bind_param('ii', $gols_time1, $id_time2);
                $stmtUpdate2->execute();
            }
        }
        $stmt->bind_param('siii',  $novoStatus, $id_camp, $id_partida, $id_fase);
        $stmt->execute();

        $horario = new DateTime();
        $horario = $horario->format('Y-m-d H:i:s'); // converte para string
        $sql = "INSERT INTO estatisticas_partida (fkid_partida, fkid_fase, fkid_camp, tipo_evento, horario)
                values (?, ?, ?, ?, ?)";

        $stmt = $con->prepare($sql);
        $stmt->bind_param('iiiss', $id_partida, $id_fase, $id_camp, $status, $horario);
        $stmt->execute();
        
        return $stmt->affected_rows > 0;

    }

    function GerenciarGols($id_camp, $id_fase, $id_partida, $time, $id_time, $id_jogadorGol, $id_jogadorAssistencia){
        global $con;

        // Atualiza o número de gols do time na tabela partidas
        if ($time == 1) {
            $sql = "UPDATE partidas SET GOLS_TIME1 = GOLS_TIME1 + 1 WHERE ID_PARTIDA = ? AND FK_FASE = ? AND FKID_CAMP = ?";
        } else {
            $sql = "UPDATE partidas SET GOLS_TIME2 = GOLS_TIME2 + 1 WHERE ID_PARTIDA = ? AND FK_FASE = ? AND FKID_CAMP = ?";
        }
        $stmt = $con->prepare($sql);
        $stmt->bind_param('iii', $id_partida, $id_fase, $id_camp);
        $stmt->execute();

        // Update nos jogadores que fez o gol e a assistência
       
        $sql = "UPDATE jogadores SET QTD_GOL = QTD_GOL + 1 WHERE ID_JOGADOR = ? AND FKID_TIME = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('ii', $id_jogadorGol, $id_time);
        $stmt->execute();
        
        
        $sql = "UPDATE jogadores SET QTD_ASS = QTD_ASS + 1 WHERE ID_JOGADOR = ? AND FKID_TIME = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('ii', $id_jogadorAssistencia, $id_time);
        $stmt->execute();
        

        //update no time que fez o gol
        $sql = "UPDATE times SET GolsMarcados = GolsMarcados + 1 WHERE ID_TIME = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('i', $id_time);
        $stmt->execute();

        // Insere o evento de gol na tabela estatisticas_partida
        $horario = new DateTime();
        $horario = $horario->format('Y-m-d H:i:s'); // converte para string
        $sql = "INSERT INTO estatisticas_partida (fkid_partida, fkid_fase, fkid_camp, fkid_time, fkid_jogador, tipo_evento, horario)
                VALUES (?, ?, ?, ?, ?, 'Gol', ?)";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('iiiiis', $id_partida, $id_fase, $id_camp, $id_time, $id_jogadorGol, $horario);
        $stmt->execute();

        return $stmt->affected_rows > 0;
    }

    function GerenciarEstatisticas($id_camp, $id_fase, $id_partida, $time, $id_time, $id_jogador, $tipo){
        global $con;

        // Update na estatística do jogador
        if ($tipo == 'Cartão Vermelho') {
            $sql = "UPDATE jogadores SET CARTOES_VERMELHOS = CARTOES_VERMELHOS + 1 WHERE ID_JOGADOR = ? AND FKID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('ii', $id_jogador, $id_time);
            $stmt->execute();

            $sql = "UPDATE times SET CartoesVermelhos = CartoesVermelhos + 1 WHERE ID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_time);
            $stmt->execute();
            
            $horario = new DateTime();
            $horario = $horario->format('Y-m-d H:i:s');
            $sql = "INSERT INTO estatisticas_partida (fkid_partida, fkid_fase, fkid_camp, fkid_time, fkid_jogador, tipo_evento, horario)
                    VALUES (?, ?, ?, ?, ?, 'Cartão Vermelho', ?)";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('iiiiis', $id_partida, $id_fase, $id_camp, $id_time, $id_jogador, $horario);
            $stmt->execute();
            return $stmt->affected_rows > 0;

        } elseif ($tipo == 'Cartão Amarelo') {
            $sql = "UPDATE jogadores SET CARTOES_AMARELOS = CARTOES_AMARELOS + 1 WHERE ID_JOGADOR = ? AND FKID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('ii', $id_jogador, $id_time);
            $stmt->execute();

            $sql = "UPDATE times SET CartoesAmarelos = CartoesAmarelos + 1 WHERE ID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_time);
            $stmt->execute();
            
            $horario = new DateTime();
            $horario = $horario->format('Y-m-d H:i:s');
            $sql = "INSERT INTO estatisticas_partida (fkid_partida, fkid_fase, fkid_camp, fkid_time, fkid_jogador, tipo_evento, horario)
                    VALUES (?, ?, ?, ?, ?, 'Cartão Amarelo', ?)";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('iiiiis', $id_partida, $id_fase, $id_camp, $id_time, $id_jogador, $horario);
            $stmt->execute();
            return $stmt->affected_rows > 0;

        } elseif ($tipo == 'Falta') {
            $sql = "UPDATE jogadores SET FALTAS = FALTAS + 1 WHERE ID_JOGADOR = ? AND FKID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('ii', $id_jogador, $id_time);
            $stmt->execute();

            $sql = "UPDATE times SET Falta = Falta + 1 WHERE ID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_time);
            $stmt->execute();
            
            $horario = new DateTime();
            $horario = $horario->format('Y-m-d H:i:s');
            $sql = "INSERT INTO estatisticas_partida (fkid_partida, fkid_fase, fkid_camp, fkid_time, fkid_jogador, tipo_evento, horario)
                    VALUES (?, ?, ?, ?, ?, 'Falta', ?)";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('iiiiis', $id_partida, $id_fase, $id_camp, $id_time, $id_jogador, $horario);
            $stmt->execute();
            return $stmt->affected_rows > 0;

        } elseif ($tipo == 'Chute ao Gol') {
            $horario = new DateTime();
            $horario = $horario->format('Y-m-d H:i:s');
            $sql = "INSERT INTO estatisticas_partida (fkid_partida, fkid_fase, fkid_camp, fkid_time, fkid_jogador, tipo_evento, horario)
                    VALUES (?, ?, ?, ?, ?, 'Chute ao Gol', ?)";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('iiiiis', $id_partida, $id_fase, $id_camp, $id_time, $id_jogador, $horario);
            $stmt->execute();
            return $stmt->affected_rows > 0;

        } else {
            return "Tipo de estatística inválido.";
        }
        
    }

    function RemoverUltimoGol($id_camp, $id_fase, $id_partida, $time, $id_time){
        global $con;

        // Buscar o último gol registrado para o time específico na partida
        $sql = "SELECT id_evento, fkid_jogador, fkid_jogador_assistencia 
                FROM estatisticas_partida 
                WHERE fkid_partida = ? 
                    AND fkid_fase = ? 
                    AND fkid_camp = ? 
                    AND fkid_time = ?
                    AND tipo_evento = 'Gol'
                ORDER BY horario DESC, id_evento DESC
                LIMIT 1";
        
        $stmt = $con->prepare($sql);
        $stmt->bind_param('iiii', $id_partida, $id_fase, $id_camp, $id_time);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 0) {
            return "Nenhum gol encontrado para remover.";
        }
        
        $row = $result->fetch_assoc();
        $id_evento = $row['id_evento'];
        $id_jogadorGol = $row['fkid_jogador'];
        $id_jogadorAssistencia = $row['fkid_jogador_assistencia'];
        
        // Remover da tabela estatisticas_partida
        $sql = "DELETE FROM estatisticas_partida WHERE id_evento = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('i', $id_evento);
        $stmt->execute();
        
        // Decrementar o número de gols do time na tabela partidas
        if ($time == 1) {
            $sql = "UPDATE partidas SET GOLS_TIME1 = GREATEST(0, GOLS_TIME1 - 1) WHERE ID_PARTIDA = ? AND FK_FASE = ? AND FKID_CAMP = ?";
        } else {
            $sql = "UPDATE partidas SET GOLS_TIME2 = GREATEST(0, GOLS_TIME2 - 1) WHERE ID_PARTIDA = ? AND FK_FASE = ? AND FKID_CAMP = ?";
        }
        $stmt = $con->prepare($sql);
        $stmt->bind_param('iii', $id_partida, $id_fase, $id_camp);
        $stmt->execute();
        
        // Decrementar gol do jogador que fez o gol
        if ($id_jogadorGol) {
            $sql = "UPDATE jogadores SET QTD_GOL = GREATEST(0, QTD_GOL - 1) WHERE ID_JOGADOR = ? AND FKID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('ii', $id_jogadorGol, $id_time);
            $stmt->execute();
        }
        
        // Decrementar assistência do jogador que deu a assistência
        if ($id_jogadorAssistencia) {
            $sql = "UPDATE jogadores SET QTD_ASS = GREATEST(0, QTD_ASS - 1) WHERE ID_JOGADOR = ? AND FKID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('ii', $id_jogadorAssistencia, $id_time);
            $stmt->execute();
        }
        
        // Decrementar gols marcados do time
        $sql = "UPDATE times SET GolsMarcados = GREATEST(0, GolsMarcados - 1) WHERE ID_TIME = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('i', $id_time);
        $stmt->execute();
        
        return true;
    }

    function RemoverUltimaEstatistica($id_camp, $id_fase, $id_partida, $time, $id_time, $tipo){
        global $con;

        // Buscar a última estatística registrada do tipo especificado para o time
        $sql = "SELECT id_evento, fkid_jogador 
                FROM estatisticas_partida 
                WHERE fkid_partida = ? 
                    AND fkid_fase = ? 
                    AND fkid_camp = ? 
                    AND fkid_time = ?
                    AND tipo_evento = ?
                ORDER BY horario DESC, id_evento DESC
                LIMIT 1";
        
        $stmt = $con->prepare($sql);
        $stmt->bind_param('iiiis', $id_partida, $id_fase, $id_camp, $id_time, $tipo);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 0) {
            return "Nenhuma estatística encontrada para remover.";
        }
        
        $row = $result->fetch_assoc();
        $id_evento = $row['id_evento'];
        $id_jogador = $row['fkid_jogador'];
        
        // Remover da tabela estatisticas_partida
        $sql = "DELETE FROM estatisticas_partida WHERE id_evento = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('i', $id_evento);
        $stmt->execute();
        
        // Decrementar estatística do jogador e do time baseado no tipo
        if ($tipo == 'Cartão Vermelho') {
            if ($id_jogador) {
                $sql = "UPDATE jogadores SET CARTOES_VERMELHOS = GREATEST(0, CARTOES_VERMELHOS - 1) WHERE ID_JOGADOR = ? AND FKID_TIME = ?";
                $stmt = $con->prepare($sql);
                $stmt->bind_param('ii', $id_jogador, $id_time);
                $stmt->execute();
            }
            
            $sql = "UPDATE times SET CartoesVermelhos = GREATEST(0, CartoesVermelhos - 1) WHERE ID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_time);
            $stmt->execute();
            
        } elseif ($tipo == 'Cartão Amarelo') {
            if ($id_jogador) {
                $sql = "UPDATE jogadores SET CARTOES_AMARELOS = GREATEST(0, CARTOES_AMARELOS - 1) WHERE ID_JOGADOR = ? AND FKID_TIME = ?";
                $stmt = $con->prepare($sql);
                $stmt->bind_param('ii', $id_jogador, $id_time);
                $stmt->execute();
            }
            
            $sql = "UPDATE times SET CartoesAmarelos = GREATEST(0, CartoesAmarelos - 1) WHERE ID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_time);
            $stmt->execute();
            
        } elseif ($tipo == 'Falta') {
            if ($id_jogador) {
                $sql = "UPDATE jogadores SET FALTAS = GREATEST(0, FALTAS - 1) WHERE ID_JOGADOR = ? AND FKID_TIME = ?";
                $stmt = $con->prepare($sql);
                $stmt->bind_param('ii', $id_jogador, $id_time);
                $stmt->execute();
            }
            
            $sql = "UPDATE times SET Falta = GREATEST(0, Falta - 1) WHERE ID_TIME = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param('i', $id_time);
            $stmt->execute();
        }
        // Nota: 'Chute ao Gol' não atualiza estatísticas de jogador/time, apenas remove o registro
        
        return true;
    }

    function VerificarStatusPartida($id_camp, $id_partida, $id_fase) {
        global $con;
        $sql = "SELECT STATUS FROM partidas WHERE FKID_CAMP = ? AND ID_PARTIDA = ? AND FK_FASE = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param('iii', $id_camp, $id_partida, $id_fase);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return $row['STATUS'];
        }
        return null;
    }
