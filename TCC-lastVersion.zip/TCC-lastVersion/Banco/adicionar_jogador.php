<?php
header('Content-Type: application/json; charset=utf-8');

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';

function ok($data) { 
    echo json_encode(['ok' => true, 'data' => $data], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

function err($msg) { 
    http_response_code(400); 
    echo json_encode(['ok' => false, 'error' => $msg], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

$id_time = isset($_POST['id_time']) ? intval($_POST['id_time']) : 0;
$nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
$numero = isset($_POST['numero']) ? intval($_POST['numero']) : 0;
$posicao = isset($_POST['posicao']) ? trim($_POST['posicao']) : '';

if ($id_time <= 0 || empty($nome) || $numero <= 0 || empty($posicao)) {
    err('Dados inválidos');
}

try {
    global $con;
    
    // Verificar se o número já existe no time
    $sql = "SELECT ID_JOGADOR FROM jogadores WHERE FKID_TIME = ? AND NUMERO = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param('ii', $id_time, $numero);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        err('Número da camisa já existe neste time');
    }
    
    // Inserir jogador
    $sql = "INSERT INTO jogadores (FKID_TIME, NOME, NUMERO, POSICAO, QTD_GOL, QTD_ASS, CARTOES_AMARELOS, CARTOES_VERMELHOS, FALTAS) 
            VALUES (?, ?, ?, ?, 0, 0, 0, 0, 0)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param('isis', $id_time, $nome, $numero, $posicao);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        ok(['message' => 'Jogador adicionado com sucesso', 'id' => $stmt->insert_id]);
    } else {
        err('Erro ao adicionar jogador');
    }
    
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
}
?>
