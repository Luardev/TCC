<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';

try {

    $cardData = "
        SELECT 
            c.ID_CAMP,
            SUBSTRING_INDEX(c.NOME, '-', -1) AS NOME,
            c.QUANTIDADE,
            c.DATA,
            c.FOTO,
            c.TIPO,
            (SELECT COUNT(*) FROM partidas p WHERE p.FKID_CAMP = c.ID_CAMP AND p.STATUS = 'I') AS PARTIDAS_ATIVAS,
            (SELECT COUNT(*) FROM partidas p WHERE p.FKID_CAMP = c.ID_CAMP AND p.STATUS = 'T') AS PARTIDAS_ENCERRADAS,
            (SELECT COUNT(*) FROM partidas p WHERE p.FKID_CAMP = c.ID_CAMP) AS TOTAL_PARTIDAS,
            (SELECT MIN(p.DATA_PARTIDA) FROM partidas p WHERE p.FKID_CAMP = c.ID_CAMP AND p.DATA_PARTIDA != '0000-00-00' AND p.DATA_PARTIDA IS NOT NULL) AS DATA_PRIMEIRA_PARTIDA
        FROM campeonato c
    ";
    $stmt = $con->prepare($cardData);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows >= 1) {

        while ($row = $result->fetch_assoc()) {
            $dados[] = $row;
        }

        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($dados);

    }else{

        echo json_encode([]);

    }

} catch (Exception $ex) {
    http_response_code(500);
    echo json_encode(['erro' => "Erro ao remover: " . $ex->getMessage()]);
}
?>