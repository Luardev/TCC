SELECT    
                    A.ID_TIME,
                    A.FKID_CAMP,
                    A.NOME AS TIME,
                    A.SERIE,
                    C.NOME AS ESCOLA,
                    A.Npartidas,
                    A.GolsMarcados,
                    A.GolsSofridos,
                    A.FALTA,
                    A.CartoesAmarelos,
                    A.CartoesVermelhos,
                    A.PONTOS,
                    A.NM_LOGO,
                    D.Njogadores,
                    year(B.DATA) AS ANO    
                FROM tcc_3infob.times	A
                INNER JOIN campeonato	B
                    ON A.FKID_CAMP = B.ID_CAMP
                INNER JOIN escolas 		C
                    ON B.FKID_ESCOLAS = C.ID_ESCOLA
				left JOIN (
					SELECT FKID_TIME, COUNT(*) AS Njogadores
                    FROM jogadores
                    group by fkid_time
                ) D ON A.ID_TIME = D.FKID_TIME
                WHERE A.ID_TIME = 27 AND A.FKID_CAMP = 84