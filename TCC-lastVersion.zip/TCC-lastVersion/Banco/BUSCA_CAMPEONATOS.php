<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/auth.php';

try {

$login = $_SESSION['login'];

$sql = "SELECT 
    A.*,
    DATE_FORMAT(A.DATA, '%d/%m/%Y') AS DATA_FORMATADA,
    SUBSTRING_INDEX(A.NOME, ' - ', -1) AS nome_limpo,
    
    -- Subquery para nomes dos times
    (
        SELECT GROUP_CONCAT(DISTINCT C.nome SEPARATOR ', ')
        FROM times C
        WHERE C.FKID_CAMP = A.ID_CAMP
    ) AS nomes_times,

    -- Subquery para nomes dos jogadores
    (
        SELECT GROUP_CONCAT(DISTINCT D.nome SEPARATOR ', ')
        FROM times C
        JOIN jogadores D ON C.ID_TIME = D.FKID_TIME
        WHERE C.FKID_CAMP = A.ID_CAMP
    ) AS nomes_jogadores

FROM 
    campeonato A
JOIN 
    escolas B ON A.fkid_escolas = B.ID_ESCOLA
WHERE 
    B.NOME = ?
ORDER BY 
    A.ID_CAMP DESC;
";

$stmt = $con->prepare($sql);
$stmt->bind_param("s", $login);
if (!$stmt->execute()) {
    throw new Exception("Erro ao executar a query do time: " . $stmt_time->error);
}

$result = $stmt->get_result();
$dados = [];

if ($result->num_rows >= 1) {
    while ($row = $result->fetch_assoc()) {
        $dados[] = $row;
    }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($dados);
}else{
    echo json_encode([]);
}

} catch (Exception $ex) {
    http_response_code(500);
    echo json_encode(['erro' => "Erro ao buscar campeonatos: " . $ex->getMessage()]);
    exit();
}
?>