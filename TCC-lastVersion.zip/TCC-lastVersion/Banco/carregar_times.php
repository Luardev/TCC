<?php
header('Content-Type: application/json; charset=utf-8');

require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';

function ok($data) { 
    echo json_encode(['ok' => true, 'data' => $data], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

function err($msg) { 
    http_response_code(400); 
    echo json_encode(['ok' => false, 'error' => $msg], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); 
    exit; 
}

$id_camp = isset($_GET['id_camp']) ? intval($_GET['id_camp']) : 0;

if ($id_camp <= 0) {
    err('ID do campeonato inválido');
}

try {
    global $con;
    
    // Buscar times do campeonato
    $sql = "SELECT 
                t.ID_TIME,
                t.NOME,
                t.SERIE,
                COUNT(j.ID_JOGADOR) as total_jogadores
            FROM times t
            LEFT JOIN jogadores j ON t.ID_TIME = j.FKID_TIME
            WHERE t.FKID_CAMP = ? AND t.NOME != 'TBD'
            GROUP BY t.ID_TIME, t.NOME, t.SERIE
            ORDER BY t.NOME";
    
    $stmt = $con->prepare($sql);
    $stmt->bind_param('i', $id_camp);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $times = [];
    while ($row = $result->fetch_assoc()) {
        $times[] = [
            'id' => $row['ID_TIME'],
            'nome' => $row['NOME'],
            'serie' => $row['SERIE'],
            'jogadores' => $row['total_jogadores']
        ];
    }
    
    ok($times);
    
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
}
?>
