<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
// require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/auth.php';

try {
    // 1. Verificar o ID recebido
    if (!isset($_POST['ID_CAMP']) || !is_numeric($_POST['ID_CAMP'])) {
        throw new Exception("ID inválido.");
    }

    $ID_CAMP = (int) $_POST['ID_CAMP'];

    // 2. Verificar se o arquivo foi enviado
    if (!isset($_FILES['arquivo']) || $_FILES['arquivo']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("Erro ao enviar o arquivo.");
    }

    // 3. Validar tipo de arquivo (ex: imagens)
    $permitidos = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
    $tipo = $_FILES['arquivo']['type'];

    if (!in_array($tipo, $permitidos)) {
        throw new Exception("Tipo de arquivo não permitido.");
    }

    // 4. Criar nome único para o arquivo
    $extensao = pathinfo($_FILES['arquivo']['name'], PATHINFO_EXTENSION);
    $novoNome = uniqid('camp_', true) . "." . $extensao;

    // 5. Mover o arquivo para a pasta /imagens
    $pasta = realpath(__DIR__ . '/..') . '/imagens_upload/'; // Caminho absoluto correto
    
    if (!is_dir($pasta)) {
        // Tenta criar o diretório
        if (!mkdir($pasta, 0755, true)) {
            die('Falha ao criar o diretório: ' . $pasta);
        }
    }

    $destino = $pasta . $novoNome;

    if (!move_uploaded_file($_FILES['arquivo']['tmp_name'], $destino)) {
        throw new Exception("Falha ao mover o arquivo.");
    }

    // 6. Montar a URL para salvar no banco (ajuste conforme seu domínio)
    $urlArquivo = 'imagens_upload/' . $novoNome;

    // 7. Atualizar o registro com a URL da imagem
    $update = "UPDATE CAMPEONATO SET FOTO = ? WHERE ID_CAMP = ?";
    $stmt = $con->prepare($update);
    $stmt->bind_param("si", $urlArquivo, $ID_CAMP);
    $stmt->execute();

    if ($stmt->affected_rows === 0) {
        throw new Exception("Nenhum registro atualizado.");
    }

    echo json_encode(['status' => true, 'arquivo_url' => $urlArquivo]);
    exit();

} catch (Exception $ex) {
    http_response_code(500);
    echo json_encode(['erro' => "Erro ao processar: " . $ex->getMessage()]);
    exit();
}
?>