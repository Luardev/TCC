<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/conexao.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/tcc-main/auth.php';

try {
    if (!isset($_POST['remover']) || !is_numeric($_POST['remover'])) {
        throw new Exception("ID inválido.");
    }

    $remover = (int) $_POST['remover'];

    $delete = "DELETE FROM CAMPEONATO WHERE ID_CAMP = ? ";

    $stmt = $con->prepare($delete);
    $stmt->bind_param("i", $remover);
    $stmt->execute();
    exit();

} catch (Exception $ex) {
    http_response_code(500);
    echo json_encode(['erro' => "Erro ao remover: " . $ex->getMessage()]);
    exit();
}
?>