<base href="http://localhost:8080/tcc-main/">
<link rel='shortcut icon' href='imagens/campeonato.png' type='Icon'>
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Importa Material Icons -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<!-- Importa Jquery -->
<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js'></script>
<script src="utils.js?a=<?php echo time() ?>"></script>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Rajdhani:wght@500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<!-- Link Bootstrap -->
<script src="js/bootstrap.bundle.min.js"></script>