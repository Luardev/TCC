# Sistema de Polling de API - Documentação

## 📋 Visão Geral

O sistema de polling foi criado para atualizar automaticamente os dados nas páginas cliente (`php/cliente/`) sem necessidade de recarregar a página. O sistema utiliza as funções existentes do `FuncoesBuscaCliente.php` através de novos endpoints de API.

## 🗂️ Arquivos Criados

### APIs de Dados
- `Banco/api_campeonato_cliente.php` - Dados completos do campeonato
- `Banco/api_partida_cliente.php` - Dados específicos de uma partida
- `Banco/api_time_cliente.php` - Dados específicos de um time

### Sistema de Polling
- `js/api-poller.js` - Classe principal do sistema de polling

## 🔧 Como Funciona

### 1. Estrutura dos Endpoints

Todos os endpoints seguem o padrão:
```json
{
  "ok": true,
  "data": {
    // dados específicos
    "timestamp": 1234567890
  }
}
```

### 2. Endpoints Disponíveis

#### `/tcc-main/Banco/api_campeonato_cliente.php?id_camp={id}`
Retorna dados completos do campeonato:
- Informações do campeonato
- Lista de partidas com placares
- Ranking de artilheiros
- Dados do chaveamento

#### `/tcc-main/Banco/api_partida_cliente.php?id_partida={id}&id_camp={id}&id_fase={id}`
Retorna dados específicos da partida:
- Informações da partida
- Placar atual
- Linha do tempo de eventos
- Estatísticas dos times
- Dados dos jogadores

#### `/tcc-main/Banco/api_time_cliente.php?id_time={id}&id_camp={id}`
Retorna dados específicos do time:
- Estatísticas do time
- Lista de artilheiros
- Dados de aproveitamento

### 3. Sistema de Polling

#### Classe APIPoller
```javascript
const poller = new APIPoller({
    url: 'endpoint_url',
    interval: 5000, // intervalo em ms
    onSuccess: (data) => { /* callback sucesso */ },
    onError: (error) => { /* callback erro */ }
});
```

#### Funções Específicas
```javascript
// Para campeonato
const campeonatoPoller = createCampeonatoPoller(campeonatoId, options);

// Para partida
const partidaPoller = createPartidaPoller(partidaId, campeonatoId, faseId, options);

// Para time
const timePoller = createTimePoller(timeId, campeonatoId, options);
```

## ⚙️ Configurações

### Intervalos Padrão
- **Campeonato**: 5 segundos
- **Partida**: 2 segundos (mais frequente para dados ao vivo)
- **Time**: 10 segundos (menos frequente)

### Controle de Erros
- Máximo 5 erros consecutivos antes de parar
- Retry com backoff exponencial
- Pausa automática quando aba perde foco

## 🎯 Funcionalidades Implementadas

### Página de Campeonato (`tela_campeonato_cliente.php`)
- ✅ Atualização de placares em tempo real
- ✅ Atualização da tabela de artilheiros
- ✅ Atualização do chaveamento
- ✅ Efeitos visuais para mudanças

### Página de Partida (`tela_partida.php`)
- ✅ Atualização do placar principal
- ✅ Atualização da linha do tempo
- ✅ Atualização de estatísticas
- ✅ Atualização do status da partida
- ✅ Atualização de dados dos jogadores

### Página de Time (`tela_time_cliente.php`)
- ✅ Atualização de estatísticas do time
- ✅ Atualização da lista de artilheiros
- ✅ Atualização do gráfico de aproveitamento

## 🛠️ Funções de Debug

### Console do Navegador
```javascript
// Pausar/retomar polling
togglePolling();

// Forçar atualização imediata
forceUpdate();

// Ver status do polling
console.log(campeonatoPoller.getStatus());
```

## 📊 Estrutura de Dados

### Resposta do Campeonato
```json
{
  "campeonato": {
    "nome": "Nome do Campeonato",
    "escola": "Nome da Escola",
    "ano": "2025"
  },
  "partidas": [
    {
      "ID_PARTIDA": 1,
      "TIME1": "Time A",
      "GOLS_TIME1": 2,
      "TIME2": "Time B",
      "GOLS_TIME2": 1
    }
  ],
  "artilheiros": [
    {
      "NOME": "Jogador",
      "TIME": "Time",
      "QTD_GOL": 5
    }
  ],
  "chaveamento": {
    "teams": [...],
    "results": [...]
  }
}
```

### Resposta da Partida
```json
{
  "partida": { /* dados da partida */ },
  "placar": {
    "time1": 2,
    "time2": 1
  },
  "eventos": [
    {
      "tipo": "Gol",
      "jogador": "Nome do Jogador",
      "minuto": 15,
      "icone": "⚽",
      "lado": "left"
    }
  ],
  "estatisticas": {
    "Chutes a Gol": {
      "time1": 8,
      "time2": 5
    }
  },
  "jogadores": {
    "time1": { /* dados dos jogadores */ },
    "time2": { /* dados dos jogadores */ }
  }
}
```

## 🔒 Segurança

- Headers CORS configurados
- Validação de parâmetros de entrada
- Tratamento de erros gracioso
- Sanitização de dados de saída

## 🚀 Como Usar

1. **Automático**: O sistema inicia automaticamente ao carregar as páginas
2. **Manual**: Use as funções de debug no console
3. **Configuração**: Modifique os intervalos nas funções específicas

## 📝 Notas Importantes

- O sistema pausa automaticamente quando a aba perde foco
- Retoma automaticamente quando a aba ganha foco
- Para automaticamente ao fechar a página
- Logs detalhados no console para debug
- Notificações visuais para status e erros
