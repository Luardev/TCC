<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Interclasse</title>
  <?php require_once './imports.php' ?>
  <link rel="stylesheet" href="./CSS/style.css"> 
  <script src="./js/index.js?_=<?php echo microtime()?>"></script>
</head>

<body>
  <div class="overlay" id="menuOverlay" onclick="toggleMenu()"></div>
  
  <!-- ======= HEADER ======= -->
  <header id="header" class="header-transparent">
    <div style="display: flex; align-items: center; gap: 2rem; flex-wrap: wrap;">
      <a href="index.php" style="text-decoration: none;">
      <div onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'" class="logo">
          <img src="Imagens/Logo.png" alt="Logo Interclasse" style="height: 48px; border-radius: 100%; filter: drop-shadow(0 0 5px rgba(255,255,255,0.5));">
          <span class="titulo_real">INTERCLASSE</span>
        </div>
      </a>
      <button class="menu-toggle" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
      <nav id="navLinks" style="display: flex; flex-wrap: wrap; gap: 1.5rem; font-weight: bold; font-size: 1rem;">
        <a href="php/login.php" class="nav-link">ACESSO ESCOLAR</a>
      </nav>
    </div>
  </header> 

  <!-- ======= CARROSSEL ======= -->
  <div class="carousel">
    <div class="carousel-wrapper">
      <img id="carousel-img" src="Imagens/Imagem_Carrossel_3.webp" alt="Futebol Escolar" class="carousel-image">
      <div class="progress-container">
        <div class="runner"></div>
        <div class="progress-bar"></div>
      </div>
    </div>
  </div>

  <!-- ======= CONTEÚDO PRINCIPAL ======= -->
  <main>
    <section class="section text-center">
      <h2>Campeonatos em Andamento</h2>
      <div class="carousel-wrapper" style="position: relative; display: flex; align-items: center; justify-content: center;">
        <!-- Botão esquerdo -->
        <button class="carousel-btn left" onclick="scrollCarousel(-1)" style="position: absolute; left: 0; z-index: 10;">
          <i class="fas fa-chevron-left"></i>
        </button>

        <div class="carousel-container" style="overflow: hidden; width: 80%;">
          <div class="cards-carousel" id="cardsCarousel" style="display: flex; gap: 16px; transition: transform 0.5s ease;">
            <!-- DIVS DINÂMICAS VIA JS -->
          </div>
        </div>

        <!-- Botão direito -->
        <button class="carousel-btn right" onclick="scrollCarousel(1)" style="position: absolute; right: 0; z-index: 10;">
          <i class="fas fa-chevron-right"></i>
        </button>
      </div>
    </section>

    <!-- ======= SEÇÃO BENEFÍCIOS ======= -->
    <section class="section text-center" id="sobre">
      <h2>Por que utilizar o nosso site?</h2>
      <div class="py-5 text-center" style="width: 80%; background: #151522; margin: auto; border-radius: 30px; padding: 2rem;">
        <img class="d-block mx-auto mb-4" src="imagens/logo.png" alt="Logo" width="200" height="200">
        <h1 class="display-5" style="font-size: 2rem; color: #4a90e2;">INTERCLASSE</h1> 
        <div class="col-lg-7 mx-auto">
          <p class="lead mb-4">
            O Interclasse nasceu para resolver um desafio comum nas escolas: a dificuldade de organizar e gerenciar os interclasses de forma prática e moderna.
            Criamos uma plataforma online completa que une eficiência, design e simplicidade — tudo para tornar a experiência mais intuitiva e divertida.
            Com o Interclasse, você controla equipes, partidas, resultados e tabelas em um só lugar — sem planilhas confusas ou anotações perdidas.
            Ideal para escolas públicas e privadas, nossa ferramenta facilita o trabalho de professores e organizadores e envolve os alunos de forma dinâmica.
            <br><br>🚀 Eleve o nível do seu campeonato escolar e transforme sua gestão esportiva com o Interclasse!
          </p>
          <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
            <a href="mailto:tccMain@gmail.com" target="_blank">
              <button type="button" class="btn btn-primary btn-lg px-4 gap-3">Entrar em Contato</button>
            </a>
          </div>
        </div>
      </div>
    </section>

    <!-- ======= SEÇÃO DESTAQUES ======= -->
    <section class="section" style="padding: 4rem 2rem; text-align: center;">
      <h2 style="color: #4a90e2;">Nossos Diferenciais</h2>
      <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 2rem; margin-top: 2rem;">
        <div style="width: 260px; background: #151522; border-radius: 20px; padding: 2rem;">
          <i class="fas fa-bolt" style="font-size: 2.5rem; color: #4a90e2; margin-bottom: 1rem;"></i>
          <h3 style="color: white;">Rápido e Intuitivo</h3>
          <p style="color: #ccc;">Organize campeonatos de forma simples e sem complicações.</p>
        </div>
        <div style="width: 260px; background: #151522; border-radius: 20px; padding: 2rem;">
          <i class="fas fa-users" style="font-size: 2.5rem; color: #4a90e2; margin-bottom: 1rem;"></i>
          <h3 style="color: white;">Colaboração</h3>
          <p style="color: #ccc;">Professores e alunos trabalhando juntos em uma plataforma única.</p>
        </div>
        <div style="width: 260px; background: #151522; border-radius: 20px; padding: 2rem;">
          <i class="fas fa-trophy" style="font-size: 2.5rem; color: #4a90e2; margin-bottom: 1rem;"></i>
          <h3 style="color: white;">Ranking e Resultados</h3>
          <p style="color: #ccc;">Acompanhe partidas, resultados e tabelas em tempo real.</p>
        </div>
      </div>
    </section>

    <!-- ======= SEÇÃO GALERIA / ESTEIRA ======= -->
    <section class="section" id="galeria" style="padding: 4rem 0; overflow: hidden;">
      <h2 style="color: #4a90e2; text-align: center; margin-bottom: 2rem;">Escolas parceiras</h2>

      <div class="slider">
        <div class="slide-track" id="slideTrack">
          <!-- As imagens serão adicionadas aqui via JS -->
        </div>
      </div>
    </section>



  <!-- ======= FOOTER ======= -->
    <footer id="contato" style="background: #0b0b14; color: #ccc; text-align: center; padding: 2rem; margin-top: 2rem;">
      <p>© 2025 Interclasse. Todos os direitos reservados.</p>
      <p>Participe do maior campeonato estudantil do Brasil!</p>
      <p>Contatos</p>
      <div style="margin-top: 1rem;">
        <a href="mailto:tccMain@gmail.com" style="color:#4a90e2; margin:0 10px;"><i class="fa-regular fa-envelope"></i></a>
      </div>
    </footer>
</main>
</body>
</html>
