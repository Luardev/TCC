/**
 * API Poller - Sistema de atualização periódica de dados via API
 * 
 * Características:
 * - Evita múltiplas requisições sobrepostas
 * - Intervalo configurável
 * - Tratamento de erros
 * - Callbacks para sucesso e erro
 * - Controle de start/stop
 */

class APIPoller {
    constructor(options = {}) {
        this.url = options.url || '';
        this.interval = options.interval || 5000; // 5 segundos por padrão
        this.method = options.method || 'GET';
        this.headers = options.headers || {};
        this.data = options.data || null;
        this.onSuccess = options.onSuccess || (() => {});
        this.onError = options.onError || (() => {});
        this.onStart = options.onStart || (() => {});
        this.onStop = options.onStop || (() => {});
        
        this.isRunning = false;
        this.isRequesting = false;
        this.timeoutId = null;
        this.retryCount = 0;
        this.maxRetries = options.maxRetries || 3;
        this.retryDelay = options.retryDelay || 1000;
        
        // Configurações de erro
        this.errorThreshold = options.errorThreshold || 5; // Máximo de erros consecutivos
        this.consecutiveErrors = 0;
        this.lastError = null;
    }

    /**
     * Inicia o polling
     */
    start() {
        if (this.isRunning) {
            console.warn('APIPoller já está em execução');
            return;
        }

        if (!this.url) {
            console.error('APIPoller: URL não definida');
            return;
        }

        this.isRunning = true;
        this.consecutiveErrors = 0;
        this.onStart();
        
        console.log(`APIPoller iniciado - URL: ${this.url}, Intervalo: ${this.interval}ms`);
        this.scheduleNextRequest();
    }

    /**
     * Para o polling
     */
    stop() {
        if (!this.isRunning) {
            return;
        }

        this.isRunning = false;
        
        if (this.timeoutId) {
            clearTimeout(this.timeoutId);
            this.timeoutId = null;
        }

        this.onStop();
        console.log('APIPoller parado');
    }

    /**
     * Agenda a próxima requisição
     */
    scheduleNextRequest() {
        if (!this.isRunning) {
            return;
        }

        this.timeoutId = setTimeout(() => {
            this.makeRequest();
        }, this.interval);
    }

    /**
     * Executa a requisição HTTP
     */
    async makeRequest() {
        if (!this.isRunning || this.isRequesting) {
            return;
        }

        this.isRequesting = true;

        try {
            const requestOptions = {
                method: this.method,
                headers: this.method === 'GET' ? {} : {
                    'Content-Type': 'application/json',
                    ...this.headers
                }
            };

            if (this.data && (this.method === 'POST' || this.method === 'PUT')) {
                requestOptions.body = JSON.stringify(this.data);
            }

            const response = await fetch(this.url, requestOptions);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const responseData = await response.json();
            
            // Reset contadores de erro em caso de sucesso
            this.consecutiveErrors = 0;
            this.retryCount = 0;
            this.lastError = null;

            // Executa callback de sucesso
            this.onSuccess(responseData);

        } catch (error) {
            this.handleError(error);
        } finally {
            this.isRequesting = false;
            
            // Agenda próxima requisição se ainda estiver rodando
            if (this.isRunning) {
                this.scheduleNextRequest();
            }
        }
    }

    /**
     * Trata erros de requisição
     */
    handleError(error) {
        this.consecutiveErrors++;
        this.lastError = error;
        
        console.error(`APIPoller erro (${this.consecutiveErrors}/${this.errorThreshold}):`, error.message);

        // Executa callback de erro
        this.onError(error, this.consecutiveErrors);

        // Se excedeu o limite de erros consecutivos, para o polling
        if (this.consecutiveErrors >= this.errorThreshold) {
            console.error(`APIPoller: Muitos erros consecutivos (${this.consecutiveErrors}). Parando polling.`);
            this.stop();
            return;
        }

        // Implementa retry com backoff exponencial
        if (this.retryCount < this.maxRetries) {
            this.retryCount++;
            const delay = this.retryDelay * Math.pow(2, this.retryCount - 1);
            
            console.log(`APIPoller: Tentativa ${this.retryCount}/${this.maxRetries} em ${delay}ms`);
            
            setTimeout(() => {
                if (this.isRunning) {
                    this.makeRequest();
                }
            }, delay);
        }
    }

    /**
     * Atualiza a URL da API
     */
    setUrl(url) {
        this.url = url;
    }

    /**
     * Atualiza o intervalo de polling
     */
    setInterval(interval) {
        this.interval = interval;
    }

    /**
     * Retorna o status do polling
     */
    getStatus() {
        return {
            isRunning: this.isRunning,
            isRequesting: this.isRequesting,
            consecutiveErrors: this.consecutiveErrors,
            lastError: this.lastError,
            url: this.url,
            interval: this.interval
        };
    }

    /**
     * Força uma requisição imediata (sem aguardar o intervalo)
     */
    async forceRequest() {
        if (this.isRequesting) {
            console.warn('APIPoller: Requisição já em andamento');
            return;
        }

        console.log('APIPoller: Forçando requisição imediata');
        await this.makeRequest();
    }
}

/**
 * Função utilitária para criar um poller rapidamente
 */
function createAPIPoller(url, options = {}) {
    return new APIPoller({
        url,
        ...options
    });
}

/**
 * Função para polling específico de dados de campeonato
 */
function createCampeonatoPoller(campeonatoId, options = {}) {
    return createAPIPoller(`/tcc-main/Banco/api_campeonato_cliente.php?id_camp=${campeonatoId}`, {
        interval: 5000, // 5 segundos para dados de campeonato
        onSuccess: (data) => {
            console.log('Dados do campeonato atualizados:', data);
            if (options.onDataUpdate) {
                options.onDataUpdate(data.data);
            }
        },
        onError: (error) => {
            console.error('Erro ao buscar dados do campeonato:', error);
            if (options.onError) {
                options.onError(error);
            }
        },
        ...options
    });
}

/**
 * Função para polling específico de dados de partida
 */
function createPartidaPoller(partidaId, campeonatoId, faseId, options = {}) {
    return createAPIPoller(`/tcc-main/Banco/api_partida_cliente.php?id_partida=${partidaId}&id_camp=${campeonatoId}&id_fase=${faseId}`, {
        interval: 2000, // 2 segundos para dados de partida (mais frequente)
        onSuccess: (data) => {
            console.log('Dados da partida atualizados:', data);
            if (options.onDataUpdate) {
                options.onDataUpdate(data.data);
            }
        },
        onError: (error) => {
            console.error('Erro ao buscar dados da partida:', error);
            if (options.onError) {
                options.onError(error);
            }
        },
        ...options
    });
}

/**
 * Função para polling específico de dados de time
 */
function createTimePoller(timeId, campeonatoId, options = {}) {
    return createAPIPoller(`/tcc-main/Banco/api_time_cliente.php?id_time=${timeId}&id_camp=${campeonatoId}`, {
        interval: 10000, // 10 segundos para dados de time (menos frequente)
        onSuccess: (data) => {
            console.log('Dados do time atualizados:', data);
            if (options.onDataUpdate) {
                options.onDataUpdate(data.data);
            }
        },
        onError: (error) => {
            console.error('Erro ao buscar dados do time:', error);
            if (options.onError) {
                options.onError(error);
            }
        },
        ...options
    });
}

// Exporta para uso global
window.APIPoller = APIPoller;
window.createAPIPoller = createAPIPoller;
window.createCampeonatoPoller = createCampeonatoPoller;
window.createPartidaPoller = createPartidaPoller;
window.createTimePoller = createTimePoller;
