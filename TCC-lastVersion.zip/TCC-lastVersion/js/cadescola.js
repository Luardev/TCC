var num2 =1;
$(document).ready(()=>{
    Buscar_Campeonatos();

    const urlParams = new URLSearchParams(window.location.search);
    const aconteceu = urlParams.get('aconteceu'); // n mexer
    
    if (aconteceu === 'tiponexist'){
        Aviso('warning','Título não definido')
    }
    else if (aconteceu === 'removido'){
        Aviso('info','Campeonato removido com successo!')
    }
    else if (aconteceu === 'criado'){
        Aviso('info','Campeonato criado com successo!')
    }

    $('#fotoCamp').on('change',(e)=>{
        const file = e.target.files[0];
        if (file) {
        const reader = new FileReader();
        reader.onload = (ev) => {
            $("#preview").html(
            `<img src="${ev.target.result}" class="img-thumbnail mt-2">`
            );
        };
        $('#fileName').val(`${file.name}`)
        $('#cancelUpload').prop("disabled",false); // esconde botão
        reader.readAsDataURL(file);
        }
    })

    $('#cancelUpload').on('click',()=>{
        $('#fileName').val('');
        $('#fotoCamp').val("");      // limpa input
        $('#preview').html('<img src="Imagens/empty-1.jpeg" class="img-thumbnail w-25">');    // remove preview
        $('#cancelUpload').prop("disabled",true); // esconde botão
    })

    $('#removeform').on('submit', async (e) => { 
        e.preventDefault(); // previne o envio do formulário

        // Cria um FormData com os inputs do form
        const formData = new FormData(e.target);
        
        try {
                const response = await fetch('Banco/remover.php', {
                    method: 'POST',
                    body: formData
                });

                if (!response.ok) {
                    const error = await response.json(); // ou response.json() se o PHP retornar JSON
                    throw new Error(error.erro);
                }

                // Aqui você pode atualizar a página ou exibir uma mensagem
                $('#alterar').modal('hide')
                Aviso("success",'Capeonato removido com successo!');
                Buscar_Campeonatos();

        } catch (error) {
                $('#alterar').modal('hide')
                console.error(error.message);
        }
    });
})

async function sobefoto(id){

    if (!$('#fotoCamp')[0].files || !$('#fotoCamp')[0] || $('#fotoCamp')[0].files.length === 0) {

        return Aviso("warning","Nenhuma foto encontrada");
        
    }else{

        // Cria um objeto FormData
        const formData = new FormData();
        
        // Adiciona o arquivo do input #fotoCamp ao FormData
        formData.append('arquivo', $('#fotoCamp')[0].files[0]); // 'foto' será a chave no lado PHP

        // Adiciona o valor de #ID_CAMP ao FormData
        formData.append('ID_CAMP', id); // 'idCamp' será a chave no lado PHP

        try {
            const response = await fetch('Banco/UPLOAD_FOTOCAMP.php', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error('Erro ao fazer upload');
            }
            

        } catch (error) {
            Aviso('error',error.message);
        }
    }
}

async function Buscar_Campeonatos(){
    $('#CameponatosCard').empty();
    loadingSpinner('CameponatosCard');
    try {
            const response = await fetch('Banco/BUSCA_CAMPEONATOS.php', {
                method: 'POST',
            });

            if (!response.ok) {
                throw new Error(error.erro);
            }
            
            const data = await response.json(); // ou response.json() se o PHP retornar JSON
            
            if(data.length > 0 && Array.isArray(data)){
                loadingSpinner('Campeonatos','hide');
                $('#removeSelect').empty();
                data.forEach((item,index) => {
                    let foto, styleFoto
                    if (item.FOTO){
                        foto = item.FOTO
                        styleFoto = ''
                    }else{
                        foto = './Imagens/empty-1.jpeg'
                        styleFoto = 'defaultLogo'
                    }

                    $('#Campeonatos').append(`
                        <tr>
                            <td>${item.ID_CAMP}</td>
                            <td>${item.nome_limpo}</td>
                            <td>${item.DATA}</td>
                            <td>${item.TIPO}</td>
                            <td>${item.QUANTIDADE}</td>
                            <td>
                                <span style="color: #10b981; font-weight: 500">Ativo</span>
                            </td>
                            <td><a href='./php/escola/EdicaoCampeonato.php?id_camp=${item.ID_CAMP}'><button>Editar</button></a></td>
                        </tr>                       
                    `);
                    $('#selectLabel').text('Selecione um campeonato para excluir.');
                    $(`#removeSelect`).append(`
                        <option value="${item.ID_CAMP}"> ${item.ID_CAMP} - ${item.nome_limpo}</option>
                    `);
                }) 
            } else {
                loadingSpinner('CameponatosCard','hide');
                $('#CameponatosCard').html(`
                <div class="card" style="width:90vw; margin:auto;">
                    <div class="card-body">
                        <h5 class="card-title">Nenhum campeonato cadastrado</h5>
                        <p class="card-text">Deseja criar um campeonato!? Basta clicar em "Criar" no menu lateral direito superior!</p>
                    </div>
                </div>'`);
                $('#removeform').html('<p><b>Nenhum</b> campeonato encontrado. Cadastre-os!</p>')
                $('#cad_remove_camp').prop('disabled', true);
            }

    } catch (error) {
            $('#alterar').modal('hide')
            console.error(error.message);
    }
}

/*
<div class="col-md-4 mb-4">
                            <div class="card h-content shadow-sm">
                            <img src="${foto}" class="${styleFoto}" style="max-height: 290px;">
                                <div class="card-body">
                                    <h5 class="card-title">ID: ${item.ID_CAMP}</h5>
                                    <p class="card-text"><strong>Nome:</strong> ${item.nome_limpo}</p>
                                    <p class="card-text"><strong>Quantidade:</strong> </p>
                                    <p class="card-text"><strong>Data:</strong> ${item.DATA}</p>
                                    <p class="card-text"><strong>Tipo:</strong> ${item.TIPO}</p>
                                    <div class="collapse mt-2" id="moreinfo${index}">
                                        <p class="card-text"><strong>Times:</strong> ${item.nomes_times}</p>
                                        <p class="card-text"><strong>Jogadores:</strong> ${item.nomes_jogadores}</p>
                                    </div>
                                </div>
                                <div class="card-footer d-flex gap-2">
                                    <button onclick="carrega_pagina('partidas')" class="btn btn-primary w-50">
                                        Gerenciar partidas
                                    </button>
                                    <button class="btn btn-outline-primary w-50" 
                                            data-bs-toggle="collapse" 
                                            data-bs-target="#moreinfo${index}" 
                                            aria-expanded="false" 
                                            aria-controls="moreinfo${index}">
                                        Visualizar
                                    </button>
                                </div>
                            </div>
                        </div>
*/

async function Cadastrar() {
       
    let Estatisticas_Times = [];
    let Nome = $('input[name=Nome]').val();
    let Data = $('input[name=Data]').val();
    let Tipo = $('select[name=Tipo]').val();
    let Quantidade = $('input[name=Quantidade]').val();

    $('.Nome_serie').each(function () {
    let nome_time = $(this).find('input[name="Nome_Time"]').val().trim();
    let serieValor = $(this).find('input[name="Serie"]').val().trim();

    if (nome_time && serieValor) {
        // Inicializa objeto do time
        let Estatisticas = {
            Nome_time: nome_time,
            Serie: serieValor,
            Jogadores: [] // Armazena os jogadores desse time
        };

        // Agora buscamos apenas os jogadores DENTRO deste bloco de time
        $(this).find('.jogador').each(function () {
            let nome = $(this).find('input[name="jogador_nome"]').val().trim();
            let altura = $(this).find('input[name="jogador_altura"]').val().trim();
            let idade = $(this).find('input[name="jogador_idade"]').val().trim();
            
            if (nome && altura && idade) {
                let jogador = {
                    nome: nome,
                    altura: parseFloat(altura),
                    idade: parseInt(idade)
                };
                Estatisticas.Jogadores.push(jogador);
            }else{
                alert('Nome,altura ou idade indefinidos')
            }
        });

        // Adiciona esse time com seus jogadores ao array final
        Estatisticas_Times.push(Estatisticas);
        

    }else{
        alert('Nome do Time ou Série inexistente')
    }
    });

    // console.log(Estatisticas_Times)

    let dados_enviar = {
        Nome: Nome,
        Data: Data,
        Tipo: Tipo,
        Quantidade: Quantidade,
        Estatisticas_Times: Estatisticas_Times,
    }

    // console.log(dados_enviar)
    
    try {
        let response = await fetch(`Banco/CADASTRAR_CAMP.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados_enviar)
        });
    
        // Verificar se a resposta foi ok (status HTTP 200)
        if (!response.ok) {
            throw new Error('Erro de rede ou servidor');
        }
    
        let data = await response.json(); // Aqui você vai receber o JSON enviado pelo PHP
        
        if (data.status === true) {
            sobefoto(data.id);
            $('.modal').modal('hide');
            $('.modal').empty();
            Aviso("success",data.message);
            Buscar_Campeonatos();
        } else {
            Aviso("error",data.message);
        }

    } catch (error) {
        console.error('Erro na requisição:', error);
    }
    /*
    try{

    }catch (error) {
        const response = await fetch('Banco/FuncoesGerenciar.php', {
            method: 'POST',
        });
        
        fetch("Banco/runner_partidas.php?action=auto")
        .then(response => response.json())
        .then(data => console.log(data.data))
        
    }*/
}

function addjogador(){

    $(document).off('click','.btn-primary').on('click', '.btn-primary', function () {
        // Encontra o modal mais próximo
        let modal = $(this).closest('.modal');
        // Conta os inputs dentro do modal
        let numeroInputs = modal.find('input[type="text"]').length;

        if (numeroInputs >= 15) {
            alert("Máximo de jogadores cadastrados. Não é possível adicionar mais.");
        } else {
            modal.find('.Nome_serie').append(`
                <div class='mb-3 row jogador'>
                    <div class="col">
                        <input type="text" class="form-control" name="jogador_nome" placeholder="Nome...">
                    </div>
                    <div class="col">
                        <input type="number" class="form-control" name="jogador_altura" placeholder="Altura...">
                    </div>
                    <div class="col">
                        <input type="number" class="form-control" name="jogador_idade" placeholder="Idade...">
                    </div>
                </div>
            `);
        }
    });
}

function ProximoPasso() {

    let quantidadeTimes = +$("input[name='Quantidade']").val(); // o '+' na frente faz com que ele seja interpretado como um inteiro
    for (let i = 1; i <= quantidadeTimes; i++) {
        let botaoVoltar = `<button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#Cadatrar_jogadores${i - 1}">voltar</button>`;
        let botaoProximo = `<button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#Cadatrar_jogadores${i + 1}">próximo</button>`;
        let botaoAddJogador = `<button class="btn btn-primary" onclick="addjogador()">Adicionar jogador</button>`;
        let botaoCadastrarFinal = `<button class="btn btn-success" onclick="Cadastrar()">Cadastrar</button>`;
        let txt = 'Informações dos jogadores.';
        // Monta os botões dependendo do modal
        let botoesFooter = "";
    
        if (i === 1) {
            // Primeiro modal — sem voltar
            botoesFooter = `${botaoProximo} ${botaoAddJogador}`;

        } else if (i === quantidadeTimes) {
            // Último modal — sem próximo, com botão final
            botoesFooter = `${botaoVoltar} ${botaoAddJogador} ${botaoCadastrarFinal}`;
       
        } else {
            // Modais intermediários
            botoesFooter = `${botaoVoltar} ${botaoProximo} ${botaoAddJogador}`;

        }
    
        $("#ModalCad3").append(`
            <div class="modal" id="Cadatrar_jogadores${i}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header">
                    <h1 class="modal-title fs-5" id="LabelCadJog${i}">Cadastrar Jogadores/Time ${i}</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>    
                    </div>
                    <div class="modal-body" id="ModCad${i}">
                        <div class='Nome_serie'> 
                        <div class="mb-3">
                        <label for="Nome_Time" class="col-form-label">Digite o nome do time</label>
                        <input type="text" class="form-control" name="Nome_Time" placeholder="Digite o nome do time...">
                        </div>
                        <div class="mb-3">
                        <label for="Serie" class="col-form-label">Digite a série do time</label><span> Exemplo (3°B ou 3° info A)</span>
                        <input type="text" class="form-control" name="Serie" placeholder="Digite a série do time...">
                        </div>
                        <div class="mb-3 jogador row">
                            <p class="col-form-label">${txt}</p>
                            <div class="col input-group">
                                <input type="text" class="form-control" name="jogador_nome" placeholder="Nome...">
                            </div>
                            <div class="col">
                                <input type="number" class="form-control" name="jogador_altura" placeholder="Altura...">
                            </div>
                            <div class="col">
                                <input type="number" class="form-control" name="jogador_idade" placeholder="Idade...">
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        ${botoesFooter}
                    </div>
                </div>
                </div>
            </div>
        `);
    }
    
    $("#exampleModal").modal('hide');
    console.log(num2)
    $("#Cadatrar_jogadores" + num2).modal('show');
    num2++;
}