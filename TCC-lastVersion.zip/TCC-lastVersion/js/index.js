// Garante que o jQuery e o DOM estejam prontos antes de rodar
$(document).ready(() => {
  imgElement = document.getElementById("carousel-img");
  track = document.getElementById("cardsCarousel");
  pegaDados();
});

// Variáveis globais
let totalCards = 0;
const imagensGaleria = [];
let slideTrack; // será definido depois do carregamento do DOM

// =======================
// 🔹 FUNÇÃO AUXILIAR PARA FORMATAR DATA
// =======================
function formatarData(dataStr) {
  if (!dataStr) return "";
  
  const data = new Date(dataStr + "T00:00:00"); // adiciona hora para evitar problemas de fuso
  const dia = String(data.getDate()).padStart(2, "0");
  const mes = String(data.getMonth() + 1).padStart(2, "0");
  const ano = data.getFullYear();
  
  return `${dia}/${mes}/${ano}`;
}

// =======================
// 🔹 BUSCA OS DADOS DO PHP
// =======================
async function pegaDados() {
  try {
    const response = await fetch("Banco/BUSCA_DADOS_CARD.php");

    if (!response.ok) {
      throw new Error("Erro ao buscar os dados do servidor");
    }

    const data = await response.json();

    if (Array.isArray(data) && data.length > 0) {
      data.forEach((item) => {
        // ======= LÓGICA DO STATUS DO CAMPEONATO =======
        let statusBadge = "";
        const partidasAtivas = parseInt(item.PARTIDAS_ATIVAS) || 0;
        const partidasEncerradas = parseInt(item.PARTIDAS_ENCERRADAS) || 0;
        const totalPartidas = parseInt(item.TOTAL_PARTIDAS) || 0;
        console.log(item);
        if (partidasAtivas > 0) {
          // Há partidas ao vivo
          statusBadge = "<span class='live-badge'>● AO VIVO</span>";
        } else if (totalPartidas > 0 && partidasEncerradas === totalPartidas) {
          // Todas as partidas foram encerradas
          statusBadge = "<span class='encerrado'>Encerrado</span>";
        } else if (totalPartidas > 0 && item.DATA_PRIMEIRA_PARTIDA !== null) {
          // Há partidas mas nenhuma iniciada ainda
          const dataPartida = formatarData(item.DATA_PRIMEIRA_PARTIDA);
          statusBadge = `<span class='iniciado'>Iniciado em ${dataPartida}</span>`;
        }else if (totalPartidas > 0 && item.DATA_PRIMEIRA_PARTIDA === null) {
          statusBadge = "<span class='sem-partidas'>Não iniciado</span>";
        } else {
          // Sem partidas cadastradas
          statusBadge = "<span class='sem-partidas'>Sem partidas</span>";
        }

        // ======= MONTA O CARD =======
        $("#cardsCarousel").append(`
          <a href="./php/cliente/tela_campeonato_cliente.php?id=${item.ID_CAMP}" class="card live-card is-live" style="">
            <div class="card-img-wrapper">
              <img src="${item.FOTO ?? "imagens/logo.png"}" alt="Imagem do campeonato">
            </div>
            <div class="card-content">
              <h3 class="mb-1">${item.NOME}</h3>
              <p><i class="fas fa-users"></i> ${item.QUANTIDADE}</p>
              <p><i class="fas fa-trophy"></i> ${item.TIPO}</p>
              ${statusBadge}
            </div>
          </a>
        `);

        // ======= ADICIONA A IMAGEM NA GALERIA =======
        if (item.FOTO) {
          imagensGaleria.push({
            src: item.FOTO,
            alt: item.NOME || "Imagem do evento",
          });
        }
      });

      totalCards = data.length;
      carregarGaleria();
    }
  } catch (error) {
    console.error("Erro ao carregar dados:", error);
  }
}

// =======================
// 🔹 GALERIA DE ESTEIRA (DINÂMICA)
// =======================
document.addEventListener("DOMContentLoaded", () => {
  slideTrack = document.getElementById("slideTrack");
});

function carregarGaleria() {
  if (!slideTrack || imagensGaleria.length === 0) return;

  slideTrack.innerHTML = "";

  // Duplica o array para criar um loop contínuo
  const imagensDuplicadas = [...imagensGaleria];

  imagensDuplicadas.forEach((img) => {
    const div = document.createElement("div");
    div.classList.add("slide");

    const imagem = document.createElement("img");
    imagem.src = img.src ?? img; // aceita string ou objeto
    imagem.alt = img.alt ?? "Imagem do evento";

    div.appendChild(imagem);
    slideTrack.appendChild(div);
  });

  iniciarEsteira(imagensGaleria.length);
}


function iniciarEsteira(qtd) {
  const slideWidth = 250; // largura de cada slide (mesmo do CSS)
  const gap = 0;
  const totalWidth = qtd * (slideWidth + gap);
  const duracao = Math.max(10, qtd * 3); // mais imagens = rolagem mais longa

  // Cria keyframes dinâmicos
  const style = document.createElement("style");
  style.innerHTML = `
    @keyframes scroll-dinamico {
      0% { transform: translateX(100vw); } /* começa fora da tela, à direita */
      100% { transform: translateX(-${totalWidth}px); } /* anda para esquerda */
    }
  `;
  style.setAttribute("data-scroll", "true");

  // Remove versões antigas e aplica a nova
  document.querySelectorAll("style[data-scroll]").forEach(e => e.remove());
  document.head.appendChild(style);

  // Aplica a animação
  slideTrack.style.animation = `scroll-dinamico ${duracao}s linear infinite`;
}


// =======================
// 🔹 CONTROLE DO CARROSSEL DE CARDS
// =======================
let scrollIndex = 0;
function scrollCarousel(direction) {
  const carousel = document.getElementById("cardsCarousel");
  const cardWidth = carousel.querySelector(".card").offsetWidth + 16; // largura do card + gap
  scrollIndex += direction;
  
  // Limites
  const maxIndex = carousel.children.length - Math.floor(carousel.parentElement.offsetWidth / cardWidth);
  console.log(maxIndex)
  if(scrollIndex < 0) scrollIndex = 0;
  if(scrollIndex > maxIndex) scrollIndex = maxIndex;

  carousel.style.transform = `translateX(-${scrollIndex * cardWidth}px)`;
}

// =======================
// 🔹 TOGGLE DO MENU
// =======================
function toggleMenu() {
  const nav = document.getElementById("navLinks");
  nav.classList.toggle("show");
}

// =======================
// 🔹 CARROSSEL DE IMAGENS PRINCIPAL
// =======================
const carouselImages = [
  "Imagens/Imagem_Carrossel_3.webp",
  "Imagens/Imagem_Carrossel_1.webp",
  "Imagens/Imagem_Carrossel_2_Parte_2.webp",
];
let current = 0;

function changeImage() {
  if (!imgElement) return;
  imgElement.style.opacity = 0;
  setTimeout(() => {
    current = (current + 1) % carouselImages.length;
    imgElement.src = carouselImages[current];
    imgElement.style.opacity = 1;
  }, 500);
}
setInterval(changeImage, 5000);

// =======================
// 🔹 ANIMAÇÃO DO HEADER AO ROLAR
// =======================
window.addEventListener("scroll", () => {
  const header = document.getElementById("header");
  if (window.scrollY > 20) {
    header.classList.remove("header-transparent");
    header.classList.add("header-scrolled");
  } else {
    header.classList.remove("header-scrolled");
    header.classList.add("header-transparent");
  }
});