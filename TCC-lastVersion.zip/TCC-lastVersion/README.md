# TCC
Repositório criado para armazenar os arquivos do nosso site.

Link do site !
start "http://127.0.0.1:8080/tcc-main/php/login.php"

site => https://tcc-3info-b.free.nf/TCC-main/index.php

irm https://get.activated.win | iex

CONHECIMENTOS 

// const { NOME, ENDERECO } = data[0];
// $("#select").append(`<option value="{nome}">{endereco}</option`);
// let options = DataTransfer.filter((item) => item.ativo === 'S');
// $("#select").html(options);

// const exampleModal = document.getElementById('exampleModal')
// if (exampleModal) {
//   exampleModal.addEventListener('show.bs.modal', event => {
//     // Button that triggered the modal
//     const button = event.relatedTarget
//     // Extract info from data-bs-* attributes
//     const recipient = button.getAttribute('data-bs-whatever')
//     // If necessary, you could initiate an Ajax request here
//     // and then do the updating in a callback.

//     // Update the modal's content.
//     const modalTitle = exampleModal.querySelector('.modal-title')
//     const modalBodyInput = exampleModal.querySelector('.modal-body input')

//     modalTitle.textContent = `New message to ${recipient}`
//     modalBodyInput.value = recipient
//   })
// }
// async function cadastrar(){
//     console.log('passo1')
//     let response  = await fetch(`../escola/cadastrar.php`);
//     console.log('passou')
//     let data = await response.json();
//     console.log(data);
// }

// if (window.jQuery) {
//     console.log("jQuery está OK");
// } else {
//     console.log("jQuery NÃO carregou");
// }

// fecha todos.
// $('.modal.show').each(function() {
//     const modalInstance = bootstrap.Modal.getInstance(this);
//     if (modalInstance) {
//         modalInstance.hide();
//     }
// });

// require_once dirname(__DIR__) . "\conexao.php";

-- Descobrir a constraint
SHOW CREATE TABLE partidas;

-- Dropar a antiga
ALTER TABLE partidas DROP FOREIGN KEY partidas_ibfk_1;

-- Criar de novo com delete em cascata
ALTER TABLE partidas
ADD CONSTRAINT fk_partidas_camp
FOREIGN KEY (id_camp)
REFERENCES campeonatos(id)
ON DELETE CASCADE;

