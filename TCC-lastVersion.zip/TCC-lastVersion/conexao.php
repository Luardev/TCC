<?php
$servidor = "localhost";
$usuario = "root";
$senha = "usbw";
$banco = "tcc_3infob";
$con = new mysqli($servidor,$usuario,$senha,$banco);
mysqli_set_charset($con, "utf8mb4");
// Força o mysqli a lançar exceções em erros
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if ($con -> connect_error){
    die("Falha de conexão". $con -> connect_error);
}
?>
